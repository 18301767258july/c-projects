﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;

namespace SimRobot
{
    public class SocketServer
    {
        private Socket server;
        public Socket client;

        public SocketServer(string ip, int port)
        {
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //开始监听
            try
            {
                server.Bind(new IPEndPoint(IPAddress.Parse(ip), port));
                //设同一时刻可以连接的客户端个数
                server.Listen(5);
                client = server.Accept();
            }
            catch 
            {
                Log.WriteLog("Please check ip and port is right or not");
            }
        }

        /// <summary>
        /// 接收数据，返回字节数组
        /// </summary>
        /// <returns>字节数组</returns>
        public string ReceiveDataReturnString()
        {
            byte[] data = new byte[64];
            int len = client.Receive(data);
            string message = Encoding.UTF8.GetString(data, 0, len);
            return message;
        }
        /// <summary>
        /// 以字节数组形式发送数据
        /// </summary>
        /// <param name="data">字节数组</param>
        public void SendData(string data)
        {

            client.Send(Encoding.UTF8.GetBytes(data));
        }
    }
}
