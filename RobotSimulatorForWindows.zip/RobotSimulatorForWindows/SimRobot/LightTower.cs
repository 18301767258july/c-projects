﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimRobot
{
    public class LightTower
    {
        private bool red = false;

        public bool Red
        {
            get { return red; }
            set { red = value; }
        }

        private bool yellow=false;

        public bool Yellow
        {
            get { return yellow; }
            set { yellow = value; }
        }
        private bool green=true;

        public bool Green
        {
            get { return green; }
            set { green = value; }
        }
        private bool buzzer=false;

        public bool Buzzer
        {
            get { return buzzer; }
            set { buzzer = value; }
        }
    }
}
