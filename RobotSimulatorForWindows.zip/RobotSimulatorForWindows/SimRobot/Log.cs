﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace SimRobot
{
    public class Log
    {
        private static string filepath;
        private static string fileName = DateTime.Now.ToString("yyyyMMdd") + ".log";
        private static object syncRoot = new object();

        public static void WriteLog(string text)
        {
            lock (Log.syncRoot)
            {
                try
                {
                    if (string.IsNullOrEmpty(Log.filepath))
                    {
                        string path = System.Environment.CurrentDirectory;

                        if (!string.IsNullOrEmpty(fileName))
                        {
                            if (!string.IsNullOrEmpty(path))
                            {
                                if (!Directory.Exists(path))
                                {
                                    Directory.CreateDirectory(path);
                                }

                                Log.filepath = System.IO.Path.Combine(path, fileName);

                                if (!string.IsNullOrEmpty(Log.filepath) && !File.Exists(Log.filepath))
                                {
                                    FileStream file = File.Create(Log.filepath);
                                    file.Close();
                                }
                            }
                        }
                    }

                    text = text + "\r\n";
                    using (StreamWriter write = new StreamWriter(Log.filepath, true, Encoding.UTF8))
                    {
                        write.Write(DateTime.Now.ToString("[yyyy-MM-dd HH:mm:ss.fff]") + " " + text);
                    }
                }
                catch
                {
                    //Console.WriteLine("exception caught: " + ex);
                }
            }
        }
    }
}
