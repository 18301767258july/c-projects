﻿namespace SimRobot
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.imgIO = new System.Windows.Forms.ImageList(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pbxNGBuffer2 = new System.Windows.Forms.PictureBox();
            this.pbxNGBuffer1 = new System.Windows.Forms.PictureBox();
            this.pbxNGBuffer3 = new System.Windows.Forms.PictureBox();
            this.pbxNGBuffer4 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pbxInBuffer1 = new System.Windows.Forms.PictureBox();
            this.pbxInBuffer2 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.pbxProcessBuffer2 = new System.Windows.Forms.PictureBox();
            this.pbxProcessBuffer1 = new System.Windows.Forms.PictureBox();
            this.pbxProcessBuffer3 = new System.Windows.Forms.PictureBox();
            this.pbxProcessBuffer4 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pbxGreen = new System.Windows.Forms.PictureBox();
            this.pbxYellow = new System.Windows.Forms.PictureBox();
            this.pbxRed = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.imgBeacon = new System.Windows.Forms.ImageList(this.components);
            this.imgBuffer = new System.Windows.Forms.ImageList(this.components);
            this.imgLight1 = new System.Windows.Forms.ImageList(this.components);
            this.imgLight0 = new System.Windows.Forms.ImageList(this.components);
            this.E_Stop = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.tbxSpeed = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pbxLeft7 = new System.Windows.Forms.PictureBox();
            this.pbxLeft8 = new System.Windows.Forms.PictureBox();
            this.pbxLeft6 = new System.Windows.Forms.PictureBox();
            this.pbxLeft5 = new System.Windows.Forms.PictureBox();
            this.pbxLeft4 = new System.Windows.Forms.PictureBox();
            this.pbxLeft3 = new System.Windows.Forms.PictureBox();
            this.pbxLeft1 = new System.Windows.Forms.PictureBox();
            this.pbxLeft2 = new System.Windows.Forms.PictureBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.pbxRight8 = new System.Windows.Forms.PictureBox();
            this.pbxRight7 = new System.Windows.Forms.PictureBox();
            this.pbxRight6 = new System.Windows.Forms.PictureBox();
            this.pbxRight5 = new System.Windows.Forms.PictureBox();
            this.pbxRight2 = new System.Windows.Forms.PictureBox();
            this.pbxRight1 = new System.Windows.Forms.PictureBox();
            this.pbxRight3 = new System.Windows.Forms.PictureBox();
            this.pbxRight4 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.pbxE_Stop = new System.Windows.Forms.PictureBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pbxGoldenDoorLock = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pbxGoldenDoorLight = new System.Windows.Forms.PictureBox();
            this.labLight = new System.Windows.Forms.Label();
            this.pbxGoldenDoor = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbxAirPressure = new System.Windows.Forms.TextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btnUPS = new System.Windows.Forms.Button();
            this.lblVacuum = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.pbxAudit3 = new System.Windows.Forms.PictureBox();
            this.pbxAudit2 = new System.Windows.Forms.PictureBox();
            this.pbxAudit1 = new System.Windows.Forms.PictureBox();
            this.pbxAudit4 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.pbxRejectLock = new System.Windows.Forms.PictureBox();
            this.pbxRejectClosed = new System.Windows.Forms.PictureBox();
            this.pbxClamp1Dut = new System.Windows.Forms.PictureBox();
            this.pbxClamp1Open = new System.Windows.Forms.PictureBox();
            this.pbxClamp1Closed = new System.Windows.Forms.PictureBox();
            this.pbxBeacon = new System.Windows.Forms.PictureBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.tbxIP = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tbxCAMPort = new System.Windows.Forms.TextBox();
            this.tbxAVCPort = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxNGBuffer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxNGBuffer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxNGBuffer3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxNGBuffer4)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxInBuffer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxInBuffer2)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxProcessBuffer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxProcessBuffer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxProcessBuffer3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxProcessBuffer4)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft2)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight4)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxE_Stop)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGoldenDoorLock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGoldenDoorLight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGoldenDoor)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAudit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAudit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAudit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAudit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRejectLock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRejectClosed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClamp1Dut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClamp1Open)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClamp1Closed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBeacon)).BeginInit();
            this.SuspendLayout();
            // 
            // imgIO
            // 
            this.imgIO.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgIO.ImageStream")));
            this.imgIO.TransparentColor = System.Drawing.Color.Transparent;
            this.imgIO.Images.SetKeyName(0, "111.PNG");
            this.imgIO.Images.SetKeyName(1, "222.PNG");
            this.imgIO.Images.SetKeyName(2, "498f8f9acffbd10258e1c0dabe8c6323.jpg");
            this.imgIO.Images.SetKeyName(3, "c89a11f80576894403f1d16ab5e55d10.jpg");
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pbxNGBuffer2);
            this.groupBox1.Controls.Add(this.pbxNGBuffer1);
            this.groupBox1.Controls.Add(this.pbxNGBuffer3);
            this.groupBox1.Controls.Add(this.pbxNGBuffer4);
            this.groupBox1.Location = new System.Drawing.Point(527, 262);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(26, 72);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            // 
            // pbxNGBuffer2
            // 
            this.pbxNGBuffer2.Location = new System.Drawing.Point(6, 41);
            this.pbxNGBuffer2.Name = "pbxNGBuffer2";
            this.pbxNGBuffer2.Size = new System.Drawing.Size(10, 10);
            this.pbxNGBuffer2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxNGBuffer2.TabIndex = 32;
            this.pbxNGBuffer2.TabStop = false;
            this.pbxNGBuffer2.Click += new System.EventHandler(this.addDeleteUUTNGBuffer2);
            // 
            // pbxNGBuffer1
            // 
            this.pbxNGBuffer1.Location = new System.Drawing.Point(6, 57);
            this.pbxNGBuffer1.Name = "pbxNGBuffer1";
            this.pbxNGBuffer1.Size = new System.Drawing.Size(10, 10);
            this.pbxNGBuffer1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxNGBuffer1.TabIndex = 33;
            this.pbxNGBuffer1.TabStop = false;
            this.pbxNGBuffer1.Click += new System.EventHandler(this.addDeleteUUTNGBuffer1);
            // 
            // pbxNGBuffer3
            // 
            this.pbxNGBuffer3.Location = new System.Drawing.Point(6, 25);
            this.pbxNGBuffer3.Name = "pbxNGBuffer3";
            this.pbxNGBuffer3.Size = new System.Drawing.Size(10, 10);
            this.pbxNGBuffer3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxNGBuffer3.TabIndex = 31;
            this.pbxNGBuffer3.TabStop = false;
            this.pbxNGBuffer3.Click += new System.EventHandler(this.addDeleteUUTNGBuffer3);
            // 
            // pbxNGBuffer4
            // 
            this.pbxNGBuffer4.Location = new System.Drawing.Point(6, 9);
            this.pbxNGBuffer4.Name = "pbxNGBuffer4";
            this.pbxNGBuffer4.Size = new System.Drawing.Size(10, 10);
            this.pbxNGBuffer4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxNGBuffer4.TabIndex = 30;
            this.pbxNGBuffer4.TabStop = false;
            this.pbxNGBuffer4.Click += new System.EventHandler(this.addDeleteUUTNGBuffer4);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pbxInBuffer1);
            this.groupBox2.Controls.Add(this.pbxInBuffer2);
            this.groupBox2.Location = new System.Drawing.Point(235, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(219, 66);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "InBuffer";
            // 
            // pbxInBuffer1
            // 
            this.pbxInBuffer1.Location = new System.Drawing.Point(7, 12);
            this.pbxInBuffer1.Name = "pbxInBuffer1";
            this.pbxInBuffer1.Size = new System.Drawing.Size(39, 50);
            this.pbxInBuffer1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxInBuffer1.TabIndex = 37;
            this.pbxInBuffer1.TabStop = false;
            this.pbxInBuffer1.Click += new System.EventHandler(this.addDeleteUUTInBuffer1);
            // 
            // pbxInBuffer2
            // 
            this.pbxInBuffer2.Location = new System.Drawing.Point(172, 12);
            this.pbxInBuffer2.Name = "pbxInBuffer2";
            this.pbxInBuffer2.Size = new System.Drawing.Size(39, 50);
            this.pbxInBuffer2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxInBuffer2.TabIndex = 38;
            this.pbxInBuffer2.TabStop = false;
            this.pbxInBuffer2.Click += new System.EventHandler(this.addDeleteUUTInBuffer2);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pbxProcessBuffer2);
            this.groupBox4.Controls.Add(this.pbxProcessBuffer1);
            this.groupBox4.Controls.Add(this.pbxProcessBuffer3);
            this.groupBox4.Controls.Add(this.pbxProcessBuffer4);
            this.groupBox4.Location = new System.Drawing.Point(466, 262);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(26, 72);
            this.groupBox4.TabIndex = 43;
            this.groupBox4.TabStop = false;
            // 
            // pbxProcessBuffer2
            // 
            this.pbxProcessBuffer2.Location = new System.Drawing.Point(6, 41);
            this.pbxProcessBuffer2.Name = "pbxProcessBuffer2";
            this.pbxProcessBuffer2.Size = new System.Drawing.Size(10, 10);
            this.pbxProcessBuffer2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxProcessBuffer2.TabIndex = 32;
            this.pbxProcessBuffer2.TabStop = false;
            this.pbxProcessBuffer2.Click += new System.EventHandler(this.addDeleteUUTProcessBuffer2);
            // 
            // pbxProcessBuffer1
            // 
            this.pbxProcessBuffer1.Location = new System.Drawing.Point(6, 57);
            this.pbxProcessBuffer1.Name = "pbxProcessBuffer1";
            this.pbxProcessBuffer1.Size = new System.Drawing.Size(10, 10);
            this.pbxProcessBuffer1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxProcessBuffer1.TabIndex = 33;
            this.pbxProcessBuffer1.TabStop = false;
            this.pbxProcessBuffer1.Click += new System.EventHandler(this.addDeleteUUTProcessBuffer1);
            // 
            // pbxProcessBuffer3
            // 
            this.pbxProcessBuffer3.Location = new System.Drawing.Point(6, 25);
            this.pbxProcessBuffer3.Name = "pbxProcessBuffer3";
            this.pbxProcessBuffer3.Size = new System.Drawing.Size(10, 10);
            this.pbxProcessBuffer3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxProcessBuffer3.TabIndex = 31;
            this.pbxProcessBuffer3.TabStop = false;
            this.pbxProcessBuffer3.Click += new System.EventHandler(this.addDeleteUUTProcessBuffer3);
            // 
            // pbxProcessBuffer4
            // 
            this.pbxProcessBuffer4.Location = new System.Drawing.Point(6, 9);
            this.pbxProcessBuffer4.Name = "pbxProcessBuffer4";
            this.pbxProcessBuffer4.Size = new System.Drawing.Size(10, 10);
            this.pbxProcessBuffer4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxProcessBuffer4.TabIndex = 30;
            this.pbxProcessBuffer4.TabStop = false;
            this.pbxProcessBuffer4.Click += new System.EventHandler(this.addDeleteUUTProcessBuffer4);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(445, 337);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 12);
            this.label1.TabIndex = 44;
            this.label1.Text = "ProcessBuffer";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(521, 337);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 12);
            this.label2.TabIndex = 45;
            this.label2.Text = "NGBuffer";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pbxGreen);
            this.groupBox3.Controls.Add(this.pbxYellow);
            this.groupBox3.Controls.Add(this.pbxRed);
            this.groupBox3.Location = new System.Drawing.Point(12, 46);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(38, 102);
            this.groupBox3.TabIndex = 46;
            this.groupBox3.TabStop = false;
            // 
            // pbxGreen
            // 
            this.pbxGreen.Location = new System.Drawing.Point(6, 72);
            this.pbxGreen.Name = "pbxGreen";
            this.pbxGreen.Size = new System.Drawing.Size(24, 24);
            this.pbxGreen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxGreen.TabIndex = 49;
            this.pbxGreen.TabStop = false;
            // 
            // pbxYellow
            // 
            this.pbxYellow.Location = new System.Drawing.Point(6, 42);
            this.pbxYellow.Name = "pbxYellow";
            this.pbxYellow.Size = new System.Drawing.Size(24, 24);
            this.pbxYellow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxYellow.TabIndex = 48;
            this.pbxYellow.TabStop = false;
            // 
            // pbxRed
            // 
            this.pbxRed.Location = new System.Drawing.Point(6, 12);
            this.pbxRed.Name = "pbxRed";
            this.pbxRed.Size = new System.Drawing.Size(24, 24);
            this.pbxRed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRed.TabIndex = 47;
            this.pbxRed.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 12);
            this.label3.TabIndex = 47;
            this.label3.Text = "Light";
            // 
            // imgBeacon
            // 
            this.imgBeacon.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgBeacon.ImageStream")));
            this.imgBeacon.TransparentColor = System.Drawing.Color.Transparent;
            this.imgBeacon.Images.SetKeyName(0, "a525bc47bb628b0228ca28cb9444c904.png");
            this.imgBeacon.Images.SetKeyName(1, "34563oi.png");
            // 
            // imgBuffer
            // 
            this.imgBuffer.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgBuffer.ImageStream")));
            this.imgBuffer.TransparentColor = System.Drawing.Color.Transparent;
            this.imgBuffer.Images.SetKeyName(0, "56c068db870aedbcdff821384caa9f68.jpg");
            this.imgBuffer.Images.SetKeyName(1, "813edc936d58f8f58336e00eab174c0b.jpg");
            this.imgBuffer.Images.SetKeyName(2, "ca7f8f6bdcdf6f8b44a6448ab631c40f.jpg");
            // 
            // imgLight1
            // 
            this.imgLight1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgLight1.ImageStream")));
            this.imgLight1.TransparentColor = System.Drawing.Color.Transparent;
            this.imgLight1.Images.SetKeyName(0, "3.png");
            this.imgLight1.Images.SetKeyName(1, "6.png");
            this.imgLight1.Images.SetKeyName(2, "re.png");
            // 
            // imgLight0
            // 
            this.imgLight0.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgLight0.ImageStream")));
            this.imgLight0.TransparentColor = System.Drawing.Color.Transparent;
            this.imgLight0.Images.SetKeyName(0, "b0288f3fc53c7d705badf275bbc2ac45.png");
            this.imgLight0.Images.SetKeyName(1, "cac274d2e8837bc0cd5ec2ff73f8f137.gif");
            this.imgLight0.Images.SetKeyName(2, "e772dd97ed34ad7f3f6751dbc30a3e23.png");
            // 
            // E_Stop
            // 
            this.E_Stop.AutoSize = true;
            this.E_Stop.Location = new System.Drawing.Point(25, 18);
            this.E_Stop.Name = "E_Stop";
            this.E_Stop.Size = new System.Drawing.Size(39, 12);
            this.E_Stop.TabIndex = 51;
            this.E_Stop.Text = "E_Stop";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(56, 14);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 54;
            this.button2.Text = "setSpeed";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tbxSpeed
            // 
            this.tbxSpeed.Location = new System.Drawing.Point(7, 14);
            this.tbxSpeed.Name = "tbxSpeed";
            this.tbxSpeed.Size = new System.Drawing.Size(43, 22);
            this.tbxSpeed.TabIndex = 55;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.pbxLeft7);
            this.groupBox5.Controls.Add(this.pbxLeft8);
            this.groupBox5.Controls.Add(this.pbxLeft6);
            this.groupBox5.Controls.Add(this.pbxLeft5);
            this.groupBox5.Controls.Add(this.pbxLeft4);
            this.groupBox5.Controls.Add(this.pbxLeft3);
            this.groupBox5.Controls.Add(this.pbxLeft1);
            this.groupBox5.Controls.Add(this.pbxLeft2);
            this.groupBox5.Location = new System.Drawing.Point(154, 108);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(144, 145);
            this.groupBox5.TabIndex = 56;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Left";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(102, 54);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(11, 12);
            this.label16.TabIndex = 73;
            this.label16.Text = "8";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(100, 80);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(11, 12);
            this.label15.TabIndex = 72;
            this.label15.Text = "7";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(86, 130);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(11, 12);
            this.label14.TabIndex = 71;
            this.label14.Text = "6";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(53, 130);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(11, 12);
            this.label13.TabIndex = 70;
            this.label13.Text = "5";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(35, 84);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(11, 12);
            this.label12.TabIndex = 69;
            this.label12.Text = "4";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(33, 54);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(11, 12);
            this.label11.TabIndex = 68;
            this.label11.Text = "3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(53, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(11, 12);
            this.label10.TabIndex = 67;
            this.label10.Text = "2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(86, 41);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(11, 12);
            this.label9.TabIndex = 66;
            this.label9.Text = "1";
            // 
            // pbxLeft7
            // 
            this.pbxLeft7.Location = new System.Drawing.Point(112, 74);
            this.pbxLeft7.Name = "pbxLeft7";
            this.pbxLeft7.Size = new System.Drawing.Size(25, 30);
            this.pbxLeft7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxLeft7.TabIndex = 65;
            this.pbxLeft7.TabStop = false;
            this.pbxLeft7.Click += new System.EventHandler(this.addDeleteUUTLeft7);
            // 
            // pbxLeft8
            // 
            this.pbxLeft8.Location = new System.Drawing.Point(113, 42);
            this.pbxLeft8.Name = "pbxLeft8";
            this.pbxLeft8.Size = new System.Drawing.Size(25, 30);
            this.pbxLeft8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxLeft8.TabIndex = 64;
            this.pbxLeft8.TabStop = false;
            this.pbxLeft8.Click += new System.EventHandler(this.addDeleteUUTLeft8);
            // 
            // pbxLeft6
            // 
            this.pbxLeft6.Location = new System.Drawing.Point(81, 99);
            this.pbxLeft6.Name = "pbxLeft6";
            this.pbxLeft6.Size = new System.Drawing.Size(25, 30);
            this.pbxLeft6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxLeft6.TabIndex = 63;
            this.pbxLeft6.TabStop = false;
            this.pbxLeft6.Click += new System.EventHandler(this.addDeleteUUTLeft6);
            // 
            // pbxLeft5
            // 
            this.pbxLeft5.Location = new System.Drawing.Point(44, 99);
            this.pbxLeft5.Name = "pbxLeft5";
            this.pbxLeft5.Size = new System.Drawing.Size(25, 30);
            this.pbxLeft5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxLeft5.TabIndex = 62;
            this.pbxLeft5.TabStop = false;
            this.pbxLeft5.Click += new System.EventHandler(this.addDeleteUUTLeft5);
            // 
            // pbxLeft4
            // 
            this.pbxLeft4.Location = new System.Drawing.Point(6, 77);
            this.pbxLeft4.Name = "pbxLeft4";
            this.pbxLeft4.Size = new System.Drawing.Size(25, 30);
            this.pbxLeft4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxLeft4.TabIndex = 61;
            this.pbxLeft4.TabStop = false;
            this.pbxLeft4.Click += new System.EventHandler(this.addDeleteUUTLeft4);
            // 
            // pbxLeft3
            // 
            this.pbxLeft3.Location = new System.Drawing.Point(6, 42);
            this.pbxLeft3.Name = "pbxLeft3";
            this.pbxLeft3.Size = new System.Drawing.Size(25, 30);
            this.pbxLeft3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxLeft3.TabIndex = 60;
            this.pbxLeft3.TabStop = false;
            this.pbxLeft3.Click += new System.EventHandler(this.addDeleteUUTLeft3);
            // 
            // pbxLeft1
            // 
            this.pbxLeft1.Location = new System.Drawing.Point(81, 10);
            this.pbxLeft1.Name = "pbxLeft1";
            this.pbxLeft1.Size = new System.Drawing.Size(25, 30);
            this.pbxLeft1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxLeft1.TabIndex = 59;
            this.pbxLeft1.TabStop = false;
            this.pbxLeft1.Click += new System.EventHandler(this.addDeleteUUTLeft1);
            // 
            // pbxLeft2
            // 
            this.pbxLeft2.Location = new System.Drawing.Point(44, 10);
            this.pbxLeft2.Name = "pbxLeft2";
            this.pbxLeft2.Size = new System.Drawing.Size(25, 30);
            this.pbxLeft2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxLeft2.TabIndex = 58;
            this.pbxLeft2.TabStop = false;
            this.pbxLeft2.Click += new System.EventHandler(this.addDeleteUUTLeft2);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.pbxRight8);
            this.groupBox6.Controls.Add(this.pbxRight7);
            this.groupBox6.Controls.Add(this.pbxRight6);
            this.groupBox6.Controls.Add(this.pbxRight5);
            this.groupBox6.Controls.Add(this.pbxRight2);
            this.groupBox6.Controls.Add(this.pbxRight1);
            this.groupBox6.Controls.Add(this.pbxRight3);
            this.groupBox6.Controls.Add(this.pbxRight4);
            this.groupBox6.Location = new System.Drawing.Point(356, 108);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(149, 145);
            this.groupBox6.TabIndex = 62;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Right";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(105, 54);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(11, 12);
            this.label24.TabIndex = 74;
            this.label24.Text = "8";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(103, 85);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(11, 12);
            this.label23.TabIndex = 74;
            this.label23.Text = "7";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(89, 130);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(11, 12);
            this.label22.TabIndex = 74;
            this.label22.Text = "6";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(59, 131);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(11, 12);
            this.label21.TabIndex = 74;
            this.label21.Text = "5";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(35, 84);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(11, 12);
            this.label20.TabIndex = 74;
            this.label20.Text = "4";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(37, 53);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(11, 12);
            this.label19.TabIndex = 74;
            this.label19.Text = "3";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(59, 41);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(11, 12);
            this.label18.TabIndex = 74;
            this.label18.Text = "2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(92, 42);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(11, 12);
            this.label17.TabIndex = 74;
            this.label17.Text = "1";
            // 
            // pbxRight8
            // 
            this.pbxRight8.Location = new System.Drawing.Point(116, 42);
            this.pbxRight8.Name = "pbxRight8";
            this.pbxRight8.Size = new System.Drawing.Size(25, 30);
            this.pbxRight8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRight8.TabIndex = 65;
            this.pbxRight8.TabStop = false;
            this.pbxRight8.Click += new System.EventHandler(this.addDeleteUUTRight8);
            // 
            // pbxRight7
            // 
            this.pbxRight7.Location = new System.Drawing.Point(116, 77);
            this.pbxRight7.Name = "pbxRight7";
            this.pbxRight7.Size = new System.Drawing.Size(25, 30);
            this.pbxRight7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRight7.TabIndex = 64;
            this.pbxRight7.TabStop = false;
            this.pbxRight7.Click += new System.EventHandler(this.addDeleteUUTRight7);
            // 
            // pbxRight6
            // 
            this.pbxRight6.Location = new System.Drawing.Point(82, 98);
            this.pbxRight6.Name = "pbxRight6";
            this.pbxRight6.Size = new System.Drawing.Size(25, 30);
            this.pbxRight6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRight6.TabIndex = 63;
            this.pbxRight6.TabStop = false;
            this.pbxRight6.Click += new System.EventHandler(this.addDeleteUUTRight6);
            // 
            // pbxRight5
            // 
            this.pbxRight5.Location = new System.Drawing.Point(51, 98);
            this.pbxRight5.Name = "pbxRight5";
            this.pbxRight5.Size = new System.Drawing.Size(25, 30);
            this.pbxRight5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRight5.TabIndex = 62;
            this.pbxRight5.TabStop = false;
            this.pbxRight5.Click += new System.EventHandler(this.addDeleteUUTRight5);
            // 
            // pbxRight2
            // 
            this.pbxRight2.Location = new System.Drawing.Point(51, 11);
            this.pbxRight2.Name = "pbxRight2";
            this.pbxRight2.Size = new System.Drawing.Size(25, 30);
            this.pbxRight2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRight2.TabIndex = 61;
            this.pbxRight2.TabStop = false;
            this.pbxRight2.Click += new System.EventHandler(this.addDeleteUUTRight2);
            // 
            // pbxRight1
            // 
            this.pbxRight1.Location = new System.Drawing.Point(82, 11);
            this.pbxRight1.Name = "pbxRight1";
            this.pbxRight1.Size = new System.Drawing.Size(25, 30);
            this.pbxRight1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRight1.TabIndex = 60;
            this.pbxRight1.TabStop = false;
            this.pbxRight1.Click += new System.EventHandler(this.addDeleteUUTRight1);
            // 
            // pbxRight3
            // 
            this.pbxRight3.Location = new System.Drawing.Point(10, 41);
            this.pbxRight3.Name = "pbxRight3";
            this.pbxRight3.Size = new System.Drawing.Size(25, 30);
            this.pbxRight3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRight3.TabIndex = 59;
            this.pbxRight3.TabStop = false;
            this.pbxRight3.Click += new System.EventHandler(this.addDeleteUUTRight3);
            // 
            // pbxRight4
            // 
            this.pbxRight4.Location = new System.Drawing.Point(10, 77);
            this.pbxRight4.Name = "pbxRight4";
            this.pbxRight4.Size = new System.Drawing.Size(25, 30);
            this.pbxRight4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRight4.TabIndex = 58;
            this.pbxRight4.TabStop = false;
            this.pbxRight4.Click += new System.EventHandler(this.addDeleteUUTRight4);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(300, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 12);
            this.label4.TabIndex = 64;
            this.label4.Text = "Closed";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(301, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 65;
            this.label5.Text = "Opened";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.pbxE_Stop);
            this.groupBox8.Controls.Add(this.E_Stop);
            this.groupBox8.Location = new System.Drawing.Point(12, 210);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(70, 36);
            this.groupBox8.TabIndex = 68;
            this.groupBox8.TabStop = false;
            // 
            // pbxE_Stop
            // 
            this.pbxE_Stop.Location = new System.Drawing.Point(6, 16);
            this.pbxE_Stop.Name = "pbxE_Stop";
            this.pbxE_Stop.Size = new System.Drawing.Size(13, 14);
            this.pbxE_Stop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxE_Stop.TabIndex = 50;
            this.pbxE_Stop.TabStop = false;
            this.pbxE_Stop.Click += new System.EventHandler(this.E_StopClick);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.tbxSpeed);
            this.groupBox9.Controls.Add(this.button2);
            this.groupBox9.Location = new System.Drawing.Point(12, 251);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(134, 41);
            this.groupBox9.TabIndex = 69;
            this.groupBox9.TabStop = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(101, 13);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(45, 37);
            this.button3.TabIndex = 70;
            this.button3.Text = "GoldenDoor";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label8);
            this.groupBox10.Controls.Add(this.pbxGoldenDoorLock);
            this.groupBox10.Controls.Add(this.label7);
            this.groupBox10.Controls.Add(this.pbxGoldenDoorLight);
            this.groupBox10.Controls.Add(this.labLight);
            this.groupBox10.Controls.Add(this.pbxGoldenDoor);
            this.groupBox10.Controls.Add(this.button3);
            this.groupBox10.Location = new System.Drawing.Point(12, 298);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(146, 59);
            this.groupBox10.TabIndex = 71;
            this.groupBox10.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(71, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 12);
            this.label8.TabIndex = 76;
            this.label8.Text = "door";
            // 
            // pbxGoldenDoorLock
            // 
            this.pbxGoldenDoorLock.Location = new System.Drawing.Point(42, 30);
            this.pbxGoldenDoorLock.Name = "pbxGoldenDoorLock";
            this.pbxGoldenDoorLock.Size = new System.Drawing.Size(19, 20);
            this.pbxGoldenDoorLock.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxGoldenDoorLock.TabIndex = 75;
            this.pbxGoldenDoorLock.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(40, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 12);
            this.label7.TabIndex = 74;
            this.label7.Text = "lock";
            // 
            // pbxGoldenDoorLight
            // 
            this.pbxGoldenDoorLight.Location = new System.Drawing.Point(6, 31);
            this.pbxGoldenDoorLight.Name = "pbxGoldenDoorLight";
            this.pbxGoldenDoorLight.Size = new System.Drawing.Size(19, 20);
            this.pbxGoldenDoorLight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxGoldenDoorLight.TabIndex = 73;
            this.pbxGoldenDoorLight.TabStop = false;
            // 
            // labLight
            // 
            this.labLight.AutoSize = true;
            this.labLight.Location = new System.Drawing.Point(8, 10);
            this.labLight.Name = "labLight";
            this.labLight.Size = new System.Drawing.Size(26, 12);
            this.labLight.TabIndex = 72;
            this.labLight.Text = "light";
            // 
            // pbxGoldenDoor
            // 
            this.pbxGoldenDoor.Location = new System.Drawing.Point(73, 30);
            this.pbxGoldenDoor.Name = "pbxGoldenDoor";
            this.pbxGoldenDoor.Size = new System.Drawing.Size(22, 21);
            this.pbxGoldenDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxGoldenDoor.TabIndex = 71;
            this.pbxGoldenDoor.TabStop = false;
            this.pbxGoldenDoor.Click += new System.EventHandler(this.DoorStatus);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 12);
            this.label6.TabIndex = 72;
            this.label6.Text = "airPressure:";
            // 
            // tbxAirPressure
            // 
            this.tbxAirPressure.Location = new System.Drawing.Point(61, 9);
            this.tbxAirPressure.Name = "tbxAirPressure";
            this.tbxAirPressure.Size = new System.Drawing.Size(45, 22);
            this.tbxAirPressure.TabIndex = 73;
            this.tbxAirPressure.Text = "450";
            this.tbxAirPressure.TextChanged += new System.EventHandler(this.airPressure_TextChange);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label6);
            this.groupBox11.Controls.Add(this.tbxAirPressure);
            this.groupBox11.Location = new System.Drawing.Point(12, 173);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(111, 31);
            this.groupBox11.TabIndex = 74;
            this.groupBox11.TabStop = false;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(73, 89);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 75;
            this.button4.Text = "Ethernet wire";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(73, 59);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 76;
            this.button5.Text = "UnLoadError";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnUPS
            // 
            this.btnUPS.Location = new System.Drawing.Point(71, 29);
            this.btnUPS.Name = "btnUPS";
            this.btnUPS.Size = new System.Drawing.Size(87, 23);
            this.btnUPS.TabIndex = 77;
            this.btnUPS.Text = "UPS Normal";
            this.btnUPS.UseVisualStyleBackColor = true;
            this.btnUPS.Click += new System.EventHandler(this.button6_Click);
            // 
            // lblVacuum
            // 
            this.lblVacuum.AutoSize = true;
            this.lblVacuum.Location = new System.Drawing.Point(305, 179);
            this.lblVacuum.Name = "lblVacuum";
            this.lblVacuum.Size = new System.Drawing.Size(22, 12);
            this.lblVacuum.TabIndex = 79;
            this.lblVacuum.Text = "Dut";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.pbxAudit3);
            this.groupBox7.Controls.Add(this.pbxAudit2);
            this.groupBox7.Controls.Add(this.pbxAudit1);
            this.groupBox7.Controls.Add(this.pbxAudit4);
            this.groupBox7.Location = new System.Drawing.Point(191, 287);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(219, 66);
            this.groupBox7.TabIndex = 42;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "AuditBuffer";
            // 
            // pbxAudit3
            // 
            this.pbxAudit3.Location = new System.Drawing.Point(116, 12);
            this.pbxAudit3.Name = "pbxAudit3";
            this.pbxAudit3.Size = new System.Drawing.Size(39, 50);
            this.pbxAudit3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxAudit3.TabIndex = 40;
            this.pbxAudit3.TabStop = false;
            this.pbxAudit3.Click += new System.EventHandler(this.addDeleteUUTAuditBuffer3);
            // 
            // pbxAudit2
            // 
            this.pbxAudit2.Location = new System.Drawing.Point(62, 12);
            this.pbxAudit2.Name = "pbxAudit2";
            this.pbxAudit2.Size = new System.Drawing.Size(39, 50);
            this.pbxAudit2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxAudit2.TabIndex = 39;
            this.pbxAudit2.TabStop = false;
            this.pbxAudit2.Click += new System.EventHandler(this.addDeleteUUTAuditBuffer2);
            // 
            // pbxAudit1
            // 
            this.pbxAudit1.Location = new System.Drawing.Point(7, 12);
            this.pbxAudit1.Name = "pbxAudit1";
            this.pbxAudit1.Size = new System.Drawing.Size(39, 50);
            this.pbxAudit1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxAudit1.TabIndex = 37;
            this.pbxAudit1.TabStop = false;
            this.pbxAudit1.Click += new System.EventHandler(this.addDeleteUUTAuditBuffer1);
            // 
            // pbxAudit4
            // 
            this.pbxAudit4.Location = new System.Drawing.Point(172, 12);
            this.pbxAudit4.Name = "pbxAudit4";
            this.pbxAudit4.Size = new System.Drawing.Size(39, 50);
            this.pbxAudit4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxAudit4.TabIndex = 38;
            this.pbxAudit4.TabStop = false;
            this.pbxAudit4.Click += new System.EventHandler(this.addDeleteUUTAuditBuffer4);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(559, 274);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(79, 23);
            this.button1.TabIndex = 80;
            this.button1.Text = "RejectButten";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(574, 303);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(37, 12);
            this.label25.TabIndex = 82;
            this.label25.Text = "Closed";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(574, 322);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 12);
            this.label26.TabIndex = 83;
            this.label26.Text = "Lock";
            // 
            // pbxRejectLock
            // 
            this.pbxRejectLock.Location = new System.Drawing.Point(617, 324);
            this.pbxRejectLock.Name = "pbxRejectLock";
            this.pbxRejectLock.Size = new System.Drawing.Size(10, 10);
            this.pbxRejectLock.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRejectLock.TabIndex = 84;
            this.pbxRejectLock.TabStop = false;
            // 
            // pbxRejectClosed
            // 
            this.pbxRejectClosed.Location = new System.Drawing.Point(617, 303);
            this.pbxRejectClosed.Name = "pbxRejectClosed";
            this.pbxRejectClosed.Size = new System.Drawing.Size(10, 10);
            this.pbxRejectClosed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxRejectClosed.TabIndex = 81;
            this.pbxRejectClosed.TabStop = false;
            // 
            // pbxClamp1Dut
            // 
            this.pbxClamp1Dut.Location = new System.Drawing.Point(339, 181);
            this.pbxClamp1Dut.Name = "pbxClamp1Dut";
            this.pbxClamp1Dut.Size = new System.Drawing.Size(10, 10);
            this.pbxClamp1Dut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxClamp1Dut.TabIndex = 78;
            this.pbxClamp1Dut.TabStop = false;
            this.pbxClamp1Dut.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // pbxClamp1Open
            // 
            this.pbxClamp1Open.Location = new System.Drawing.Point(340, 161);
            this.pbxClamp1Open.Name = "pbxClamp1Open";
            this.pbxClamp1Open.Size = new System.Drawing.Size(10, 10);
            this.pbxClamp1Open.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxClamp1Open.TabIndex = 67;
            this.pbxClamp1Open.TabStop = false;
            this.pbxClamp1Open.Click += new System.EventHandler(this.pbxBlow_Click);
            // 
            // pbxClamp1Closed
            // 
            this.pbxClamp1Closed.Location = new System.Drawing.Point(340, 137);
            this.pbxClamp1Closed.Name = "pbxClamp1Closed";
            this.pbxClamp1Closed.Size = new System.Drawing.Size(10, 10);
            this.pbxClamp1Closed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxClamp1Closed.TabIndex = 66;
            this.pbxClamp1Closed.TabStop = false;
            this.pbxClamp1Closed.Click += new System.EventHandler(this.pbxClose_Click);
            // 
            // pbxBeacon
            // 
            this.pbxBeacon.Location = new System.Drawing.Point(23, 32);
            this.pbxBeacon.Name = "pbxBeacon";
            this.pbxBeacon.Size = new System.Drawing.Size(19, 20);
            this.pbxBeacon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxBeacon.TabIndex = 49;
            this.pbxBeacon.TabStop = false;
            this.pbxBeacon.Click += new System.EventHandler(this.beaconClick);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(536, 214);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 85;
            this.button6.Text = "CAM Log";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(617, 214);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 86;
            this.button7.Text = "AVC Log";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(524, 21);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(21, 12);
            this.label27.TabIndex = 87;
            this.label27.Text = "IP :";
            // 
            // tbxIP
            // 
            this.tbxIP.Location = new System.Drawing.Point(551, 18);
            this.tbxIP.Name = "tbxIP";
            this.tbxIP.Size = new System.Drawing.Size(100, 22);
            this.tbxIP.TabIndex = 88;
            this.tbxIP.Text = "192.168.8.12";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(486, 49);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 12);
            this.label28.TabIndex = 89;
            this.label28.Text = "CAM Port :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(488, 86);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(57, 12);
            this.label29.TabIndex = 90;
            this.label29.Text = "AVC Port :";
            // 
            // tbxCAMPort
            // 
            this.tbxCAMPort.Location = new System.Drawing.Point(551, 46);
            this.tbxCAMPort.Name = "tbxCAMPort";
            this.tbxCAMPort.Size = new System.Drawing.Size(100, 22);
            this.tbxCAMPort.TabIndex = 91;
            this.tbxCAMPort.Text = "49152";
            // 
            // tbxAVCPort
            // 
            this.tbxAVCPort.Location = new System.Drawing.Point(551, 83);
            this.tbxAVCPort.Name = "tbxAVCPort";
            this.tbxAVCPort.Size = new System.Drawing.Size(100, 22);
            this.tbxAVCPort.TabIndex = 92;
            this.tbxAVCPort.Text = "49155";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(563, 124);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 93;
            this.btnConnect.Text = "listen";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.button8_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(192, 259);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 94;
            this.button8.Text = "Reset";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(384, 258);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 95;
            this.button9.Text = "Reset";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(265, 371);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 96;
            this.button10.Text = "Reset";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(461, 361);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(42, 23);
            this.button11.TabIndex = 97;
            this.button11.Text = "Reset";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(523, 361);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(42, 23);
            this.button12.TabIndex = 98;
            this.button12.Text = "Reset";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(316, 79);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(50, 23);
            this.button13.TabIndex = 99;
            this.button13.Text = "Reset";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 419);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.tbxAVCPort);
            this.Controls.Add(this.tbxCAMPort);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.tbxIP);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.pbxRejectLock);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.pbxRejectClosed);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.lblVacuum);
            this.Controls.Add(this.pbxClamp1Dut);
            this.Controls.Add(this.btnUPS);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.pbxClamp1Open);
            this.Controls.Add(this.pbxClamp1Closed);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.pbxBeacon);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "SimRobot";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxNGBuffer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxNGBuffer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxNGBuffer3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxNGBuffer4)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxInBuffer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxInBuffer2)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxProcessBuffer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxProcessBuffer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxProcessBuffer3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxProcessBuffer4)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxGreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRed)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLeft2)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRight4)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxE_Stop)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGoldenDoorLock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGoldenDoorLight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGoldenDoor)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxAudit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAudit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAudit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAudit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRejectLock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRejectClosed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClamp1Dut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClamp1Open)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClamp1Closed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBeacon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList imgIO;
        private System.Windows.Forms.PictureBox pbxNGBuffer4;
        private System.Windows.Forms.PictureBox pbxNGBuffer3;
        private System.Windows.Forms.PictureBox pbxNGBuffer2;
        private System.Windows.Forms.PictureBox pbxNGBuffer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pbxInBuffer1;
        private System.Windows.Forms.PictureBox pbxInBuffer2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.PictureBox pbxProcessBuffer2;
        private System.Windows.Forms.PictureBox pbxProcessBuffer1;
        private System.Windows.Forms.PictureBox pbxProcessBuffer3;
        private System.Windows.Forms.PictureBox pbxProcessBuffer4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox3;
        public System.Windows.Forms.PictureBox pbxGreen;
        public System.Windows.Forms.PictureBox pbxYellow;
        public System.Windows.Forms.PictureBox pbxRed;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbxBeacon;
        private System.Windows.Forms.ImageList imgBeacon;
        private System.Windows.Forms.ImageList imgBuffer;
        private System.Windows.Forms.ImageList imgLight1;
        private System.Windows.Forms.ImageList imgLight0;
        public System.Windows.Forms.PictureBox pbxE_Stop;
        private System.Windows.Forms.Label E_Stop;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tbxSpeed;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.PictureBox pbxLeft4;
        private System.Windows.Forms.PictureBox pbxLeft3;
        private System.Windows.Forms.PictureBox pbxLeft1;
        private System.Windows.Forms.PictureBox pbxLeft2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.PictureBox pbxRight2;
        private System.Windows.Forms.PictureBox pbxRight1;
        private System.Windows.Forms.PictureBox pbxRight3;
        private System.Windows.Forms.PictureBox pbxRight4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pbxClamp1Closed;
        private System.Windows.Forms.PictureBox pbxClamp1Open;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.PictureBox pbxGoldenDoorLight;
        private System.Windows.Forms.Label labLight;
        public System.Windows.Forms.PictureBox pbxGoldenDoor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbxAirPressure;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.PictureBox pbxGoldenDoorLock;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnUPS;
        private System.Windows.Forms.PictureBox pbxClamp1Dut;
        private System.Windows.Forms.Label lblVacuum;
        private System.Windows.Forms.PictureBox pbxLeft7;
        private System.Windows.Forms.PictureBox pbxLeft8;
        private System.Windows.Forms.PictureBox pbxLeft6;
        private System.Windows.Forms.PictureBox pbxLeft5;
        private System.Windows.Forms.PictureBox pbxRight8;
        private System.Windows.Forms.PictureBox pbxRight7;
        private System.Windows.Forms.PictureBox pbxRight6;
        private System.Windows.Forms.PictureBox pbxRight5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.PictureBox pbxAudit3;
        private System.Windows.Forms.PictureBox pbxAudit2;
        private System.Windows.Forms.PictureBox pbxAudit1;
        private System.Windows.Forms.PictureBox pbxAudit4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pbxRejectClosed;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pbxRejectLock;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox tbxIP;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox tbxCAMPort;
        private System.Windows.Forms.TextBox tbxAVCPort;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
    }
}

