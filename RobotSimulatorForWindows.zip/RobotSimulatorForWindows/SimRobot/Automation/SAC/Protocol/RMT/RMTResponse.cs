﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Pegatron.Foundation;
using Pegatron.Foundation.Xml;
using Pegatron.Communication;
using Pegatron.Communication.Socket;

namespace Pegatron.Automation.SAC.Protocol.RMT
{
    public class RMTResponse : EventArgs
    {
        protected List<RMTCommand> mResponses = new List<RMTCommand>();

        public RMTCommand Command
        {
            get;
            protected set;
        }

        public RMTCommand[] Responses
        {
            get
            {
                return this.mResponses.ToArray();
            }
        }

        public RMTResponse(RMTCommand command)
        {
            this.Command = command;
        }

        public void AddResponse(RMTCommand response)
        {
            this.mResponses.Add(response);
        }
    }
}
