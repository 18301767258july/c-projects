﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Management;
using Pegatron.Foundation;
using Pegatron.Communication.Socket;

namespace Pegatron.Automation.SAC.Protocol.PVO
{
    public class PVOResponse
    {
        protected List<PVOCommand> mResponses = new List<PVOCommand>();

        public PVOCommand Command
        {
            get;
            protected set;
        }

        public PVOCommand[] Responses
        {
            get
            {
                return this.mResponses.ToArray();
            }
        }

        public PVOResponse(PVOCommand command)
        {
            this.Command = command;
        }

        public void AddResponse(PVOCommand response)
        {
            this.mResponses.Add(response);
        }
    }
}
