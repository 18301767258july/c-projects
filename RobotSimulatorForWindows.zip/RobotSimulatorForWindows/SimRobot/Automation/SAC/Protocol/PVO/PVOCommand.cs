﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Management;
using Pegatron.Foundation;
using Pegatron.Communication.Socket;

namespace Pegatron.Automation.SAC.Protocol.PVO
{
    public class PVOCommand
    {
        public const int DefaultCommandExpectedReplyCount = 1;

        protected ManualResetEventSlim mWaitReplyFinishedEvent = new ManualResetEventSlim(false);

        protected ManualResetEventSlim mWaitReplyInterruptedEvent = new ManualResetEventSlim(false);

        public WaitHandle ReplyFinishedWaitHandle
        {
            get
            {
                return this.mWaitReplyFinishedEvent.WaitHandle;
            }
        }

        public WaitHandle ReplyInterruptedWaitHandle
        {
            get
            {
                return this.mWaitReplyInterruptedEvent.WaitHandle;
            }
        }

        public bool ReplyFinished
        {
            get
            {
                return this.mWaitReplyFinishedEvent.IsSet;
            }
        }

        public bool ReplyInterrupted
        {
            get
            {
                return this.mWaitReplyInterruptedEvent.IsSet;
            }
        }

        public int ExpectedReplyCount
        {
            get;
            set;
        }

        public string RawData
        {
            get;
            protected set;
        }

        public string Command
        {
            get;
            protected set;
        }

        public string GUID
        {
            get;
            protected set;
        }

        public string StationID
        {
            get;
            protected set;
        }

        public string TesterID
        {
            get;
            protected set;
        }

        public EPVOTesterStatus? TesterStatus
        {
            get;
            protected set;
        }

        public string TestType
        {
            get;
            protected set;
        }

        public string TestStage
        {
            get;
            protected set;
        }

        public PVONest[] Nests
        {
            get;
            protected set;
        }

        public string Version
        {
            get;
            protected set;
        }

        public DateTime Time
        {
            get;
            protected set;
        }

        public PVOCommand(string rawData, string command, string stationID, string testerID, EPVOTesterStatus? testerStatus, string testType, string testStage, string version, params PVONest[] pvoNests)
            : this(rawData, command, PVOUtility.GUID(), stationID, testerID, testerStatus, testType, testStage, version, pvoNests)
        {
        }

        public PVOCommand(string rawData, string command, string guid, string stationID, string testerID, EPVOTesterStatus? testerStatus, string testType, string testStage, string version, params PVONest[] pvoNests)
            : this(rawData, command, guid, stationID, testerID, testerStatus, testType, testStage, version, TimeCounter.Now, pvoNests)
        {
        }

        public PVOCommand(string rawData, string command, string guid, string stationID, string testerID, EPVOTesterStatus? testerStatus, string testType, string testStage, string version, DateTime time, params PVONest[] pvoNests)
            : this(rawData, command, guid, PVOCommand.DefaultCommandExpectedReplyCount, stationID, testerID, testerStatus, testType, testStage, version, time, pvoNests)
        {
        }

        public PVOCommand(string rawData, string command, string guid, int expectedReplyCount, string stationID, string testerID, EPVOTesterStatus? testerStatus, string testType, string testStage, string version, DateTime time, params PVONest[] pvoNests)
        {
            this.RawData = rawData;
            this.Command = command;
            this.GUID = guid;
            this.ExpectedReplyCount = expectedReplyCount;
            this.StationID = stationID;
            this.TesterID = testerID;
            this.TesterStatus = testerStatus;
            this.TestType = testType;
            this.TestStage = testStage;
            this.Nests = pvoNests;
            this.Version = version;
            this.Time = time;
        }

        public void SetReplyFinished()
        {
            this.mWaitReplyFinishedEvent.Set();
        }

        public void SetReplyInterrupted()
        {
            this.mWaitReplyInterruptedEvent.Set();
        }
    }
}
