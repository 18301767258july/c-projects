﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Automation.SAC.Protocol.PVO
{
    public class PVOConstants
    {
        public const string ProtocolVersion             = "1.5";

        /// <summary>
        /// PVOConstants...
        /// </summary>
        public const int MinUdpPort                     = 57800;
        public const int MaxUdpPort                     = 57820;
        public const double BroadcastIntervalSeconds    = 2;
        public const double HeartbeatIntervalSeconds    = 2;
        public const double HeartbeatTimeoutSeconds     = 10;
        public const double ConnectionTimeoutSeconds    = 5;
        public const string DefaultStationID            = "CONTROLLER";
        public const string DefaultSecurityValue        = "000";
        public const string MessageTerminator           = "\r";

        /// <summary>
        /// commands...
        /// </summary>
        public const string HandShakeCommand            = "HAND_SHAKE";
        public const string StartTestCommand            = "START";
        public const string OpenCommand                 = "OPEN";
        public const string AbortTestCommand            = "ABORT";
        public const string QueryStatusCommand          = "QUERY_STATUS";
        public const string UpdateStatusCommand         = "UPDATE_STATUS";
        public const string QueryConfigCommand          = "QUERY_CONFIG";
        public const string UpdateConfigCommand         = "UPDATE_CONFIG";
        public const string DeviceRemovedCommand        = "DEVICE_REMOVED";

        /// <summary>
        /// keys...
        /// </summary>
        public const string CommandKey                  = "Command";
        public const string GUIDKey                     = "GUID";
        public const string ConnectedKey                = "Connected";
        public const string UdpIPKey                    = "UdpIP";
        public const string UdpPortKey                  = "UdpPort";
        public const string TcpIPKey                    = "TcpIP";
        public const string TcpPortKey                  = "TcpPort";
        public const string RoleTypeKey                 = "RoleType";
        public const string StationIDKey                = "StationID";
        public const string BroadcastGUIDKey            = "BroadcastGUID";
        public const string TestStageKey                = "TestStage";
        public const string TestTypeKey                 = "TestType"; 
        public const string TesterIDKey                 = "TesterID";
        public const string TesterStatusKey             = "TesterStatus";
        public const string NestsKey                    = "Nests";
        public const string NestIDKey                   = "NestID";
        public const string NestStatusKey               = "NestStatus";
        public const string UUTIDKey                    = "UUTID";
        public const string ResultCodeKey               = "ResultCode";
        public const string ResultDescKey               = "ResultDescription";
        public const string FailuresKey                 = "Failures";
        public const string ConfigKey                   = "Config";
        public const string SecurityKey                 = "SecurityKey";
        public const string ProtocolVersionKey          = "ProtocolVersion";
        
    }

    public enum EPVORoleType
    {
        Controller = 0,
        Station    = 1,
    }

    public enum EPVONestStatus
    {
        Empty         = 0,
        Occupied      = 1,
        Testing       = 2,
        TestCompleted = 3,
        UnknownStatus = 4,
    }

    public enum EPVOTestResult
    {
        Passed        = 0,
        Failed        = 1,
        Aborted       = 2,
        UnknownResult = 3,
    }

    public enum EPVOTesterStatus
    {
        Ready         = 0,
        NotReady      = 1,
        UnknownStatus = 2,
    }
}
