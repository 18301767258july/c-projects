﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Diagnostics;
using System.Threading;
using Pegatron.Foundation;
using Pegatron.Foundation.Xml;
using Pegatron.Communication;
using Pegatron.Communication.Socket;

namespace Pegatron.Automation.SAC.Protocol.PVO
{

    public class PVOClientConnectionParam : CommConnectionParam
    {
        public const int DefaultConnectionTimeoutMilliseconds = 2000;//2s

        public EPVORoleType RemoteRoleType
        {
            get;
            set;
        }

        public string RemoteStationID
        {
            get;
            set;
        }

        public int TimeoutMilliseconds
        {
            get;
            set;
        }

        public PVOClientConnectionParam(
            EPVORoleType remoteRoleType,
            string remoteStationID,
            int timeoutMilliseconds = PVOClientConnectionParam.DefaultConnectionTimeoutMilliseconds
            )
        {
            this.RemoteRoleType = remoteRoleType;
            this.RemoteStationID = remoteStationID;
            this.TimeoutMilliseconds = timeoutMilliseconds;
        }
    }

    public class PVOClientAsyncRecvParam : CommRecvParam
    {
        public static PVOClientAsyncRecvParam Default
        {
            get
            {
                return new PVOClientAsyncRecvParam(10, true, 2000);
            }
        }

        public int AsyncDelayMilliseconds
        {
            get;
            set;
        }

        public bool IsBackground
        {
            get;
            set;
        }

        public int TimeoutMilliseconds
        {
            get;
            set;
        }

        public PVOClientAsyncRecvParam(int asyncDelayMilliseconds, bool isBackground, int timeoutMilliseconds)
        {
            this.AsyncDelayMilliseconds = asyncDelayMilliseconds;
            this.IsBackground = isBackground;
            this.TimeoutMilliseconds = timeoutMilliseconds;
        }
    }

    public class PVOClientSendParam : CommSendParam
    {
        public KeyValuePair<string, object>[] KeyValues
        {
            get;
            set;
        }

        public int ExpectedReplyCount
        {
            get;
            set;
        }

        public PVOClientSendParam(params KeyValuePair<string, object>[] keyValues)
            : this(true, keyValues)
        {
        }

        public PVOClientSendParam(int expectedReplyCount, params KeyValuePair<string, object>[] keyValues)
        {
            this.KeyValues = keyValues;
            this.ExpectedReplyCount = expectedReplyCount;
        }

        public PVOClientSendParam(bool expectReply, params KeyValuePair<string, object>[] keyValues) : 
            this(expectReply ? 1 : 0, keyValues)
        {
        }
    }

    public class PVOClientSendResult : CommResult
    {
        public PVOCommand Command
        {
            get;
            set;
        }

        public PVOClientSendResult(PVOCommand command, bool result = false, object error = null)
            : base(result, error)
        {
            this.Command = command;
        }
    }

    public class PVOClientRecvParam : CommRecvParam
    {
        public PVOCommand Command
        {
            get;
            set;
        }

        public int TimeoutMilliseconds
        {
            get;
            set;
        }

        public PVOClientRecvParam(PVOCommand command, int timeoutMilliseconds)
        {
            this.Command = command;
            this.TimeoutMilliseconds = timeoutMilliseconds;
        }
    }

    public class PVOClientRecvResult : CommResult
    {
        public PVOCommand Command
        {
            get;
            set;
        }

        public PVOResponse Response
        {
            get;
            set;
        }

        public PVOClientRecvResult()
            : this(null, null)
        {
        }

        public PVOClientRecvResult(PVOCommand command, PVOResponse response, bool result = false, object error = null)
            : base(result, error)
        {
            this.Command = command;
            this.Response = response;
        }
    }

    public class PVOConnectionChangedEventArgs : EventArgs
    {
        public PVOClient Client
        {
            get;
            set;
        }

        public bool Connected
        {
            get;
            set;
        }

        public string Reason
        {
            get;
            set;
        }

        public DateTime Time
        {
            get;
            set;
        }

        public PVOConnectionChangedEventArgs(PVOClient client, bool connected, DateTime time)
            : this(client, connected, null, time)
        {
        }

        public PVOConnectionChangedEventArgs(PVOClient client, bool connected, string reason, DateTime time)
        {
            this.Client = client;
            this.Connected = connected;
            this.Reason = reason;
            this.Time = time;
        }
    }

    public class PVOCommandReceivedEventArgs : EventArgs
    {
        public PVOStation RemoteStation
        {
            get;
            set;
        }

        public PVOCommand Command
        {
            get;
            set;
        }

        public DateTime Time
        {
            get;
            set;
        }

        public PVOCommandReceivedEventArgs(PVOStation remoteStation, PVOCommand command, DateTime time)
        {
            this.RemoteStation = remoteStation;
            this.Command = command;
            this.Time = time;
        }
    }

    public delegate void PVOConnectionChangedEventHandler(object sender, PVOConnectionChangedEventArgs args);

    public delegate void PVOCommandReceivedEventHandler(object sender, PVOCommandReceivedEventArgs args);

    public sealed class PVOClient : IConnectedDevice, ICommunication
    {
        public const string PVOConnectionBadParamError      = "PVO connection bad parameter error";
        public const string PVOWaitConnectionTimeoutError   = "PVO wait connection timeout error";
        public const string PVOConnectionFailed             = "PVO connection failed";
        public const string PVOHandShakeStartError          = "PVO hand shake start error";

        public const string PVOSendBadParamError            = "PVO send bad parameter error";

        public const string PVORecvBadParamError            = "PVO recv bad parameter error";
        public const string PVORecvWaitTimeoutError         = "PVO recv wait timeout error";
        public const string PVORecvInterruptError           = "PVO recv interrupt error";
        public const string PVORecvExpectNoReplyError       = "PVO recv expect no reply error";

        public event PVOConnectionChangedEventHandler ConnectionChanged;

        public event PVOCommandReceivedEventHandler CommandReceived;

        private object mConnectionUpdateSyncRoot = new object();

        private LoopProcessor mHeartbeatProcessor = new LoopProcessor();

        private HashTableManager<string, PVOResponse> mResponseData = new HashTableManager<string, PVOResponse>();
        private HashTableManager<string, PVOCommand> mSendCmdData = new HashTableManager<string, PVOCommand>();

        private HashTableManager<string, SocketTcpClient> mTcpClients = new HashTableManager<string, SocketTcpClient>();
        private HashTableManager<string, string> mTcpClientIncompletePVOMessages = new HashTableManager<string, string>();

        private ManualResetEventSlim mAsyncRecvInterruptEvent = new ManualResetEventSlim(false);
        
        private ManualResetEventSlim mConnectionWaitFinishedEvent = new ManualResetEventSlim(true);


        #region properties
        public PVOClientConnectionParam PVOClientConnectionParam
        {
            get;
            private set;
        }

        public int HeartbeatTimeoutMilliseconds
        {
            get;
            private set;
        }

        public int HeartbeatIntervalMilliseconds
        {
            get;
            private set;
        }

        private bool PreviousConnected
        {
            get;
            set;
        }

        public bool Connected
        {
            get
            {
                bool result = false;
                if (this.LocalStation.Connected)
                {
                    double elapsedSeconds = this.LocalStation.ElapsedSeconds;
                    result = elapsedSeconds < 0 ? false : (elapsedSeconds * 1000 < this.HeartbeatTimeoutMilliseconds);
                }
                return result;
            }
        }

        public PVOStation LocalStation
        {
            get;
            set;
        }

        private SocketTcpServer TcpServer
        {
            get;
            set;
        }

        private SocketUdpClient UdpClient
        {
            get;
            set;
        }

        public Encoding StringEncoding
        {
            get;
            private set;
        }

        private string IncompleteUdpMessage
        {
            get;
            set;
        }
        #endregion

        public PVOClient(PVOStation station, int heartbeatTimeoutMilliseconds, int heartbeatIntervalMilliseconds, Encoding stringEncoding)
        {
            this.mHeartbeatProcessor.LoopHandler = this.Heartbeat;
            this.LocalStation = station;
            this.HeartbeatTimeoutMilliseconds = heartbeatTimeoutMilliseconds;
            this.HeartbeatIntervalMilliseconds = heartbeatIntervalMilliseconds;
            this.StringEncoding = stringEncoding;
            this.PreviousConnected = false;
            this.TcpServer = new SocketTcpServer();
            this.InitClient();
        }

        #region private functions
        private bool InitClient()
        {
            object error = null;
            return this.InitClient(ref error);
        }

        private bool InitClient(ref object error)
        {
            bool result = false;
            try
            {
                this.UdpClient = new SocketUdpClient(new IPEndPoint(IPAddress.Parse(this.LocalStation.UdpIP), 0), true);
                if (this.UdpClient != null)
                {
                    this.LocalStation.UdpIP = this.UdpClient.LocalIP;
                    this.LocalStation.UdpPort = this.UdpClient.LocalPort;
                    CommResult tcpResult = 
                        this.TcpServer.StartService(new SocketTcpServiceStartParam(this.LocalStation.TcpIP, 0), this.OnTcpConnectionReceived);
                    if (tcpResult != null)
                    {
                        if (tcpResult.Result)
                        {
                            this.LocalStation.TcpIP = this.TcpServer.BindingIP;
                            this.LocalStation.TcpPort = this.TcpServer.BindingPort;
                            result = true;
                        }
                        error = tcpResult.Error;
                    }
                }
            }
            catch (System.Exception ex)
            {
                error = ex;
            }
            return result;
        }

        private string CreateTcpClientKey(SocketTcpClient tcpClient)
        {
            return tcpClient.GetHashCode().ToString();
        }

        private void OnTcpConnectionReceived(object sender, CommConnectionReceivedEventArgs connection)
        {
            if (connection != null && connection is SocketTcpConnectionReceivedEventArgs)
            {
                SocketTcpConnectionReceivedEventArgs tcpConnection = connection as SocketTcpConnectionReceivedEventArgs;
                SocketTcpClient tcpClient = tcpConnection.Client as SocketTcpClient;
                if (tcpClient != null)
                {
                    string clientKey = this.CreateTcpClientKey(tcpClient);
                    this.mTcpClients[clientKey] = tcpClient;
                    this.mTcpClientIncompletePVOMessages[clientKey] = null;
                    tcpClient.BeginAsyncRecv(SocketAsyncRecvParam.Default, this.OnTcpDataReceived);
                }
            }
        }

        private void OnTcpDataReceived(object sender, CommDataReceivedEventArgs data)
        {
            SocketDataReceivedEventArgs tcpData = data as SocketDataReceivedEventArgs;
            if (tcpData != null && tcpData.Data != null)
            {
                string newData = this.StringEncoding.GetString(tcpData.Data, 0, tcpData.Bytes);
                if (!string.IsNullOrEmpty(newData))
                {
                    PVOCommand[] commands = null;
                    SocketTcpClient tcpClient = sender as SocketTcpClient;
                    string clientKey = this.CreateTcpClientKey(tcpClient);
                    string incompleteTcpMessage = this.mTcpClientIncompletePVOMessages[clientKey];
                    string rawData = (string.IsNullOrEmpty(incompleteTcpMessage) ? newData : (incompleteTcpMessage + newData));

                    incompleteTcpMessage = null;
                    commands = PVOUtility.CreatePVOCommands(rawData, ref incompleteTcpMessage, tcpData.Time);
                    this.mTcpClientIncompletePVOMessages[clientKey] = incompleteTcpMessage;

                    if (commands != null)
                    {
                        foreach (PVOCommand command in commands)
                        {
                            this.ProcessCommand(command);
                        }
                        if (commands.Length > 0 && string.IsNullOrEmpty(incompleteTcpMessage))
                        {
                            tcpClient.Disconnect();
                            this.mTcpClients.RemoveByKey(clientKey);
                            this.mTcpClientIncompletePVOMessages.RemoveByKey(clientKey);
                        }
                    }
                }
            }
        }

        private void ProcessCommand(PVOCommand recvCommand)
        {
            if (recvCommand != null)
            {
                string commandID = recvCommand.GUID;
                if (this.mSendCmdData.ContainsKey(commandID))
                {
                    PVOCommand sendCommand = this.mSendCmdData[commandID];
                    PVOResponse sendResponse = this.mResponseData[commandID];
                    if (sendResponse == null)
                    {
                        sendResponse = new PVOResponse(sendCommand);
                    }
                    sendResponse.AddResponse(recvCommand);
                    this.mResponseData.SetValueByKey(commandID, sendResponse);
                    if (sendResponse.Responses.Length >= sendCommand.ExpectedReplyCount)
                    {
                        sendCommand.SetReplyFinished();
                        this.mSendCmdData.RemoveByKey(commandID);
                    }
                }
                if (this.CommandReceived != null)
                {
                    this.CommandReceived.Invoke(this, new PVOCommandReceivedEventArgs(this.LocalStation.RemoteStation, recvCommand, recvCommand.Time));
                }
            }
        }

        private void OnUdpDataReceived(object sender, CommDataReceivedEventArgs data)
        {
            SocketDataReceivedEventArgs udpData = data as SocketDataReceivedEventArgs;
            if (udpData != null && udpData.Data != null)
            {
                string newData = this.StringEncoding.GetString(udpData.Data, 0, udpData.Bytes);
                if(!string.IsNullOrEmpty(newData))
                {
                    string rawData = (string.IsNullOrEmpty(this.IncompleteUdpMessage) ? newData : (this.IncompleteUdpMessage + newData));
                    string incompleteUdpMessage = null;
                    PVOHandShake[] handShakes = PVOUtility.CreatePVOHandShakes(rawData, ref incompleteUdpMessage, udpData.Time);
                    this.IncompleteUdpMessage = incompleteUdpMessage;
                    if (handShakes != null)
                    {
                        foreach (PVOHandShake handShake in handShakes)
                        {
                            this.ProcessHandShake(handShake);
                        }
                    }
                }
            }
        }

        private void ProcessHandShake(PVOHandShake handShake)
        {
            if (handShake != null && !string.IsNullOrEmpty(handShake.GUID)
                && handShake.Station != null && handShake.Station.RoleType != this.LocalStation.RoleType)
            {
                if (!this.mConnectionWaitFinishedEvent.IsSet)
                {
                    this.LocalStation.OnRemoteConnected(handShake.Station, handShake.Time);
                    if (this.PVOClientConnectionParam != null && handShake.Station.RoleType == this.PVOClientConnectionParam.RemoteRoleType
                        && handShake.Station.StationID == this.PVOClientConnectionParam.RemoteStationID)
                    {
                        this.UpdateConnection(handShake.Time, "connection received");
                        this.mConnectionWaitFinishedEvent.Set();
                    }
                }
                else
                {
                    if (this.LocalStation.RemoteStation != null)
                    {
                        if (handShake.Station.RoleType == this.LocalStation.RemoteStation.RoleType
                            && handShake.Station.StationID == this.LocalStation.RemoteStation.StationID)
                        {
                            this.LocalStation.OnRemoteConnected(handShake.Station, handShake.Time);
                            if (this.LocalStation.Connected)
                            {
                                if (this.LocalStation.BroadcastGUID != handShake.GUID)
                                {//reply to remote
                                    PVOUtility.HandShakeReply(this.UdpClient, this.LocalStation, handShake.GUID, true);
                                }
                                else
                                {//received connected reply from remote
                                    this.UpdateConnection(handShake.Time, "connection received");
                                }
                            }
                            else
                            {//received disconnected notification from remote
                                this.UpdateConnection(handShake.Time, "disconnection received");
                            }
                        }
                    }
                    else
                    {
                        this.LocalStation.OnRemoteConnected(handShake.Station, handShake.Time);
                    }
                }
            }
        }

        private bool Heartbeat(object arg)
        {
            try
            {
                this.UpdateConnection(TimeCounter.Now, "heartbeat check");
                this.HandShakeRequest(false);
            }
            catch (System.Exception ex)
            {
                ATSException.Logging(ex);
            }
            return true;
        }

        private void UpdateConnection(DateTime time, string reason)
        {
            lock (mConnectionUpdateSyncRoot)
            {
                bool connected = this.Connected;
                if (connected != this.PreviousConnected)
                {
                    try
                    {
                        if (this.ConnectionChanged != null)
                        {
                            this.ConnectionChanged.Invoke(this, new PVOConnectionChangedEventArgs(this, connected, reason, time));
                        }
                    }
                    catch (System.Exception ex)
                    {
                        ATSException.Logging(ex);
                    }
                }
                this.PreviousConnected = connected;
            }
        }

        private bool HandShakeRequest(bool resetRecv = false)
        {
            bool result = false;
            if (this.UdpClient != null)
            {
                if (resetRecv)
                {
                    this.UdpClient.EndAsyncRecv();
                    this.UdpClient.BeginAsyncRecv(SocketAsyncRecvParam.Default, this.OnUdpDataReceived);
                }
                result = PVOUtility.HandShakeRequest(this.UdpClient, this.LocalStation);
            }
            return result;
        }

        private bool HandShakeBroadcast(bool resetRecv = false)
        {
            bool result = false;
            if (this.UdpClient != null)
            {
                if (resetRecv)
                {
                    this.UdpClient.EndAsyncRecv();
                    this.UdpClient.BeginAsyncRecv(SocketAsyncRecvParam.Default, this.OnUdpDataReceived);
                }
                result = PVOUtility.HandShakeBroadcast(this.UdpClient, this.LocalStation);
            }
            return result;
        }
        #endregion

        #region public functions
        public bool StartHeartbeat()
        {
            this.HandShakeRequest(true);
            this.mHeartbeatProcessor.LoopSleepMilliseconds = this.HeartbeatIntervalMilliseconds;
            return this.mHeartbeatProcessor.AsyncExec();
        }

        public void StopHeartbeat()
        {
            this.mHeartbeatProcessor.StopExec();
        }

        public CommResult Connect(CommConnectionParam param)
        {
            CommResult result = new CommResult(false);
            object error = null;
            try
            {
                this.Disconnect();
                if (this.InitClient(ref error))
                {
                    if (param is PVOClientConnectionParam)
                    {
                        this.PVOClientConnectionParam = param as PVOClientConnectionParam;
                        this.mConnectionWaitFinishedEvent.Reset();
                        if (this.HandShakeBroadcast(true))
                        {
                            if (this.mConnectionWaitFinishedEvent.WaitHandle.WaitOne(this.PVOClientConnectionParam.TimeoutMilliseconds))
                            {
                                this.StartHeartbeat();
                                result.Result = true;
                            }
                            else
                            {
                                error = PVOClient.PVOWaitConnectionTimeoutError;
                            }
                        }
                        else
                        {
                            error = PVOClient.PVOHandShakeStartError;
                        }
                    }
                    else
                    {
                        error = PVOClient.PVOConnectionBadParamError;
                    }
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error; 
                if (!result.Result)
                {
                    this.Disconnect();
                }
            }
            return result;
        }

        public void Disconnect()
        {
            try
            {
                this.mAsyncRecvInterruptEvent.Set();
                this.StopHeartbeat();
                if (this.UdpClient != null)
                {
                    this.UdpClient.EndAsyncRecv();
                }
                this.LocalStation.Connected = false;
                PVOUtility.HandShakeReply(this.UdpClient, this.LocalStation, this.LocalStation.BroadcastGUID, false);
                if (this.UdpClient != null)
                {
                    this.UdpClient.Disconnect();
                    this.UdpClient = null;
                }
                this.IncompleteUdpMessage = null;

                if (this.TcpServer != null)
                {
                    this.TcpServer.StopService();
                }

                this.ClearTcpClients();
                this.ClearAllCommands();
            }
            catch (System.Exception)
            {
                this.mAsyncRecvInterruptEvent.Reset();
            }
        }

        private void ClearTcpClients()
        {
            foreach (SocketTcpClient tcpClient in this.mTcpClients.Values)
            {
                tcpClient.Disconnect();
            }
            this.mTcpClients.ClearDevices();
            this.mTcpClientIncompletePVOMessages.ClearDevices();
        }

        private void ClearAllCommands()
        {
            this.mSendCmdData.PerformOnValues(command => command.SetReplyInterrupted());
            this.mSendCmdData.ClearDevices();
            this.mResponseData.ClearDevices();
        }

        public CommResult Send(CommSendParam param)
        {
            PVOClientSendResult result = new PVOClientSendResult(null, false);
            object error = null;
            try
            {
                if (param is PVOClientSendParam)
                {
                    PVOClientSendParam sendParam = param as PVOClientSendParam;
                    PVOCommand sentCommand = this.Send(sendParam.ExpectedReplyCount, sendParam.KeyValues);
                    if (sentCommand != null)
                    {
                        result.Command = sentCommand;
                        result.Result = true;
                    }
                }
                else
                {
                    error = PVOClient.PVOSendBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public PVOCommand Send(int expectedReplyCount, params KeyValuePair<string, object>[] keyValues)
        {
            PVOCommand result = null;
            string pvoMessage = PVOUtility.CreatePVOMessage(keyValues);
            PVOCommand command = PVOUtility.CreatePVOCommand(pvoMessage, TimeCounter.Now);
            if (command != null)
            {
                command.ExpectedReplyCount = expectedReplyCount;
                if (command.ExpectedReplyCount > 0)
                {
                    this.mSendCmdData.SetValueByKey(command.GUID, command);
                }
                if (PVOUtility.TcpSend(this.LocalStation.RemoteStation, pvoMessage))
                {
                    result = command;
                }
                else
                {
                    this.mSendCmdData.RemoveByKey(command.GUID);
                }
            }
            return result;
        }

        public CommResult Recv(CommRecvParam param)
        {
            PVOClientRecvResult result = new PVOClientRecvResult();
            object error = null;
            try
            {
                if (param is PVOClientRecvParam)
                {
                    PVOClientRecvParam recvParam = param as PVOClientRecvParam;
                    result.Response = this.Recv(recvParam.Command, recvParam.TimeoutMilliseconds, ref error);
                    if (result.Response != null)
                    {
                        result.Result = true;
                    }
                }
                else
                {
                    error = PVOClient.PVORecvBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public PVOResponse Recv(PVOCommand command, int timeoutMillisecond, ref object error)
        {
            PVOResponse result = null;
            if (command != null)
            {
                if (command.ExpectedReplyCount > 0)
                {
                    int index = WaitHandle.WaitAny(new WaitHandle[] { command.ReplyFinishedWaitHandle, command.ReplyInterruptedWaitHandle, this.mAsyncRecvInterruptEvent.WaitHandle },
                        timeoutMillisecond);
                    result = this.mResponseData[command.GUID];
                    if (index == 0)
                    {
                        this.mResponseData.RemoveByKey(command.GUID);
                    }
                    else if (index == 1)
                    {
                        error = PVOClient.PVORecvInterruptError;
                    }
                    else if (index == 2)
                    {
                        error = PVOClient.PVORecvInterruptError;
                    }
                    else
                    {
                        error = PVOClient.PVORecvWaitTimeoutError;
                    }
                }
                else
                {
                    error = PVOClient.PVORecvExpectNoReplyError;
                }
            }
            else
            {
                error = PVOClient.PVORecvBadParamError;
            }
            return result;
        }

        public bool WaitUntilReply(string guid, int timeoutMillisecond)
        {
            PVOResponse reply = null;
            return this.WaitUntilReply(guid, timeoutMillisecond, ref reply);
        }

        public bool WaitUntilReply(string guid, int timeoutMillisecond, ref PVOResponse reply)
        {
            object error = null;
            return this.WaitUntilReply(guid, timeoutMillisecond, ref reply, ref error);
        }

        public bool WaitUntilReply(string guid, int timeoutMillisecond, ref PVOResponse reply, ref object error)
        {
            return this.WaitUntilReply(this.mSendCmdData[guid], timeoutMillisecond, ref reply, ref error);
        }

        public bool WaitUntilReply(PVOCommand command, int timeoutMillisecond, ref PVOResponse reply)
        {
            object error = null;
            return this.WaitUntilReply(command, timeoutMillisecond, ref reply, ref error);
        }

        public bool WaitUntilReply(PVOCommand command, int timeoutMillisecond, ref PVOResponse reply, ref object error)
        {
            bool result = false;
            if (command != null)
            {
                reply = this.Recv(command, timeoutMillisecond, ref error);
                result = (reply != null);
            }
            return result;
        }

        public void InterruptRecv(string guid)
        {
            this.InterruptRecv(this.mSendCmdData[guid]);
        }

        public void InterruptRecv(PVOCommand command)
        {
            if (command != null)
            {
                command.SetReplyInterrupted();
            }
        }

        #endregion

        #region commands
        private bool Send(bool expectReply, string guid, string command, string testerID, params int[] nestIDs)
        {
            return this.Send(new PVOClientSendParam(
                expectReply,
                new KeyValuePair<string, object>(PVOConstants.GUIDKey, guid),
                new KeyValuePair<string, object>(PVOConstants.CommandKey, command),
                new KeyValuePair<string, object>(PVOConstants.StationIDKey, this.LocalStation.RemoteStation.StationID),
                new KeyValuePair<string, object>(PVOConstants.TesterIDKey, testerID),
                new KeyValuePair<string, object>(PVOConstants.NestsKey, PVOUtility.CreateDictsByNestIDs(nestIDs)))).Result;
        }

        private bool Send(bool expectReply, string guid, string command, string testerID, string testType, string testStage, params int[] nestIDs)
        {
            return this.Send(new PVOClientSendParam(
                expectReply,
                new KeyValuePair<string, object>(PVOConstants.GUIDKey, guid),
                new KeyValuePair<string, object>(PVOConstants.CommandKey, command),
                new KeyValuePair<string, object>(PVOConstants.StationIDKey, this.LocalStation.RemoteStation.StationID),
                new KeyValuePair<string, object>(PVOConstants.TesterIDKey, testerID),
                new KeyValuePair<string, object>(PVOConstants.TestTypeKey, testType),
                new KeyValuePair<string, object>(PVOConstants.TestStageKey, testStage),
                new KeyValuePair<string, object>(PVOConstants.NestsKey, PVOUtility.CreateDictsByNestIDs(nestIDs)))).Result;
        }

        private bool Send(bool expectReply, string guid, string command, string testerID, string testType, string testStage, params PVONest[] pvoNests)
        {
            return this.Send(new PVOClientSendParam(
                expectReply,
                new KeyValuePair<string, object>(PVOConstants.GUIDKey, guid),
                new KeyValuePair<string, object>(PVOConstants.CommandKey, command),
                new KeyValuePair<string, object>(PVOConstants.StationIDKey, this.LocalStation.RemoteStation.StationID),
                new KeyValuePair<string, object>(PVOConstants.TesterIDKey, testerID),
                new KeyValuePair<string, object>(PVOConstants.TestTypeKey, testType),
                new KeyValuePair<string, object>(PVOConstants.TestStageKey, testStage),
                new KeyValuePair<string, object>(PVOConstants.NestsKey, PVOUtility.CreateDictsByPVONests(pvoNests)))).Result;
        }

        public bool StartTest(string guid, string testerID, string testType, string testStage, params PVONest[] pvoNests)
        {
            return this.Send(true, guid, PVOConstants.StartTestCommand, testerID, testType, testStage, pvoNests);
        }

        public bool Open(string guid, string testerID, string testType, string testStage, params int[] nestIDs)
        {
            return this.Send(true, guid, PVOConstants.OpenCommand, testerID, testType, testStage, nestIDs);
        }

        public bool QueryStatus(string guid, string testerID, string testType, string testStage, params int[] nestIDs)
        {
            return this.Send(true, guid, PVOConstants.QueryStatusCommand, testerID, testType, testStage, nestIDs);
        }

        public bool DeviceRemoved(string guid, string testerID, string testType, string testStage, params int[] nestIDs)
        {
            return this.Send(false, guid, PVOConstants.DeviceRemovedCommand, testerID, testType, testStage, nestIDs);
        }

        public bool AbortTest(string guid, string testerID, string testType, string testStage, params int[] nestIDs)
        {
            return this.Send(false, guid, PVOConstants.AbortTestCommand, testerID, testType, testStage, nestIDs);
        }

        public bool QueryConfig(string guid, string testerID, params int[] nestIDs)
        {
            return this.Send(true, guid, PVOConstants.QueryConfigCommand, testerID, nestIDs);
        }

        public bool UpdateConfig(string guid, string testerID, params PVONest[] pvoNests)
        {
            return this.Send(new PVOClientSendParam(
                false,
                new KeyValuePair<string, object>(PVOConstants.GUIDKey, guid),
                new KeyValuePair<string, object>(PVOConstants.CommandKey, PVOConstants.UpdateConfigCommand),
                new KeyValuePair<string, object>(PVOConstants.StationIDKey, this.LocalStation.StationID),
                new KeyValuePair<string, object>(PVOConstants.TesterIDKey, testerID),
                new KeyValuePair<string, object>(PVOConstants.NestsKey, PVOUtility.CreateDictsByPVONests(pvoNests)))).Result;
        }

        public bool UpdateStatus(string guid, string testerID, EPVOTesterStatus testerStatus, string testType, string testStage, params PVONest[] pvoNests)
        {
            return this.Send(new PVOClientSendParam(
                false,
                new KeyValuePair<string, object>(PVOConstants.GUIDKey, guid),
                new KeyValuePair<string, object>(PVOConstants.CommandKey, PVOConstants.UpdateStatusCommand),
                new KeyValuePair<string, object>(PVOConstants.StationIDKey, this.LocalStation.StationID),
                new KeyValuePair<string, object>(PVOConstants.TesterIDKey, testerID),
                new KeyValuePair<string, object>(PVOConstants.TesterStatusKey, testerStatus),
                new KeyValuePair<string, object>(PVOConstants.TestTypeKey, testType),
                new KeyValuePair<string, object>(PVOConstants.TestStageKey, testStage),
                new KeyValuePair<string, object>(PVOConstants.NestsKey, PVOUtility.CreateDictsByPVONests(pvoNests)))).Result;
        }
        #endregion
    }
}
