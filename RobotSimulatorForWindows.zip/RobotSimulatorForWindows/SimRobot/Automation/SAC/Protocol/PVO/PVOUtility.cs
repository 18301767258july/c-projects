﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Diagnostics;
using System.Threading;
using System.Collections;
using Pegatron.Foundation;
using Pegatron.Foundation.Xml;
using Pegatron.Communication;
using Pegatron.Communication.Socket;

namespace Pegatron.Automation.SAC.Protocol.PVO
{
    internal class PVOUtility
    {
        #region PVO

        public static string GUID()
        {
            return Guid.NewGuid().ToString().ToUpper();
        }

        public static XDict CreatePVODict(string pvoMessage)
        {
            XDict xdict = null;
            if (!pvoMessage.EndsWith(PVOConstants.MessageTerminator))
            {
                xdict = XDict.JsonString2XDict(pvoMessage);
            }
            else
            {
                xdict = XDict.JsonString2XDict(pvoMessage.Substring(0, pvoMessage.Length - PVOConstants.MessageTerminator.Length));
            }
            return xdict;
        }

        public static XDict CreatePVODict(params KeyValuePair<string, object>[] keyValues)
        {
            XDict xdict = new XDict();
            if (keyValues != null && keyValues.Length > 0)
            {
                foreach (KeyValuePair<string, object> keyValue in keyValues)
                {
                    if (keyValue.Value != null)
                    {
                        xdict[keyValue.Key] = keyValue.Value;
                    }
                }
            }
            xdict[PVOConstants.ProtocolVersionKey] = PVOConstants.ProtocolVersion;
            xdict[PVOConstants.SecurityKey] = PVOConstants.DefaultSecurityValue;
            return xdict;
        }

        public static string CreatePVOMessage(params KeyValuePair<string, object>[] keyValues)
        {
            string result = string.Empty;
            if (keyValues != null && keyValues.Length > 0)
            {
                XDict xdict = PVOUtility.CreatePVODict(keyValues);
                if (xdict != null)
                {
                    result = xdict.ToJsonString();
                }
            }
            return result;
        }

        public static string[] CreatePVOMessages(string rawData, ref string incompleteData)
        {
            string[] result = null;
            if (!string.IsNullOrEmpty(rawData))
            {
                string completeData = Utility.SplitOutIncompleteData(rawData, PVOConstants.MessageTerminator, ref incompleteData);
                if (!string.IsNullOrEmpty(completeData))
                {
                    result = Utility.SplitStringWithSeperatorKept(completeData, PVOConstants.MessageTerminator, StringSplitOptions.RemoveEmptyEntries);
                }
            }
            return result;
        }
        #endregion

        #region HandShake
        public static PVOHandShake CreatePVOHandShake(string pvoMessage, DateTime time)
        {
            PVOHandShake result = null;
            if (pvoMessage != null)
            {
                XDict xdict = PVOUtility.CreatePVODict(pvoMessage);
                if (xdict != null)
                {
                    PVOStation pvoStation = new PVOStation(
                            (EPVORoleType)xdict.GetIntValueByKey(PVOConstants.RoleTypeKey, (int)EPVORoleType.Controller),
                            xdict.GetStringValueByKey(PVOConstants.StationIDKey),
                            xdict.GetStringValueByKey(PVOConstants.BroadcastGUIDKey),
                            xdict.GetStringValueByKey(PVOConstants.TcpIPKey),
                            xdict.GetIntValueByKey(PVOConstants.TcpPortKey, 0),
                            xdict.GetStringValueByKey(PVOConstants.UdpIPKey),
                            xdict.GetIntValueByKey(PVOConstants.UdpPortKey, 0),
                            xdict.GetBoolValueByKey(PVOConstants.ConnectedKey, false)
                            );
                    result = new PVOHandShake(
                        pvoMessage,
                        xdict.GetStringValueByKey(PVOConstants.CommandKey),
                        xdict.GetStringValueByKey(PVOConstants.GUIDKey),
                        pvoStation,
                        xdict.GetStringValueByKey(PVOConstants.ProtocolVersionKey),
                        time);
                }
            }
            return result;
        }

        public static PVOHandShake[] CreatePVOHandShakes(string rawData, ref string incompleteData, DateTime time)
        {
            List<PVOHandShake> result = new List<PVOHandShake>();
            string[] pvoMessages = PVOUtility.CreatePVOMessages(rawData, ref incompleteData);
            if (pvoMessages != null)
            {
                foreach (string pvoMessage in pvoMessages)
                {
                    result.Add(PVOUtility.CreatePVOHandShake(pvoMessage, time));
                }
            }
            return result.ToArray();
        }

        public static string CreateHandShakePVOMessage(PVOStation pvoStation, string guid, bool connected)
        {
            return PVOUtility.CreatePVOMessage(
                        new KeyValuePair<string, object>(PVOConstants.GUIDKey, guid),
                        new KeyValuePair<string, object>(PVOConstants.CommandKey, PVOConstants.HandShakeCommand),
                        new KeyValuePair<string, object>(PVOConstants.RoleTypeKey, pvoStation.RoleType),
                        new KeyValuePair<string, object>(PVOConstants.StationIDKey, pvoStation.StationID),
                        new KeyValuePair<string, object>(PVOConstants.BroadcastGUIDKey, pvoStation.BroadcastGUID),
                        new KeyValuePair<string, object>(PVOConstants.UdpIPKey, pvoStation.UdpIP),
                        new KeyValuePair<string, object>(PVOConstants.UdpPortKey, pvoStation.UdpPort),
                        new KeyValuePair<string, object>(PVOConstants.TcpIPKey, pvoStation.TcpIP),
                        new KeyValuePair<string, object>(PVOConstants.TcpPortKey, pvoStation.TcpPort),
                        new KeyValuePair<string, object>(PVOConstants.ConnectedKey, connected));
        }

        public static bool UdpSend(SocketUdpClient udpClient, IPEndPoint remoteEP, string message)
        {
            bool result = false;
            if (remoteEP != null && message != null && udpClient != null)
            {
                if (!string.IsNullOrEmpty(message))
                {
                    result = udpClient.Send(
                        new SocketStringSendParam(message, PVOConstants.MessageTerminator, remoteEP)
                        ).Result;
                    if (result)
                    {
                        Console.WriteLine("UDP SENT:" + message);
                    }
                    else
                    {
                        Console.WriteLine("UDP SEND FAILED:" + message);
                    }
                }
            }
            return result;
        }

        public static bool UdpSend(SocketUdpClient udpClient, string remoteIP, string message)
        {
            bool result = true;
            for (int remotePort = PVOConstants.MinUdpPort; remotePort <= PVOConstants.MaxUdpPort; remotePort++)
            {
                if (!PVOUtility.UdpSend(udpClient, new IPEndPoint(IPAddress.Parse(remoteIP), remotePort), message))
                {
                    result = false;
                }
            }
            return result;
        }

        public static bool UdpHandShake(SocketUdpClient udpClient, PVOStation pvoStation, IPEndPoint remoteEP, bool connected)
        {
            return PVOUtility.UdpSend(udpClient, remoteEP, PVOUtility.CreateHandShakePVOMessage(pvoStation, pvoStation.BroadcastGUID, connected));
        }

        public static bool UdpHandShake(SocketUdpClient udpClient, PVOStation pvoStation, string remoteIP, bool connected)
        {
            return PVOUtility.UdpSend(udpClient, remoteIP, PVOUtility.CreateHandShakePVOMessage(pvoStation, pvoStation.BroadcastGUID, connected));
        }

        public static bool UdpHandShake(SocketUdpClient udpClient, PVOStation pvoStation, IPEndPoint remoteEP, string guid, bool connected)
        {
            return PVOUtility.UdpSend(udpClient, remoteEP, PVOUtility.CreateHandShakePVOMessage(pvoStation, guid, connected));
        }

        public static bool UdpHandShake(SocketUdpClient udpClient, PVOStation pvoStation, string remoteIP, string guid, bool connected)
        {
            return PVOUtility.UdpSend(udpClient, remoteIP, PVOUtility.CreateHandShakePVOMessage(pvoStation, guid, connected));
        }

        public static bool HandShakeBroadcast(SocketUdpClient udpClient, PVOStation pvoStation)
        {
            return PVOUtility.HandShakeToRemote(udpClient, pvoStation, pvoStation.BroadcastGUID, true, true, true);
        }

        public static bool HandShakeRequest(SocketUdpClient udpClient, PVOStation pvoStation)
        {
            return PVOUtility.HandShakeToRemote(udpClient, pvoStation, pvoStation.BroadcastGUID, true, false, true);
        }

        public static bool HandShakeReply(SocketUdpClient udpClient, PVOStation pvoStation, string guid, bool connected = true)
        {
            return PVOUtility.HandShakeToRemote(udpClient, pvoStation, guid, connected, false, false);
        }

        public static bool HandShakeToRemote(SocketUdpClient udpClient, PVOStation pvoStation, string guid, bool connected = true, bool broadcast = false, bool expectReply = true)
        {
            bool result = false;
            if (udpClient != null && pvoStation != null)
            {
                if (broadcast)
                {
                    string broadcastIP = Network.GetBroadcastIPAddress(pvoStation.UdpIP);
                    result = PVOUtility.UdpHandShake(
                        udpClient,
                        pvoStation,
                        broadcastIP,
                        guid,
                        connected);
                }
                else
                {
                    if (pvoStation.RemoteStation != null)
                    {
                        result = PVOUtility.UdpHandShake(
                            udpClient,
                            pvoStation,
                            new IPEndPoint(IPAddress.Parse(pvoStation.RemoteStation.UdpIP), pvoStation.RemoteStation.UdpPort),
                            guid,
                            connected);
                    }
                }
                if (result)
                {
                    pvoStation.UpdateHandShakeSent(TimeCounter.Now, expectReply);
                }
                else
                {//send failed
                    pvoStation.UpdateHandShakeReceived(null);
                }
            }
            return result;
        }
        
        #endregion

        #region CommandTest
        public static PVOCommand CreatePVOCommand(DateTime time, params KeyValuePair<string, object>[] keyValues)
        {
            PVOCommand result = null;
            if (keyValues != null)
            {
                result = PVOUtility.CreatePVOCommand(PVOUtility.CreatePVOMessage(keyValues), time);
            }
            return result;
        }

        public static PVOCommand CreatePVOCommand(string pvoMessage, DateTime time)
        {
            PVOCommand result = null;
            if (pvoMessage != null)
            {
                XDict xdict = PVOUtility.CreatePVODict(pvoMessage);
                if (xdict != null)
                {
                    result = new PVOCommand(
                        pvoMessage,
                        xdict.GetStringValueByKey(PVOConstants.CommandKey),
                        xdict.GetStringValueByKey(PVOConstants.GUIDKey),
                        xdict.GetStringValueByKey(PVOConstants.StationIDKey),
                        xdict.GetStringValueByKey(PVOConstants.TesterIDKey),
                        (EPVOTesterStatus)xdict.GetIntValueByKey(PVOConstants.TesterStatusKey, (int)EPVOTesterStatus.Ready),
                        xdict.GetStringValueByKey(PVOConstants.TestTypeKey),
                        xdict.GetStringValueByKey(PVOConstants.TestStageKey),
                        xdict.GetStringValueByKey(PVOConstants.ProtocolVersionKey),
                        time,
                        PVOUtility.CreatePVONestsByDicts(xdict[PVOConstants.NestsKey] as ArrayList)
                            );
                }
            }
            return result;
        }

        public static PVOCommand[] CreatePVOCommands(string rawData, ref string incompleteData, DateTime time)
        {
            List<PVOCommand> result = new List<PVOCommand>();
            string[] pvoMessages = PVOUtility.CreatePVOMessages(rawData, ref incompleteData);
            if (pvoMessages != null)
            {
                foreach (string pvoMessage in pvoMessages)
                {
                    result.Add(PVOUtility.CreatePVOCommand(pvoMessage, time));
                }
            }
            return result.ToArray();
        }

        public static XDict[] CreateDictsByNestIDs(params int[] nestIDs)
        {
            List<XDict> nestDicts = new List<XDict>();
            if (nestIDs != null && nestIDs.Length > 0)
            {
                foreach (int nestID in nestIDs)
                {
                    nestDicts.Add(new XDict(PVOConstants.NestIDKey, nestID));
                }
            }
            return nestDicts.ToArray();
        }

        public static XDict[] CreateDictsByPVONests(params PVONest[] pvoNests)
        {
            List<XDict> nestDicts = new List<XDict>();
            if (pvoNests != null && pvoNests.Length > 0)
            {
                foreach (PVONest pvoNest in pvoNests)
                {
                    XDict xdict = new XDict();
                    xdict[PVOConstants.NestIDKey] = pvoNest.NestID;
                    xdict[PVOConstants.ConfigKey] = pvoNest.Config;
                    xdict[PVOConstants.NestStatusKey] = pvoNest.NestStatus;
                    xdict[PVOConstants.UUTIDKey] = pvoNest.UUTID;
                    xdict[PVOConstants.ResultCodeKey] = pvoNest.ResultCode;
                    xdict[PVOConstants.ResultDescKey] = pvoNest.ResultDesc;
                    xdict[PVOConstants.FailuresKey] = pvoNest.Failures;
                    nestDicts.Add(xdict);
                }
            }
            return nestDicts.ToArray();
        }

        public static PVONest[] CreatePVONestsByDicts(params XDict[] nestDicts)
        {
            List<PVONest> pvoNests = new List<PVONest>();
            foreach (XDict nestDict in nestDicts)
            {
                pvoNests.Add(new PVONest(
                    nestDict.GetIntValueByKey(PVOConstants.NestIDKey, -1),
                    nestDict[PVOConstants.ConfigKey],
                    nestDict.ContainsKey(PVOConstants.NestStatusKey) ? (EPVONestStatus?)nestDict.GetIntValueByKey(PVOConstants.NestStatusKey, (int)EPVONestStatus.Empty) : null,
                    nestDict.GetStringValueByKey(PVOConstants.UUTIDKey),
                    nestDict.ContainsKey(PVOConstants.ResultCodeKey) ? (EPVOTestResult?)nestDict.GetIntValueByKey(PVOConstants.ResultCodeKey, (int)EPVOTestResult.Passed) : null,
                    nestDict.GetStringValueByKey(PVOConstants.ResultDescKey),
                    nestDict[PVOConstants.FailuresKey] as string[]));
            }
            return pvoNests.ToArray();
        }

        public static PVONest[] CreatePVONestsByDicts(ArrayList nestArray)
        {
            List<PVONest> pvoNests = new List<PVONest>();
            if (nestArray != null)
            {
                foreach (object nest in nestArray)
                {
                    XDict nestDict = new XDict(nest as Dictionary<string, object>);
                    List<string> failuresList = new List<string>();
                    if (nestDict[PVOConstants.FailuresKey] != null)
                    {
                        foreach (object failure in nestDict[PVOConstants.FailuresKey] as ArrayList)
                        {
                            failuresList.Add(failure as string);
                        }
                    }
                    pvoNests.Add(new PVONest(
                       nestDict.GetIntValueByKey(PVOConstants.NestIDKey, -1),
                       nestDict[PVOConstants.ConfigKey],
                       nestDict.ContainsKey(PVOConstants.NestStatusKey) ? (EPVONestStatus?)nestDict.GetIntValueByKey(PVOConstants.NestStatusKey, (int)EPVONestStatus.Empty) : null,
                       nestDict.GetStringValueByKey(PVOConstants.UUTIDKey),
                       nestDict.ContainsKey(PVOConstants.ResultCodeKey) ? (EPVOTestResult?)nestDict.GetIntValueByKey(PVOConstants.ResultCodeKey, (int)EPVOTestResult.Passed) : null,
                       nestDict.GetStringValueByKey(PVOConstants.ResultDescKey),
                       failuresList.ToArray()));

                }
            }
            return pvoNests.ToArray();
        }

        public static bool TcpSend(PVOStation pvoStation, params KeyValuePair<string, object>[] keyValues)
        {
            return PVOUtility.TcpSend(pvoStation, PVOUtility.CreatePVOMessage(keyValues));
        }

        public static bool TcpSend(PVOStation pvoStation, string pvoMessage)
        {
            bool result = false;
            if (!string.IsNullOrEmpty(pvoMessage) && pvoStation != null)
            {
                SocketTcpClient tcpClient = new SocketTcpClient();
                CommResult tcpResult = tcpClient.Connect(
                    new SocketConnectionParam(pvoStation.TcpIP, pvoStation.TcpPort, (int)(PVOConstants.ConnectionTimeoutSeconds * 1000)));
                if (tcpResult != null && tcpResult.Result)
                {
                    tcpResult = tcpClient.Send(new SocketStringSendParam(pvoMessage, PVOConstants.MessageTerminator));
                }
                result = tcpResult != null && tcpResult.Result;
                if (result)
                {
                    Console.WriteLine("TCP SENT:" + pvoMessage);
                }
                else
                {
                    Console.WriteLine("TCP SEND FAILED:" + pvoMessage);
                }
                tcpClient.Disconnect();
            }
            return result;
        }
        #endregion
    }
}
