﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Management;
using System.Collections;
using Pegatron.Foundation;
using Pegatron.Foundation.Xml;
using Pegatron.Communication;
using Pegatron.Communication.Socket;

namespace Pegatron.Automation.SAC.Protocol.PVO
{
    public class PVOServiceStartParam : CommServiceStartParam
    {
        public string Interface
        {
            get;
            set;
        }

        public EPVORoleType RoleType
        {
            get;
            set;
        }

        public string StationID
        {
            get;
            set;
        }

        public PVOServiceStartParam(string interfaceName, EPVORoleType roleType, string stationID)
        {
            this.Interface = interfaceName;
            this.RoleType = roleType;
            this.StationID = stationID;
        }
    }

    public sealed class PVOService : IServiceDevice
    {
        #region fields
        
        public const string PVOServiceStartBadParamError           = "PVO service start bad parameter error";
        public const string PVOServiceInvalidIPError               = "PVO service invalid ip error";
        public const string PVOServiceBroadcastInitialSendingError = "PVO service broadcast initial sending error";
        public const string PVOServiceBroadcastServiceStartError   = "PVO service broadcast service start error";
        public const string PVOServiceStillRunningError            = "PVO service still running error";

        private object mMainSyncRoot = new object();
        private object mUdpSyncRoot = new object();
        private HashTableManager<string, PVOClient> mPVOClients = new HashTableManager<string, PVOClient>();
        private HashTableManager<string, string> mUdpClientIncompletePVOMessages = new HashTableManager<string, string>();

        private LoopProcessor mBroadcastService = new LoopProcessor();
        private event CommConnectionReceivedCallback CommConnectionReceived;

        /// <summary>
        /// connection received
        /// </summary>
        public event PVOConnectionChangedEventHandler PVOConnectionChanged;
        /// <summary>
        /// command received
        /// </summary>
        public event PVOCommandReceivedEventHandler PVOCommandReceived;
        
        #endregion

        #region properties

        public bool ServiceRunning 
        { 
            get
            {
                return this.mBroadcastService.Running;
            }
        }

        public PVOStation ServerStation
        {
            get;
            private set;
        }

        public Encoding StringEncoding
        {
            get;
            set;
        }

        private SocketUdpClient UdpClient
        {
            get;
            set;
        }

        #endregion

        #region constructor

        public PVOService()
        {
            this.mBroadcastService.LoopHandler = this.Broadcast;
            this.mBroadcastService.LoopSleepMilliseconds = (int)(PVOConstants.BroadcastIntervalSeconds * 1000);
            this.StringEncoding = Encoding.ASCII;
        }
        #endregion

        #region private functions

        private PVOClient[] GetClientsByLocalStationID(string stationID)
        {
            List<PVOClient> result = new List<PVOClient>();
            lock (mUdpSyncRoot)
            {
                foreach (string key in mPVOClients.Keys)
                {
                    PVOClient pvoClient = mPVOClients[key];
                    if (pvoClient != null && pvoClient.LocalStation.StationID == stationID)
                    {
                        result.Add(pvoClient);
                    }
                }
            }
            return result.ToArray();
        }

        private void ClearPVOClients()
        {
            lock (mUdpSyncRoot)
            {
                foreach (string key in mPVOClients.Keys)
                {
                    PVOClient pvoClient = mPVOClients[key];
                    if (pvoClient != null)
                    {
                        pvoClient.Disconnect();
                    }
                }
                this.mPVOClients.ClearDevices();
            }
        }

        private bool Broadcast(object arg)
        {
            try
            {
                PVOUtility.HandShakeBroadcast(this.UdpClient, this.ServerStation);
            }
            catch (System.Exception ex)
            {
                ATSException.Logging(ex);
            }
            return true;
        }

        private bool InitUdpClient(string ip, ref object error)
        {
            bool result = false;
            if (!string.IsNullOrEmpty(ip))
            {
                if (this.UdpClient == null || this.UdpClient.LocalIP != ip)
                {
                    for (int localPort = PVOConstants.MinUdpPort; localPort <= PVOConstants.MaxUdpPort; localPort++)
                    {
                        try
                        {
                            if ((this.UdpClient = new SocketUdpClient(new IPEndPoint(IPAddress.Parse(ip), localPort), true)) != null)
                            {
                                error = null;
                                result = true;
                                break;
                            }
                        }
                        catch (System.Exception ex)
                        {
                            error = ex;
                            ATSException.Logging(ex);
                        }
                    }
                }
                else
                {
                    result = true;
                }
            }
            else
            {
                error = PVOService.PVOServiceInvalidIPError;
            }
            return result;
        }

        private void OnConnectionChanged(object sender, PVOConnectionChangedEventArgs args)
        {
            if (args != null)
            {
                if (this.PVOConnectionChanged != null)
                {
                    this.PVOConnectionChanged.BeginInvoke(this, args, null, null);
                }
                if (this.CommConnectionReceived != null)
                {
                    this.CommConnectionReceived.BeginInvoke(this, new CommConnectionReceivedEventArgs(args.Client, this, args.Time, args.Connected), null, null);
                }
            }
        }

        private void OnCommandReceived(object sender, PVOCommandReceivedEventArgs args)
        {
            if (args != null)
            {
                if (this.PVOCommandReceived != null)
                {
                    this.PVOCommandReceived.Invoke(this, args);
                }
            }
        }

        private void OnUdpDataReceived(object sender, CommDataReceivedEventArgs data)
        {
            SocketDataReceivedEventArgs udpData = data as SocketDataReceivedEventArgs;
            if (udpData != null && udpData.Data != null && udpData.RemoteEndPoint != null)
            {
                string newData = this.StringEncoding.GetString(udpData.Data, 0, udpData.Bytes);
                if (!string.IsNullOrEmpty(newData))
                {
                    string remoteKey = udpData.RemoteEndPoint.ToString();
                    string incompleteUdpMessage = this.mUdpClientIncompletePVOMessages[remoteKey];
                    string rawData = (string.IsNullOrEmpty(incompleteUdpMessage) ? newData : (incompleteUdpMessage + newData));

                    incompleteUdpMessage = null;
                    PVOHandShake[] handShakes = PVOUtility.CreatePVOHandShakes(rawData, ref incompleteUdpMessage, udpData.Time);
                    this.mUdpClientIncompletePVOMessages[remoteKey] = incompleteUdpMessage;

                    if (handShakes != null)
                    {
                        foreach (PVOHandShake handShake in handShakes)
                        {
                            this.ProcessHandShake(handShake);
                        }
                    }
                }
            }
        }

        private void ProcessHandShake(PVOHandShake handShake)
        {
            if (handShake != null && !string.IsNullOrEmpty(handShake.GUID)
                && handShake.Station != null && handShake.Station.RoleType != this.ServerStation.RoleType)
            {
                PVOStation pvoStation = new PVOStation(this.ServerStation);
                pvoStation.OnRemoteConnected(handShake.Station, handShake.Time);
                //lock (mUdpSyncRoot)
                {
                    string stationID = pvoStation.RemoteStation.StationID;
                    PVOClient oldClient = this.mPVOClients[stationID];
                    if (oldClient == null || !oldClient.Connected)
                    {
                        if (oldClient != null)
                        {
                            oldClient.Disconnect();
                        }
                        PVOClient pvoClient = new PVOClient(pvoStation,
                            (int)(PVOConstants.HeartbeatTimeoutSeconds * 1000),
                            (int)(PVOConstants.HeartbeatIntervalSeconds * 1000),
                            this.StringEncoding);
                        pvoClient.ConnectionChanged += this.OnConnectionChanged;
                        pvoClient.CommandReceived += this.OnCommandReceived;
                        pvoClient.StartHeartbeat();
                        this.mPVOClients[stationID] = pvoClient;
                    }
                }
            }
        }

        #endregion

        #region GUID
        public static string GUID()
        {
            return PVOUtility.GUID();
        }
        #endregion

        #region start / stop service

        public CommResult StartService(CommServiceStartParam param, CommConnectionReceivedCallback connectionCallback)
        {
            CommResult result = new CommResult(false);
            object error = null;
            try
            {
                if (param is PVOServiceStartParam)
                {
                    PVOServiceStartParam pvoServiceStartParam = param as PVOServiceStartParam;
                    this.CommConnectionReceived += connectionCallback;
                    result.Result = this.StartService(
                                pvoServiceStartParam.Interface,
                                pvoServiceStartParam.RoleType,
                                pvoServiceStartParam.StationID,
                                ref error);
                }
                else
                {
                    error = PVOService.PVOServiceStartBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public bool StartService(string interfaceName, ref object error)
        {
            return this.StartService(interfaceName, EPVORoleType.Controller, PVOConstants.DefaultStationID, ref error);
        }

        public bool StartService(string interfaceName, string stationID, ref object error)
        {
            return this.StartService(interfaceName, EPVORoleType.Station, stationID, ref error);
        }

        public bool StartService(string interfaceName, EPVORoleType roleType, string stationID, ref object error)
        {
            bool result = false;
            lock (mMainSyncRoot)
            {
                try
                {
                    this.StopService();
                    if (!this.ServiceRunning)
                    {
                        string interfaceIP = Network.GetIPByPrefix(interfaceName);
                        if (this.InitUdpClient(interfaceIP, ref error))
                        {
                            this.ServerStation = new PVOStation(roleType, stationID, PVOService.GUID(),
                                    interfaceIP, 0,
                                    this.UdpClient.LocalIP, this.UdpClient.LocalPort, true);
                            this.UdpClient.EndAsyncRecv();
                            this.UdpClient.BeginAsyncRecv(SocketAsyncRecvParam.Default, this.OnUdpDataReceived);
                            if (this.Broadcast(null))
                            {
                                if (!(result = this.mBroadcastService.AsyncExec()))
                                {
                                    error = PVOService.PVOServiceBroadcastServiceStartError;
                                }
                            }
                            else
                            {
                                error = PVOService.PVOServiceBroadcastInitialSendingError;
                            }
                        }
                    }
                    else
                    {
                        error = PVOService.PVOServiceBroadcastInitialSendingError;
                    }
                }
                catch (System.Exception ex)
                {
                    error = ex;
                    result = false;
                }
                finally
                {
                    if (!result)
                    {
                        this.StopService();
                    }
                }
            }
            return result;
        }

        public void StopService()
        {
            this.StopService(true);
        }

        public void StopService(bool releasePort)
        {
            lock (mMainSyncRoot)
            {
                this.mBroadcastService.StopExec();

                if (this.UdpClient != null)
                {
                    this.UdpClient.EndAsyncRecv();
                }

                this.ClearPVOClients();

                this.CommConnectionReceived = null;

                this.mUdpClientIncompletePVOMessages.ClearDevices();

                if (releasePort)
                {
                    if (this.UdpClient != null)
                    {
                        this.UdpClient.Disconnect();
                        this.UdpClient = null;
                    }
                }
            }
        }

        #endregion

        #region find stations
        public string[] ConnectedStations
        {
            get
            {
                List<string> stationIDs = new List<string>();
                lock (mUdpSyncRoot)
                {
                    foreach (string key in mPVOClients.Keys)
                    {
                        PVOClient pvoClient = mPVOClients[key];
                        if (pvoClient != null && pvoClient.Connected)
                        {
                            stationIDs.Add(key);
                        }
                    }
                }
                return stationIDs.ToArray();
            }
        }

        public string[] DisconnectedStations
        {
            get
            {
                List<string> stationIDs = new List<string>();
                lock (mUdpSyncRoot)
                {
                    foreach (string key in mPVOClients.Keys)
                    {
                        PVOClient pvoClient = mPVOClients[key];
                        if (pvoClient != null && !pvoClient.Connected)
                        {
                            stationIDs.Add(key);
                        }
                    }
                }
                return stationIDs.ToArray();
            }
        }
        #endregion

        #region commands
        public bool WaitUntilReply(string stationID, string guid, int timeoutMillisecond)
        {
            PVOResponse reply = null;
            return this.WaitUntilReply(stationID, guid, timeoutMillisecond, ref reply);
        }

        public bool WaitUntilReply(string stationID, string guid, int timeoutMillisecond, ref PVOResponse reply)
        {
            bool result = false;
            PVOClient client = this.mPVOClients[stationID];
            if (client != null)
            {
                result = client.WaitUntilReply(guid, timeoutMillisecond, ref reply);
            }
            return result;
        }

        public bool StartTest(string stationID, string guid, string testerID, string testType, string testStage, params PVONest[] pvoNests)
        {
            bool result = false;
            PVOClient client = this.mPVOClients[stationID];
            if (client != null)
            {
                result = client.StartTest(guid, testerID, testType, testStage, pvoNests);
            }
            return result;
        }

        public bool Open(string stationID, string guid, string testerID, string testType, string testStage, params int[] nestIDs)
        {
            bool result = false;
            PVOClient client = this.mPVOClients[stationID];
            if (client != null)
            {
                result = client.Open(guid, testerID, testType, testStage, nestIDs);
            }
            return result;
        }

        public bool QueryStatus(string stationID, string guid, string testerID, string testType, string testStage, params int[] nestIDs)
        {
            bool result = false;
            PVOClient client = this.mPVOClients[stationID];
            if (client != null)
            {
                result = client.QueryStatus(guid, testerID, testType, testStage, nestIDs);
            }
            return result;
        }

        public bool UpdateStatus(string stationID, string guid, string testerID, EPVOTesterStatus testerStatus, string testType, string testStage, params PVONest[] pvoNests)
        {
            bool result = true;
            PVOClient[] clients = this.GetClientsByLocalStationID(stationID);
            if (clients != null && clients.Length > 0)
            {
                foreach (PVOClient client in clients)
                {
                    if (!client.UpdateStatus(guid, testerID, testerStatus, testType, testStage, pvoNests))
                    {
                        result = false;
                    }
                }
            }
            return result;
        }
        
        public bool DeviceRemoved(string stationID, string guid, string testerID, string testType, string testStage, params int[] nestIDs)
        {
            bool result = false;
            PVOClient client = this.mPVOClients[stationID];
            if (client != null)
            {
                result = client.DeviceRemoved(guid, testerID, testType, testStage, nestIDs);
            }
            return result;
        }

        public bool AbortTest(string stationID, string guid, string testerID, string testType, string testStage, params int[] nestIDs)
        {
            bool result = false;
            PVOClient client = this.mPVOClients[stationID];
            if (client != null)
            {
                result = client.AbortTest(guid, testerID, testType, testStage, nestIDs);
            }
            return result;
        }

        public bool QueryConfig(string stationID, string guid, string testerID, params int[] nestIDs)
        {
            bool result = false;
            PVOClient client = this.mPVOClients[stationID];
            if (client != null)
            {
                result = client.QueryConfig(guid, testerID, nestIDs);
            }
            return result;
        }

        public bool UpdateConfig(string stationID, string guid, string testerID, params PVONest[] pvoNests)
        {
            bool result = true;
            PVOClient[] clients = this.GetClientsByLocalStationID(stationID);
            if (clients != null && clients.Length > 0)
            {
                foreach (PVOClient client in clients)
                {
                    if (!client.UpdateConfig(guid, testerID, pvoNests))
                    {
                        result = false;
                    }
                }
            }
            return result;
        }

        #endregion
    }
}
