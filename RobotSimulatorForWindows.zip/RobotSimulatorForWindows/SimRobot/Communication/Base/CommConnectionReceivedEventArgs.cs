﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Communication
{
    public class CommConnectionReceivedEventArgs : EventArgs
    {
        public IConnectedDevice Client
        {
            get;
            set;
        }

        public IServiceDevice Server
        {
            get;
            set;
        }

        public bool Connected
        {
            get;
            set;
        }

        public DateTime Time
        {
            get;
            set;
        }

        public CommConnectionReceivedEventArgs(IConnectedDevice client, IServiceDevice server, DateTime time, bool connected)
        {
            this.Client = client;
            this.Server = server;
            this.Time = time;
            this.Connected = connected;
        }
    }
}
