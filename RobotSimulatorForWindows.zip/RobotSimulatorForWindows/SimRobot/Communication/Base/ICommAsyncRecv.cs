﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Communication
{
    public interface ICommAsyncRecv
    {
        bool AsyncReceiving
        {
            get;
        }

        CommResult BeginAsyncRecv(CommRecvParam param, CommDataReceivedCallback asyncReceivedCallback);

        void EndAsyncRecv();
    }
}
