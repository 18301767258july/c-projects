﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Communication
{
    public class CommConnectionChangedEventArgs : EventArgs
    {
        public IConnectedDevice Device
        {
            get;
            set;
        }

        public bool Connected
        {
            get;
            set;
        }

        public string Reason
        {
            get;
            set;
        }

        public DateTime Time
        {
            get;
            set;
        }

        public CommConnectionChangedEventArgs(IConnectedDevice device, bool connected, DateTime time)
            :this(device, connected, null, time)
        {
        }

        public CommConnectionChangedEventArgs(IConnectedDevice device, bool connected, string reason, DateTime time)
        {
            this.Device = device;
            this.Connected = connected;
            this.Reason = reason;
            this.Time = time;
        }
    }
}
