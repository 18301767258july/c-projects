﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Diagnostics;
using System.Threading;
using Pegatron.Foundation;
using Pegatron.Communication;

namespace Pegatron.Communication.Socket
{

    public class SocketConnectionParam : CommConnectionParam
    {
        public const int DefaultConnectionTimeoutMilliseconds = 5000;

        public string RemoteIP
        {
            get;
            set;
        }

        public int RemotePort
        {
            get;
            set;
        }

        public int TimeoutMilliseconds
        {
            get;
            set;
        }

        public SocketConnectionParam(
            string remoteIP,
            int remotePort,
            int timeoutMilliseconds = SocketConnectionParam.DefaultConnectionTimeoutMilliseconds
            )
        {
            this.RemoteIP = remoteIP;
            this.RemotePort = remotePort;
            this.TimeoutMilliseconds = timeoutMilliseconds;
        }
    }
}
