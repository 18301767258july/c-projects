﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using Pegatron.Foundation;

namespace Pegatron.Communication.Socket
{
    public class SocketRecvParam : CommRecvParam
    {
        public const int DefaultRecvBufferSize = 1024;
        public int RecvBufferSize
        {
            get;
            set;
        }

        public int TimeoutMilliseconds
        {
            get;
            set;
        }

        public SocketRecvParam(int timeoutMilliseconds, int recvBufferSize = SocketRecvParam.DefaultRecvBufferSize)
        {
            this.TimeoutMilliseconds = timeoutMilliseconds;
            this.RecvBufferSize = recvBufferSize;
        }
    }

    public class SocketAsyncRecvParam : SocketRecvParam
    {
        public static SocketAsyncRecvParam Default
        {
            get
            {
                return new SocketAsyncRecvParam(0, 10, true, 2000);
            }
        }

        public int AsyncDelayMilliseconds
        {
            get;
            set;
        }

        public int NoDataDelayMilliseconds
        {
            get;
            set;
        }

        public bool IsBackground
        {
            get;
            set;
        }

        public SocketAsyncRecvParam(int asyncDelayMilliseconds, int noDataDelayMilliseconds, bool isBackground, int timeout,
            int recvBufferSize = SocketRecvParam.DefaultRecvBufferSize)
            : base(timeout, recvBufferSize)
        {
            this.AsyncDelayMilliseconds = asyncDelayMilliseconds;
            this.NoDataDelayMilliseconds = noDataDelayMilliseconds;
            this.IsBackground = isBackground;
        }
    }
}
