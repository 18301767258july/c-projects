﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Diagnostics;
using System.Threading;
using Pegatron.Foundation;
using Pegatron.Communication;

namespace Pegatron.Communication.Socket
{
    public class SocketTcpClient : IConnectedDevice, ICommunication, ICommAsyncRecv
    {
        public const string SocketTcpConnectionBadParamError      = "socket tcp connection bad parameter error";
        public const string SocketTcpConnectionWaitTimeoutError   = "socket tcp connection wait timeout error";
        public const string SocketTcpConnectionFailed             = "socket tcp connection failed";
        public const string SocketTcpSendBadParamError            = "socket tcp send bad parameter error";
        public const string SocketTcpRecvBadParamError            = "socket tcp recv bad parameter error";
        public const string SocketTcpRecvWaitTimeoutError         = "socket tcp recv wait timeout error";
        public const string SocketTcpRecvInterruptError           = "socket tcp recv interrupt error";
        public const string SocketTcpRecvAsyncStartError          = "socket tcp recv async start error";
        public const string SocketTcpRecvAsyncBadParamError       = "socket tcp recv async bad parameter error";
        public const string SocketTcpRecvAsyncStillRunningError   = "socket tcp recv async still running error";
        public const string SocketTcpRecvNoDataError              = "socket tcp recv no data error";

        protected LoopProcessor mAsyncRecvProcessor = new LoopProcessor();

        protected ManualResetEventSlim mAsyncRecvInterruptEvent = new ManualResetEventSlim(false);

        protected IAsyncResult mAsyncRecvResult = null;

        protected byte[] mRecvBuffer = null;

        public SocketAsyncRecvParam SocketAsyncRecvParam
        {
            get;
            protected set;
        }

        public CommDataReceivedCallback AsyncReceivedCallback
        {
            get;
            protected set;
        }

        public bool AsyncReceiving
        {
            get
            {
                return this.mAsyncRecvProcessor.Running;
            }
        }

        public bool Connected
        {
            get
            {
                return this.SystemSocketClient != null && this.SystemSocketClient.Client != null && this.SystemSocketClient.Connected;
            }
        }

        protected TcpClient SystemSocketClient
        {
            get;
            set;
        }

        public IPEndPoint BindingEndPoint
        {
            get;
            protected set;
        }

        public EndPoint LocalEndPoint
        {
            get
            {
                EndPoint result = null;
                try
                {
                    if (this.SystemSocketClient != null && this.SystemSocketClient.Client != null)
                    {
                        result = this.SystemSocketClient.Client.LocalEndPoint;
                    }
                }
                catch
                {
                    result = null;
                }
                return result;
            }
        }

        public EndPoint RemoteEndPoint
        {
            get
            {
                EndPoint result = null;
                try
                {
                    if (this.SystemSocketClient != null && this.SystemSocketClient.Client != null)
                    {
                        result = this.SystemSocketClient.Client.RemoteEndPoint;
                    }
                }
                catch
                {
                    result = null;
                }
                return result;
            }
        }

        public string RemoteIP
        {
            get
            {
                return Network.GetIPByEndPoint(this.RemoteEndPoint);
            }
        }

        public int RemotePort
        {
            get
            {
                return Network.GetPortByEndPoint(this.RemoteEndPoint);;
            }
        }

        public string LocalIP
        {
            get
            {
                return Network.GetIPByEndPoint(this.LocalEndPoint);
            }
        }

        public int LocalPort
        {
            get
            {
                return Network.GetPortByEndPoint(this.LocalEndPoint); ;
            }
        }

        public SocketTcpClient()
            : this((IPEndPoint)null)
        {
        }

        public SocketTcpClient(TcpClient systemClient)
            : this((IPEndPoint)null)
        {
            this.SystemSocketClient = systemClient;
        }

        public SocketTcpClient(IPEndPoint bindingEP)
        {
            this.BindingEndPoint = bindingEP;
            this.mAsyncRecvProcessor.LoopHandler = this.AsyncRecv;
        }

        public CommResult Connect(CommConnectionParam param)
        {
            CommResult result = new CommResult(false);
            object error = null;
            try
            {
                if (param is SocketConnectionParam)
                {
                    SocketConnectionParam tcpClientConnectionParam = param as SocketConnectionParam;
                    result.Result = this.Connect(
                                  tcpClientConnectionParam.RemoteIP,
                                  tcpClientConnectionParam.RemotePort,
                                  tcpClientConnectionParam.TimeoutMilliseconds, ref error
                                  );
                }
                else
                {
                    error = SocketTcpClient.SocketTcpConnectionBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public bool Connect(string remoteIP, int remotePort, int timeoutMilliseconds, ref object error)
        {
            return this.Connect(new IPEndPoint(IPAddress.Parse(remoteIP), remotePort), timeoutMilliseconds, ref error);
        }

        public bool Connect(IPEndPoint remoteEndPoint, int timeoutMilliseconds, ref object error)
        {
            bool result = false;
            try
            {
                this.Disconnect();
                if (remoteEndPoint != null)
                {
                    if (this.SystemSocketClient == null || this.SystemSocketClient.Client == null)
                    {
                        if (this.BindingEndPoint != null)
                        {
                            this.SystemSocketClient = new TcpClient(this.BindingEndPoint);
                        }
                        else
                        {
                            this.SystemSocketClient = new TcpClient();
                        }
                    }
                    if (this.SystemSocketClient != null && !this.Connected)
                    {
                        IAsyncResult asyncResult = this.SystemSocketClient.BeginConnect(remoteEndPoint.Address, remoteEndPoint.Port, null, null);
                        if (asyncResult != null)
                        {
                            if (asyncResult.AsyncWaitHandle.WaitOne(timeoutMilliseconds))
                            {
                                this.SystemSocketClient.EndConnect(asyncResult);
                                result = true;
                            }
                            else
                            {
                                error = SocketTcpClient.SocketTcpConnectionWaitTimeoutError;
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                result = false;
                error = ex;
            }
            finally
            {
                if (!result)
                {
                    this.Disconnect();
                }
            }
            return result;
        }

        public void Disconnect()
        {
            try
            {
                this.EndAsyncRecv();
                if (this.SystemSocketClient != null)
                {
                    this.SystemSocketClient.Close();
                    this.SystemSocketClient = null;
                }
            }
            catch (System.Exception)
            {
            }
        }

        public CommResult Send(CommSendParam param)
        {
            SocketSendResult result = new SocketSendResult(false);
            object error = null;
            try
            {
                if (param is SocketStringSendParam)
                {
                    SocketStringSendParam tcpClientSendParam = param as SocketStringSendParam;
                    result.Result = this.Send(tcpClientSendParam.Message, tcpClientSendParam.Terminator, ref error);
                }
                else if (param is SocketByteSendParam)
                {
                    SocketByteSendParam tcpClientSendParam = param as SocketByteSendParam;
                    result.Result = this.Send(tcpClientSendParam.Data, ref error);
                }
                else
                {
                    error = SocketTcpClient.SocketTcpSendBadParamError;
                }

            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public bool Send(byte[] data, ref object error)
        {
            bool result = false;
            try
            {
                if (this.Connected)
                {
                    NetworkStream networkStream = this.SystemSocketClient.GetStream();
                    if (networkStream != null)
                    {
                        if (data != null)
                        {
                            networkStream.Write(data, 0, data.Length * sizeof(byte));
                        }
                        networkStream.Flush();
                    }
                    result = true;
                }
                else
                {
                    error = SocketTcpClient.SocketTcpConnectionFailed;
                }
            }
            catch (System.Exception ex)
            {
                result = false;
                error = ex;
            }
            finally
            {
            }
            return result;
        }

        public bool Send(string message, ref object error)
        {
            return this.Send(message, null, ref error);
        }

        public bool Send(string message, string terminator, ref object error)
        {
            bool result = false;
            try
            {
                if (this.Connected)
                {
                    NetworkStream networkStream = this.SystemSocketClient.GetStream();
                    StreamWriter streamWriter = new StreamWriter(networkStream);
                    message += (terminator == null ? string.Empty : terminator);
                    streamWriter.Write(message);
                    streamWriter.Flush();
                    result = true;
                }
                else
                {
                    error = SocketTcpClient.SocketTcpConnectionFailed;
                }
            }
            catch (System.Exception ex)
            {
                result = false;
                error = ex;
            }
            finally
            {
            }
            return result;
        }

        public CommResult Recv(CommRecvParam param)
        {
            SocketRecvResult result = new SocketRecvResult(false);
            object error = null;
            try
            {
                if (param is SocketRecvParam)
                {
                    byte[] data = null;
                    int bytes = 0;
                    SocketRecvParam tcpClientRecvParam = param as SocketRecvParam;
                    result.Result = this.Recv(ref data, ref bytes, tcpClientRecvParam.RecvBufferSize, tcpClientRecvParam.TimeoutMilliseconds, ref error);
                    result.Data = data;
                    result.Bytes = bytes;
                }
                else
                {
                    error = SocketTcpClient.SocketTcpRecvBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
            }
            return result;
        }

        public bool Recv(ref string data, int recvBufferSize, int timeoutMilliseconds, ref object error)
        {
            return this.Recv(ref data, Encoding.ASCII, recvBufferSize, timeoutMilliseconds, ref error);
        }

        public bool Recv(ref string data, Encoding encoding, int recvBufferSize, int timeoutMilliseconds, ref object error)
        {
            bool result = false;
            if (encoding != null)
            {
                byte[] byteData = null;
                int bytes = 0;
                if ((result = this.Recv(ref byteData, ref bytes, recvBufferSize, timeoutMilliseconds, ref error)))
                {
                    if (bytes > 0)
                    {
                        data = encoding.GetString(byteData, 0, bytes);
                    }
                }
            }
            return result;
        }

        public bool Recv(ref byte[] data, ref int bytes, int recvBufferSize, int timeoutMilliseconds, ref object error)
        {
            bool result = false;
            try
            {
                if (this.Connected)
                {
                    if (this.mRecvBuffer == null)
                    {
                        this.mRecvBuffer = new byte[recvBufferSize];
                    }
                    if (this.mAsyncRecvResult == null /*|| this.mAsyncRecvResult.IsCompleted*/)
                    {
                        this.mAsyncRecvResult = this.SystemSocketClient.Client.BeginReceive(this.mRecvBuffer, 0, this.mRecvBuffer.Length * sizeof(byte), 0, null, 0);
                    }
                    if (this.mAsyncRecvResult != null)
                    {
                        int waitReturn = WaitHandle.WaitAny(new WaitHandle[] { this.mAsyncRecvResult.AsyncWaitHandle, this.mAsyncRecvInterruptEvent.WaitHandle}, timeoutMilliseconds);
                        if (waitReturn == 0)
                        {
                            bytes = this.SystemSocketClient.Client.EndReceive(this.mAsyncRecvResult);
                            if (bytes > 0)
                            {
                                data = new byte[bytes];
                                Array.Copy(this.mRecvBuffer, data, bytes);
                                Array.Clear(this.mRecvBuffer, 0, this.mRecvBuffer.Length);
                                result = true;
                            }
                            else
                            {
                                error = SocketTcpClient.SocketTcpRecvNoDataError;
                            }
                            this.mAsyncRecvResult = null;
                        }
                        else if (waitReturn == 1)
                        {
                            error = SocketTcpClient.SocketTcpRecvInterruptError;
                        }
                        else
                        {
                            error = SocketTcpClient.SocketTcpRecvWaitTimeoutError;
                        }
                    }
                    else
                    {
                        error = SocketTcpClient.SocketTcpRecvAsyncStartError;
                    }
                }
                else
                {
                    error = SocketTcpClient.SocketTcpConnectionFailed;
                }
            }
            catch (System.Exception ex)
            {
                result = false;
                error = ex;
            }
            finally
            {
            }
            return result;
        }

        public CommResult BeginAsyncRecv(CommRecvParam param, CommDataReceivedCallback asyncReceivedCallback)
        {
            CommResult result = new CommResult(false);
            object error = null;
            try
            {
                if (!this.AsyncReceiving)
                {
                    if (param is SocketAsyncRecvParam)
                    {
                        this.SocketAsyncRecvParam = param as SocketAsyncRecvParam;
                        this.mAsyncRecvProcessor.LoopSleepMilliseconds = this.SocketAsyncRecvParam.AsyncDelayMilliseconds;
                        this.mAsyncRecvProcessor.IsBackground = this.SocketAsyncRecvParam.IsBackground;
                        this.AsyncReceivedCallback = asyncReceivedCallback;
                        this.mAsyncRecvInterruptEvent.Reset();
                        result.Result = this.mAsyncRecvProcessor.AsyncExec();
                    }
                    else
                    {
                        error = SocketTcpClient.SocketTcpRecvAsyncBadParamError;
                    }
                }
                else
                {
                    error = SocketTcpClient.SocketTcpRecvAsyncStillRunningError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public void EndAsyncRecv()
        {
            this.mAsyncRecvInterruptEvent.Set();
            this.mAsyncRecvProcessor.StopExec();
            this.mAsyncRecvInterruptEvent.Reset();
        }

        private bool AsyncRecv(object arg)
        {
            bool result = true;
            try
            {
                byte[] data = null;
                int bytes = 0;
                object error = null;
                if (this.Recv(ref data, ref bytes, this.SocketAsyncRecvParam.RecvBufferSize, this.SocketAsyncRecvParam.TimeoutMilliseconds, ref error))
                {
                    if (this.AsyncReceivedCallback != null)
                    {
                        this.AsyncReceivedCallback.Invoke(this, new SocketDataReceivedEventArgs(data, bytes, this.RemoteEndPoint, this.LocalEndPoint));
                    }
                }
                else
                {
                    if (error as string == SocketTcpClient.SocketTcpRecvNoDataError || 
                        error as string == SocketTcpClient.SocketTcpConnectionFailed)
                    {
                        Thread.Sleep(this.SocketAsyncRecvParam.NoDataDelayMilliseconds);
                    }
                }
            }
            catch (System.Exception)
            {
            }
            finally
            {
                if (this.mAsyncRecvInterruptEvent.IsSet)
                {
                    result = false;
                }
            }
            return result;
        }
    }
}
