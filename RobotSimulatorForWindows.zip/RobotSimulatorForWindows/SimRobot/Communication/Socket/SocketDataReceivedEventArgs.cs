﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Diagnostics;
using System.Threading;
using Pegatron.Foundation;

namespace Pegatron.Communication.Socket
{
    public class SocketDataReceivedEventArgs : CommDataReceivedEventArgs
    {
        public EndPoint RemoteEndPoint
        {
            get;
            set;
        }

        public EndPoint LocalEndPoint
        {
            get;
            set;
        }

        public byte[] Data
        {
            get;
            set;
        }

        public int Bytes
        {
            get;
            set;
        }

        public DateTime Time
        {
            get;
            protected set;
        }

        public SocketDataReceivedEventArgs(byte[] data, int bytes, EndPoint remoteEndPoint, EndPoint localEndPoint)
            : this(data, bytes, remoteEndPoint, localEndPoint, TimeCounter.Now)
        {
        }

        public SocketDataReceivedEventArgs(byte[] data, int bytes, EndPoint remoteEndPoint, EndPoint localEndPoint, DateTime time)
        {
            this.RemoteEndPoint = remoteEndPoint;
            this.LocalEndPoint = localEndPoint;
            this.Data = data;
            this.Bytes = bytes;
            this.Time = time;
        } 
    }
}
