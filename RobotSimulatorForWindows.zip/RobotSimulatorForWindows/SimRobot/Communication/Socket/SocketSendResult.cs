﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using Pegatron.Foundation;

namespace Pegatron.Communication.Socket
{
    public class SocketSendResult : CommResult
    {
        public int BytesSent
        {
            get;
            set;
        }

        public SocketSendResult(bool result = false, object error = null, int bytesSent = 0)
            : base(result, error)
        {
            this.BytesSent = bytesSent;
        }
    }
}
