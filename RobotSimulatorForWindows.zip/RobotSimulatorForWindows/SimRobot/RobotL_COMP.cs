﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.IO;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using Pegatron.Automation;
using Pegatron.Communication;
using Pegatron.Communication.Socket;
using Pegatron.Foundation;


namespace SimRobot
{
    public enum RobotStatus
    {
        Stop,
        Running
    }
    public class RobotL_COMP : Robot
    {
        private bool goldenDoorFlag = false;
        //public bool GoldenDoorFlag
        //{
        //    get;
        //    set {
        //        this.goldenDoorFlag = value;

        //    }
        //}
        private bool drawerFlag = false;
        private int listenCAMPort = 49152;
        private int listenAVCPort = 49155;
        private string currentPosition = "Input";
        private string targetPosition = null;
        private string pick = "pick";
        private string place = "place";
        Dictionary<string, int> csvData = new Dictionary<string, int>();
        public int avcPort = 49155;
        private static Object obj = new object();
        private static Object robotDataObj = new object();
        private static Object AVCDataLockObj = new object();
        public bool continueFlag = false;
        public bool abortFlag = false;
        public List<string[]> motionDataList = new List<string[]>();
        public Timer timer;
        public bool timerFlag=true;
        private int timeOut=15;//s
        private bool pickFlag = false;
       // private bool loadFlag = false;
        private bool unloadFlag = false;
       // private bool binFlag = false;
        //suctionBlow  event
        public delegate void clampEventHander(Sensor sensor, bool suction);
        public delegate void lockHander(string num, bool result);
        //locationData  event
        public delegate void locationEventHander(int location, int slot, bool result);
        public delegate void lightTowerEventHander(LightTower lightTower);
        public delegate void airPressureSpeedHnader(string value);
        public delegate void showLog(string data);
        public delegate void displayRobotMotion(string start, int startSlot, string end, int endSlot);


        public displayRobotMotion robotMotion;
        public displayRobotMotion removeRobotMotion;
        public showLog writeCAMLog;
        public showLog writeAVCLog;
        public clampEventHander clampData;
        public locationEventHander locationData;
        //stationData   event
        public locationEventHander stationData;
        // UUTMAP event 
        public locationEventHander uutMapData;
        //lightTower
        public lightTowerEventHander lightTowerData;
        // set speed
        public airPressureSpeedHnader speedData;
        public lockHander LockData;
        public lockHander ioChangeData;

        public SocketTcpServer server = new SocketTcpServer();
        public SocketTcpServer serverAVC = new SocketTcpServer();
        public SocketTcpClient client = null;
        
        public SocketTcpClient clientAVC = null;
       
        public Bin lefts = new Bin(8);
        public Bin rights = new Bin(8);

        private string sendDataToAVCFromRobot = null;
        public string SendDataToAVCFromRobot
        {
            get { return sendDataToAVCFromRobot; }
            set
            {
                if (clientAVC != null)
                {
                    sendDataToAVCFromRobot = value;
                    SendAVC(sendDataToAVCFromRobot);
                }

            }
        }
        Thread motionThread;
        private double pressureNum = 500;
        public double Pressure
        {
            get { return this.pressureNum; }
            set
            {
                this.pressureNum = value;
                if (pressureNum >= 400 && pressureNum <= 600)
                {
                    this.airPressure.Value = true;
                    this.Send(UNSOLICITED(airPressure.Name, "0"));
                }
                else
                {
                    this.airPressure.Value = false;
                    this.Send(UNSOLICITED(airPressure.Name, "01003"));
                }
            }
        }

        public RobotL_COMP():base()
        {
            motionThread = new Thread(checkMotionDataListThread);     
            motionThread.IsBackground = true;                  
           
        }
        public void Air(bool value)
        {
            this.airPressure.Value = value;
            getStatus("00000");
            if (this.airPressure.Value)
            {
                this.Send(UNSOLICITED(airPressure.Name, "0"));
            }
            else
            {
                this.Send(UNSOLICITED(airPressure.Name, "01003"));
            }
        }
        public void Estop(bool value)
        {
            this.estop.Value = value;
            getStatus("00000");
            if (this.estop.Value == true)
            {

                this.Send(UNSOLICITED(estop.Name, "01001"));
            }
            else
            {
                this.Send(UNSOLICITED(estop.Name, "0"));
            }
           // getStatus("00");
        }
        
        #region socket listen
        private void OnTcpConnectionReceived(object sender, CommConnectionReceivedEventArgs connection)
        {
            if (connection != null && connection is SocketTcpConnectionReceivedEventArgs)
            {
                SocketTcpConnectionReceivedEventArgs tcpConnection = connection as SocketTcpConnectionReceivedEventArgs;
                this.OnClientSelected(tcpConnection.Client as SocketTcpClient);
            }
        }

        private void timerGetStatus(object zero)
        {
            if (timerFlag)
            {
                getStatus((string)zero);
            }
            else
            {
                GC.Collect();
            }
        }
        private void OnClientSelected(SocketTcpClient newClient)
        {
           // this.client = newClient;

            if (newClient.LocalPort == listenCAMPort)
            {
                this.client = newClient;
                
                if (this.client != null && this.client.Connected)
                {
                    timer = new Timer(timerGetStatus, "00000", 0, 15000);
                    GC.KeepAlive(timer);
                    Log.WriteLog("--->CAM connect succeed");
                    if (!this.client.AsyncReceiving || this.client.AsyncReceivedCallback != this.OnSocketDataReceived)
                    {
                        this.client.EndAsyncRecv();
                        this.client.BeginAsyncRecv(SocketAsyncRecvParam.Default, this.OnSocketDataReceived);
                    }
                }
            }
            else if (newClient.LocalPort == listenAVCPort)
            {
                this.clientAVC = newClient;
                
                if (this.clientAVC != null && this.clientAVC.Connected)
                {
                    Log.WriteLog("--->AVC connect succeed");
                    if (!this.clientAVC.AsyncReceiving || this.clientAVC.AsyncReceivedCallback != this.OnSocketDataReceived)
                    {
                        this.clientAVC.EndAsyncRecv();
                        this.clientAVC.BeginAsyncRecv(SocketAsyncRecvParam.Default, this.OnSocketDataReceived);
                    }
                    
                }
            }
            
        }
      
        //send data to AVC
        private bool SendAVC(string sendData)
        {
            bool result = false;
            object error = null;

            if (this.clientAVC.Send(sendData + "\r", ref error))
            {
                Log.WriteLog("----->AVC " + sendData);
                writeAVCLogEvent("----->"+sendData+"\r");
                result = true;
            }
            else
            {
                if (error != null)
                {
                    Log.WriteLog("----->AVC " + sendData + " with error: " + error);
                    writeAVCLogEvent("----->"+sendData + " with error: " + error+"\r");
                }
            }
            return result;
        }
        // send data to CAM
        private bool Send(string sendData)
        {
            bool result = false;
            object error = null;
            if(this.client!=null)
            {
                if (this.client.Send(sendData + "\r", ref error))
                {
                    Log.WriteLog("----->CAM " + sendData);
                    writeCAMLogEvent("----->" + sendData + "\r");
                    result = true;

                    SendDataToAVCFromRobot = sendData + "\r";
                }
                else
                {
                    if (error != null)
                    {
                        Log.WriteLog("----->CAM " + sendData + " with error: " + error);
                        writeCAMLogEvent("----->" + sendData + "with error:" + error + "\r");
                    }
                }
            }
            
            return result;
        }
       
        private void OnSocketDataReceived(object sender, CommDataReceivedEventArgs data)
        {
            if (data != null && data is SocketDataReceivedEventArgs)
            {
                SocketDataReceivedEventArgs socketData = data as SocketDataReceivedEventArgs;

                if (socketData.Data != null)
                {
                    string receiveMes = Encoding.UTF8.GetString(socketData.Data);
                    int commandsNum=Regex.Matches(receiveMes, @"\r").Count;
                    if (commandsNum > 1)
                    {
                        string[] mes = receiveMes.Split('\r');
                        for(int i=0;i<commandsNum;i++)
                        {
                            string[] commandData = mes[i].Split(',');
                            Log.WriteLog("<-----" + commandData);
                            handleReceiveData(mes[i], commandData);
                        }
                    }
                    else
                    {
                        Log.WriteLog("<-----" + receiveMes);
                        receiveMes = receiveMes.Replace("\r", "");
                        string[] mes = receiveMes.Split(',');
                        handleReceiveData(receiveMes, mes);
                    }
                }
            }
        }
        private void handleReceiveData(string mes,string[] data)
        {
            //处理数据
            switch (data[1])
            {
                case "REQUEST_CHANGE_DEVSTATE":
                case "CONNECT":
                case "DISCONNECT":
                case "REMOVE_UUT":
                case "ADD_UUT":
                case "MAKE_ERROR":
                case "ESTOP":
                case "AIR":
                case "POWER":
                case "RESET":
                    writeAVCLogEvent("<-----" + mes);
                    break;
                case "PL":
                case "UB":
                case "UL":
                case "HOME":
                case "PICK":
                case "LOAD":
                case "UNLOAD":
                case "BIN":
                case "ACQUIRE_UUT_MAP":
                    writeCAMLogEvent("<-----" + mes);
                    lock (obj)
                    {
                        motionDataList.Add(data);

                    }
                    motionThread.Start();                   
                    break;
                default:
                    writeCAMLogEvent("<-----" + mes);
                    break;
            }
            MoveAction(data);
        }
        
        public bool ListenCam()
        {
            bool result = false;
            CommResult commResult=null;
            if (client == null)
            {
                commResult = this.server.StartService(new SocketTcpServiceStartParam(this.ip, this.camPort), this.OnTcpConnectionReceived);
            }
            if (commResult.Result)
            {
                Log.WriteLog(ip + "--->listen CAM succeed");
                result = true;
            }
            else
            {
                if (commResult.Error == null)
                {
                    commResult.Error = "failed but no error generated";
                }
                Log.WriteLog(ip + "->listen failed with error: " + commResult.Error);
            }
            return result;
        }
        public bool ListenAVC()
        {
            bool result = false;
            CommResult commResult = null;
            // 192.168.8.11
            // 127.0.0.1
            commResult = this.serverAVC.StartService(new SocketTcpServiceStartParam(this.ip, this.avcPort), this.OnTcpConnectionReceived);
           
            if (commResult.Result)
            {
                Log.WriteLog(ip + "--->listen AVC succeed");
                result = true;
            }
            else
            {
                if (commResult.Error == null)
                {
                    commResult.Error = "failed but no error generated";
                }
                Log.WriteLog(ip + "->listen failed with error: " + commResult.Error);
            }
            return result;
        }
        #endregion
        #region event
        private void uutMapEvent(int location, int slot, bool result = false)
        {
            if (uutMapData != null)
            {
                uutMapData(location, slot, result);
            }
        }
        private void stationDataEvent(int station, int slot, bool result)
        {
            if (stationData != null)
            {
                stationData(station, slot, result);
            }

        }
        private void locationDataEvent(int location, int slot, bool result)
        {
            if (locationData != null)
            {
                locationData(location, slot, result);
            }
        }
        private void clampEvent(Sensor sensor, bool status)
        {
            if (clampData != null)
            {
                clampData(sensor, status);
            }
        }
        private void lightTowerEvent(LightTower sensors)
        {
            if (lightTowerData != null)
            {
                lightTowerData(sensors);
            }
        }
        private void setSpeedEvent(string speed)
        {
            if (speedData!=null)
            {
                speedData(speed);
            }
        }
        private void writeCAMLogEvent(string data)
        {
            if(writeCAMLog!=null)
            {
                writeCAMLog(data);
            }
        }
        private void writeAVCLogEvent(string data)
        {
            if (writeAVCLog != null)
            {
                writeAVCLog(data);
            }
        }
        private void lockEvent(string lockOne,bool result)
        {
            if (LockData!=null)
            {
                LockData(lockOne,result);
            }
        }
        private void ioChangeEvent(string io,bool status)
        {
            if (ioChangeData != null)
            {
                ioChangeData(io,status);
            }
        }
        private void robotMotionEvent(string start, int startSlot, string end, int endSlot)
        {
            if(robotMotion!=null)
            {
                robotMotion(start,startSlot,end,endSlot);
            }
        }
        private void removeRobotMotionEvent(string start, int startSlot, string end, int endSlot)
        {
            if(removeRobotMotion!=null)
            {
                removeRobotMotion(start, startSlot, end, endSlot);
            }
        }
        #endregion
        #region robot action
        private void MoveAction(string[] recData)
        {
            bool flag = false;
            string data = null;
            //处理数据
            switch (recData[1])
            {
                case "REQUEST_CHANGE_DEVSTATE":
                    requestChangeDevState(recData[0], Convert.ToInt32(recData[2]), Convert.ToInt32(recData[3]));
                    break;
                case "CONNECT":
                    flag = connect(recData[0]);
                    break;
                case "DISCONNECT":
                    flag = disconnect(recData[0]);
                    break;
                case "REMOVE_UUT":
                    flag = removeUUT(recData);
                    break;
                case "ADD_UUT":
                    flag = addUUT(recData);
                    break;
                case "MAKE_ERROR":
                    flag = makeError(recData);
                    break;
                case "ESTOP":
                    flag = estopError(recData[0],Convert.ToInt32(recData[2]));
                    break;
                case "AIR":
                    flag = air(recData[0],Convert.ToInt32(recData[2]));
                    break;
                case "POWER":
                    flag = power(recData[0], Convert.ToInt32(recData[2]));
                    break;
                case "RESET":
                    reset(recData[0]);
                    flag = true;
                    break;
                case "GET_SPEED":
                    data=GetSpeed(recData[0]);
                    this.Send(data);
                    break;
                case "SET_SPEED":
                    data=SetSpeed(recData);
                    this.Send(data);
                    break;
                case "GET_STATUS":
                    getStatus(recData[0]);
                    break;
                case "GET_CONFIG":
                    data=getConfig(recData);
                    this.Send(data);
                    break;
                case "GET_IO":
                    break;
                case "SET_IO":
                    break;
                case "ACQUIRE_UUT_MAP":
                    data=acquireUUTMap(recData);
                    this.Send(data);
                    break;
                case "BEACON":
                    data=BEACON(recData);
                    this.Send(data);
                    break;
                case "SET_CONFIG":

                    break;
                case "GET_MODE":
                    data = reportMode(recData);
                    this.Send(data);
                    break;
                case "SET_MODE":
                    data = reportMode(recData);
                    this.Send(data);
                    break;
                case "CONTINUE":
                    data = CONTINUE(recData);
                    this.Send(data);
                    break;
                case "ABORT":
                    data = ABORT(recData);
                    this.Send(data);
                    break;
                //default:
                //    data = recData[0] + "," + recData[1] + "," + ((int)ROBOTERRORCODE.UndefineAction).ToString() + "," + ROBOTERRORCODE.UndefineAction.ToString();
                //    this.Send(data);
                //    break;
            }
          //  this.Send(data);
        }
        public void checkMotionDataListThread()
        {
            string data = null;

            while (true)
            {
                Thread.Sleep(2);
                if (motionDataList.Count >= 1)
                {
                    lock (obj)
                    {
                        string[] motion = motionDataList[0];
                        // update robot motion

                        switch (motion[1])
                        {
                            case "PL":
                                robotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                PL(motion);
                                removeRobotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                break;
                            case "UB":
                                robotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                Thread.Sleep(1000);
                                UB(motion);
                                removeRobotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                break;
                            case "UL":
                                robotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                UL(motion);
                                removeRobotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                break;
                            case "HOME":
                                data = HOME(motion);
                                this.Send(data);
                                break;
                            case "PICK":
                                PICK(motion[3], motion[4]);
                                data = motion[0] + "," + motion[1] + "," + motion[2] + "," + motion[3] + "," + motion[4] + ",0,Success.";
                                this.Send(data);
                                break;
                            case "LOAD":
                                LOAD(motion[3], motion[4]);
                                data = motion[0] + "," + motion[1] + "," + motion[2] + "," + motion[3] + "," + motion[4] + ",0,Success.";
                                this.Send(data);
                                break;
                            case "UNLOAD":
                                UNLOAD(motion[3], motion[4]);
                                data = motion[0] + "," + motion[1] + "," + motion[2] + "," + motion[3] + "," + motion[4] + ",0,Success.";
                                this.Send(data);
                                break;
                            case "BIN":
                                BIN(motion[3], motion[4]);
                                data = motion[0] + "," + motion[1] + "," + motion[2] + "," + motion[3] + "," + motion[4] + ",0,Success.";
                                this.Send(data);
                                break;
                            case "ACQUIRE_UUT_MAP":
                                data = acquireUUTMap(motion);
                                this.Send(data);
                                break;
                        }

                        motionDataList.RemoveAt(0);
                    }
                }



            }
        }
        private string HOME(string[] recData)
        {
            StringBuilder data = new StringBuilder();
            data.Append(recData[0]).Append(",HOME,").Append(recData[2]).Append(",").Append(home()).Append(",0,Success");
            abortFlag = false;
            continueFlag = false;
            return data.ToString();
        }
        
        private string CONTINUE(string[] recData)
        {
            continueFlag=true;
            StringBuilder data = new StringBuilder();
            data.Append( recData[0]).Append( ",").Append(recData[1]).Append(",0,Success");
            return data.ToString();
        }
       
        private string ABORT(string[] recData)
        {
            continueFlag = false;
            abortFlag = true;
            StringBuilder data = new StringBuilder();
            data.Append(recData[0]).Append(",").Append(recData[1]).Append(",0,Success");
            return data.ToString();
        }
        public string setIO(string[] recData)
        {
            return "";
        }
        private string getIO(string[] recData)
        {
            return "";
        }
        public void getStatus(object num)
        {
            StringBuilder data = new StringBuilder();
            data.Append(num).Append(",GET_STATUS,").Append(RobotStatus.Running.ToString()).Append(",").Append(getInputBitMap()).Append(",").Append(getOutputBitMap()).Append(",0,Success");
            
            this.Send(data.ToString());
        }  //GET_STATUS

        /// <summary>
        /// 回复CAM的SET_MODE命令
        /// </summary>
        /// <param name="recData"></param>
        public string reportMode(string[] recData)
        {
            //06977,SET_MODE,20,0[0x0d]
            //06977,REPORT_MODE,20, 0,0,Succeed[0x0d]
            StringBuilder data = new StringBuilder();
           // string data = recData[0] + ",REPORT_MODE,";
            data.Append(recData[0]);
            data.Append(",REPORT_MODE,");
            if (recData[1] == "GET_MODE")
            {
                switch (recData[2])
                {
                    case "20":

                        //data = data + "20," + Convert.ToInt32(rejectDrawerClosed.Value) + ",0,Success";
                        data.Append("20,");
                        data.Append(Convert.ToInt32(rejectDrawerClosed.Value));
                        data.Append(",0,Success");
                        break;
                    case "21":
                        //data = data + "21," + Convert.ToInt32(goldenDoorClosed.Value) + ",0,Success";
                        data.Append("21,");
                        data.Append(Convert.ToInt32(goldenDoorClosed.Value));
                        data.Append(",0,Success");
                        break;
                }
            }
            else if (recData[1] == "SET_MODE")
            {
                switch (recData[2])
                {
                    case "20":
                        if (recData[3] == "1")// Access enabled
                        {
                           // doorLock.Value = false;
                            rejectDrawerLock.Value = true;
                          //  rejectRight.Value = true;
                            rejectDrawerClosed.Value = true;
                            getStatus("00000");
                            drawerFlag = true;
                           // data = data + "20," + Convert.ToInt32(rejectDrawerLock.Value) + ",0,Success";
                            data.Append("20,");
                            data.Append(Convert.ToInt32(rejectDrawerLock.Value));
                            data.Append(",0,Success");
                        }
                        else  //Access disabled
                        {
                            if (rejectDrawerClosed.Value)
                            {
                                rejectDrawerLock.Value = false;
                                rejectDrawerClosed.Value = false;
                                getStatus("00000");
                                drawerFlag = false;
                                //data = data + "20," + Convert.ToInt32(rejectDrawerLock.Value) + ",0,Success";
                                data.Append("20,");
                                data.Append(Convert.ToInt32(rejectDrawerLock.Value));
                                data.Append(",0,Success");
                            }
                            else
                            {
                                //error
                                //data = data + "20," + Convert.ToInt32(rejectDrawerLock.Value) + "," + ((int)ROBOTERRORCODE.DoorNotClosed).ToString() + "," + ROBOTERRORCODE.DoorNotClosed.ToString();
                                data.Append("20,");
                                data.Append(Convert.ToInt32(rejectDrawerLock.Value));
                                data.Append(",");
                                data.Append(((int)ROBOTERRORCODE.DoorNotClosed).ToString());
                                data.Append(",");
                                data.Append(ROBOTERRORCODE.DoorNotClosed.ToString());
                            }
                        }
                        lockEvent("20", rejectDrawerLock.Value);
                        break;
                    case "21":
                        if (recData[3] == "1")// Access enabled
                        {
                            goldenDoorLock.Value = true;
                            goldenDoorClosed.Value = true;
                            goldenDoorLight.Value = true;
                            getStatus("00000");
                            goldenDoorFlag = true;
                            //data = data + "21," + Convert.ToInt32(goldenDoorLock.Value) + ",0,Success";
                            data.Append("21,");
                            data.Append(Convert.ToInt32(goldenDoorLock.Value));
                            data.Append(",0,Success");
                        }
                        else  //Access disabled
                        {
                            if (goldenDoorClosed.Value)
                            {
                                goldenDoorLock.Value = false;
                                goldenDoorClosed.Value = false;
                                goldenDoorLight.Value = false;
                                getStatus("00000");
                                goldenDoorFlag = false;
                               // data = data + "21," + Convert.ToInt32(goldenDoorLock.Value) + ",0,Success";
                                data.Append("21,");
                                data.Append(Convert.ToInt32(goldenDoorLock.Value));
                                data.Append(",0,Success");
                            }
                            else
                            {
                                //error
                                //data = data + "21," + goldenDoorLock.Value.ToString() + "," + ((int)ROBOTERRORCODE.DoorNotClosed).ToString() + "," + ROBOTERRORCODE.DoorNotClosed.ToString();
                                data.Append("21,");
                                data.Append(goldenDoorLock.Value.ToString());
                                data.Append(",");
                                data.Append(((int)ROBOTERRORCODE.DoorNotClosed).ToString());
                                data.Append(",");
                                ROBOTERRORCODE.DoorNotClosed.ToString();
                            }
                        }
                        lockEvent("21", goldenDoorLock.Value);
                        break;
                }
                
            }

            //this.Send(data);
            return data.ToString();
        }
        private string GetSpeed(string num)
        {
            StringBuilder data = new StringBuilder();
            //string data = num + ",GET_SPEED," + this.Speed.ToString() + ",0,Success";
            data.Append(num);
            data.Append(",GET_SPEED,");
            data.Append(this.Speed);
            data.Append(",0,Success");
            return data.ToString();
        }
        private string SetSpeed(string[] recData)
        {
            StringBuilder data = new StringBuilder();
           // string data = null;
            this.Speed = Convert.ToInt32(recData[2]);
            getStatus("00000");
            //data = recData[0] + ",SET_SPEED," + recData[2] + "," + this.Speed + ",0,Success";
            data.Append(recData[0]);
            data.Append(",SET_SPEED,");
            data.Append(recData[2]);
            data.Append(",");
            data.Append(this.Speed);
            data.Append(",0,Success");
            setSpeedEvent(Convert.ToString(this.Speed));
            return data.ToString();
        }
        private string BEACON(string[] recData)
        {
            StringBuilder data = new StringBuilder();
            //string data=null;
            //data = recData[0] + ",BEACON,";
            data.Append(recData[0]);
            data.Append(",BEACON,");
            //Buzzer
            switch (recData[2])
            {
                case "Off":
                    lightHouse.Buzzer = false;
                    //data = data + "Off,";
                    data.Append("Off,");
                    break;
                case "On":
                    lightHouse.Buzzer = true;
                    //data = data + "On,";
                    data.Append("On,");
                    break;
                case "NoChange":
                   // data = data + (lightHouse.Buzzer ? "On," : "Off,");
                    data.Append(lightHouse.Buzzer ? "On," : "Off,");
                    break;
            }
            //Red
            switch (recData[3])
            {
                case "Off":
                    lightHouse.Red = false;
                    data.Append("Off,");
                    //data = data + "Off,";
                    break;
                case "On":
                    lightHouse.Red = true;
                    //data = data + "On,";
                    data.Append("On,");
                    break;
                case "NoChange":
                    //data = data + (lightHouse.Red ? "On," : "Off,");
                    data.Append((lightHouse.Red ? "On," : "Off,"));
                    break;
            }
            //Amber
            switch (recData[4])
            {
                case "Off":
                    lightHouse.Yellow = false;
                    //data = data + "Off,";
                    data.Append("Off,");
                    break;
                case "On":
                    lightHouse.Yellow = true;
                    //data = data + "On,";
                    data.Append("On,");
                    break;
                case "Flashing":
                    lightHouse.Yellow = true;
                    //data = data + "Flashing,";
                    data.Append("Flashing,");
                    break;
                case "NoChange":
                    //data = data+(lightHouse.Yellow ? "On," : "0ff,");
                    data.Append((lightHouse.Yellow ? "On," : "0ff,"));
                    break;
            }
            //Green
            switch (recData[5])
            {
                case "Off":
                    lightHouse.Green = false;
                    //data = data + "Off,Off,0,Success";
                    data.Append("Off,Off,0,Success");
                    break;
                case "On":
                    lightHouse.Green = true;
                    //data = data + "On,Off,0,Success";
                    data.Append("On,Off,0,Success");
                    break;
                case "NoChange":
                    //data = data + (lightHouse.Green ? "On," : "0ff,") + "0,Success";
                    data.Append(lightHouse.Green ? "On," : "0ff,");
                    data.Append("Off,0,Success");
                    break;
            }
            getStatus("00000");

            lightTowerEvent(lightHouse);
            // this.Send(data);
            return data.ToString();
        }   //BEACON
        public string requestModeChange(int dev, int newState, int oldState)
        {
            StringBuilder data = new StringBuilder();
            //string command = "0,REQUEST_MODE_CHANGE," + dev.ToString() + "," + newState.ToString() + "," + oldState.ToString();
            // Log.WriteLog("----->" + command);
            data.Append("0,REQUEST_MODE_CHANGE,");
            data.Append(dev);
            data.Append(",");
            data.Append(newState);
            data.Append(",");
            data.Append(oldState);
            this.Send(data.ToString());
            return data.ToString();
        }
        private string acquireUUTMap(string[] recData) //ACQUIRE_UUT_MAP
        {
            //00001,ACQUIRE_UUT_MAP,101,01
            string data=null;
            //delay time
            //delayTime(3);
            if (clamp1Open.Value == true&&clamp1Opened.Value==true)
            {
                clamp1Close.Value = true;
                clampEvent(clamp1Close, clamp1Close.Value);
                getStatus("00000");
            }
            switch (recData[2])
            {
                case "101":
                    if (lefts.buffer[Convert.ToInt32(recData[3])-1].Value)
                    {
                        clamp1DUT.Value = true;
                        getStatus("00000");
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        clamp1Open.Value = true;
                        clamp1Opened.Value = true;
                        getStatus("00000");
                        clampEvent(clamp1Opened, clamp1Opened.Value);
                        clamp1DUT.Value = false;
                        getStatus("00000");
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        uutMapEvent(Convert.ToInt32(recData[2]), Convert.ToInt32(recData[3]), lefts.buffer[Convert.ToInt32(recData[3]) - 1].Value);
                        data = recData[0] + ",ACQUIRE_UUT_MAP," + recData[2] + "," + recData[3] + ",1,0,Success";
                    }
                    else
                    {
                        clamp1DUT.Value = false;
                        getStatus("00000");
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        clamp1Open.Value = true;
                        clamp1Opened.Value = true;
                        getStatus("00000");
                        clampEvent(clamp1Opened, clamp1Opened.Value);
                        clamp1DUT.Value = false;
                        getStatus("00000");
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        uutMapEvent(Convert.ToInt32(recData[2]), Convert.ToInt32(recData[3]), lefts.buffer[Convert.ToInt32(recData[3]) - 1].Value);
                        data = recData[0] + ",ACQUIRE_UUT_MAP," + recData[2] + "," + recData[3] + ",0,0,Success";
                    }
                    break;
                case "102":
                    if (rights.buffer[Convert.ToInt32(recData[3])-1].Value)
                    {
                        clamp1DUT.Value = true;
                        getStatus("00000");
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        clamp1Open.Value = true;
                        clamp1Opened.Value = true;
                        getStatus("00000");
                        clampEvent(clamp1Opened, clamp1Opened.Value);
                        clamp1DUT.Value = false;
                        getStatus("00000");
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        uutMapEvent(Convert.ToInt32(recData[2]), Convert.ToInt32(recData[3]), rights.buffer[Convert.ToInt32(recData[3]) - 1].Value);
                        data = recData[0] + ",ACQUIRE_UUT_MAP," + recData[2] + "," + recData[3] + ",1,0,success";
                    }
                    else
                    {
                        clamp1DUT.Value = false;
                        getStatus("00000");
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        clamp1Open.Value = true;
                        clamp1Opened.Value = true;
                        getStatus("00000");
                        clampEvent(clamp1Opened, clamp1Opened.Value);
                        clamp1DUT.Value = false;
                        getStatus("00000");
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        uutMapEvent(Convert.ToInt32(recData[2]), Convert.ToInt32(recData[3]), rights.buffer[Convert.ToInt32(recData[3]) - 1].Value);
                        data = recData[0] + ",ACQUIRE_UUT_MAP," + recData[2] + "," + recData[3] + ",0,0,Success";
                    }
                    break;
               
            }


            

            
            // this.Send(data);
            return data;
        }
        private string UNSOLICITED(string who, string errorCode)
        {
            //string data = "";
            StringBuilder data = new StringBuilder("00,UNSOLICITED,");
            switch (who)
            {
                case "Estop": //e-stop
                    if (errorCode == "01001")
                    {
                        data.Append(errorCode).Append(",Robot ESTOP engaged");
                    }
                    else if (errorCode == "0")
                    {
                        data.Append(errorCode).Append(",Robot ESTOP released");
                    }
                    break;
                case "airPressure": //airPressure
                    if (errorCode == "01003")
                    {
                        data.Append(errorCode).Append(",Robot Air UnNormal");
                    }
                    else if (errorCode == "0")
                    {
                        data.Append(errorCode).Append(",Robot Air Normal");
                    }
                    break;
                case "electric":
                    if (errorCode == "01002")
                    {
                        data.Append(errorCode).Append(",power supply exceptation");
                    }
                    else
                    {
                        data.Append(errorCode).Append(",power supply normal");
                    }
                    break;
            }
            //this.Send(data);
            return data.ToString();
        }
        private string getConfig(string[] recData)
        {
            string data = recData[0] + ",GET_CONFIG," + dev_type + "," + ip + "," + os_ver + "," + app_ver + "," + proto_ver + "," + serial_num + ",0,Success";
            // this.Send(data);
            return data;
        }
        public ROBOTERRORCODE PL(string[] recData)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            //string data=null;
            StringBuilder data = new StringBuilder();
            flag = PICK(recData[3], recData[4]);
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                data.Append(recData[0]).Append(",PICK,").Append(recData[2]).Append(",").Append(recData[3]).Append(",").Append(recData[4]).Append(",0,Success.");
                
                this.Send(data.ToString());
            }
            else
            {
                data.Append(recData[0]).Append(",PICK,").Append(recData[2]).Append(",").Append(recData[3]).Append(",").Append(recData[4]).Append(",1,").Append(flag.ToString());
                
                this.Send(data.ToString());
            }
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = LOAD(recData[6], recData[7]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Append(recData[0]).Append(",LOAD,").Append(recData[5]).Append(",").Append(recData[6]).Append(",").Append(recData[7]).Append(",0,Success.");
                    this.Send(data.ToString());
                }
            }
            else
            {
                data.Append(recData[0]).Append(",LOAD,").Append(recData[5]).Append(",").Append(recData[6]).Append(",").Append(recData[7]).Append(",1,").Append(flag.ToString());
                this.Send(data.ToString());
            }
            return flag;
            
        }  //PL
        public ROBOTERRORCODE UB(string[] recData)
        {
            // 49152:12395,UL,01,102,03,01,102,03[0x0d]
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            StringBuilder data = new StringBuilder();
            //string data=null;

            flag = UNLOAD(recData[3], recData[4]);
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                data.Append(recData[0]).Append(",UNLOAD,").Append(recData[2]).Append(",").Append(recData[3]).Append(",").Append( recData[4]).Append(",0,Success.");
                
                this.Send(data.ToString());
               
            }
            else
            {
                data.Append(recData[0]).Append(",UNLOAD,").Append(recData[2]).Append(",").Append(recData[3]).Append(",").Append(recData[4]).Append(",1,").Append(flag.ToString());
                
                this.Send(data.ToString());
            }
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = BIN(recData[6], recData[7]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Append(recData[0]).Append(",BIN,").Append(recData[5]).Append(",").Append(recData[6]).Append(",").Append(recData[7]).Append(",0,Success.");
                    this.Send(data.ToString());
                }
            }
            else
            {
                data.Append(recData[0]).Append(",BIN,").Append(recData[5]).Append(",").Append(recData[6]).Append(",").Append(recData[7]).Append(",1,").Append(flag.ToString());
                this.Send(data.ToString());
            }
            return flag;
        }  //UB
        public ROBOTERRORCODE UL(string[] recData)
        {
            // 49152:12395,UL,01,102,03,01,102,03[0x0d]

            //string data=null;
            StringBuilder data = new StringBuilder();
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            flag = UNLOAD(recData[3], recData[4]);
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                data.Append(recData[0]).Append(",UNLOAD,").Append(recData[2]).Append(",").Append(recData[3]).Append(",").Append(recData[4]).Append(",0,Success.");
                
                this.Send(data.ToString());
            }
            else
            {
                data.Append(recData[0]).Append(",UNLOAD,").Append(recData[2]).Append(",").Append(recData[3]).Append(",").Append(recData[4]).Append(",1,").Append(flag.ToString());
                
                this.Send(data.ToString());
            }
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = LOAD(recData[6], recData[7]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Append(recData[0]).Append(",LOAD,").Append(recData[5]).Append(",").Append(recData[6]).Append(",").Append(recData[7]).Append(",0,Success.");
                    this.Send(data.ToString());
                }
            }
            else
            {
                data.Append(recData[0]).Append(",LOAD,").Append(recData[5]).Append(",").Append(recData[6]).Append(",").Append(recData[7]).Append(",1,").Append(flag.ToString());
                this.Send(data.ToString());
            }
            return flag;
            
        }  //UL
        public ROBOTERRORCODE PICK(string station,string slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            switch (station)
            {
                case "51":
                    targetPosition="Input";
                    delayTime(csvData[currentPosition + targetPosition+pick],Speed);
                    flag = fromInput(station, Convert.ToInt32(slot));
                    break;
                case "21":
                    flag = fromInBuffer(station, Convert.ToInt32(slot));
                    break;
                case "31":
                    flag = toAuditBuffer(Convert.ToInt32(slot));
                    break;
            }
            return flag;
        }
        public ROBOTERRORCODE LOAD(string location,string slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            switch (location)
            {
                case "101":
                    switch (slot)
                    {
                        case "1":
                        case "3":
                        case "5":
                        case "7":
                            targetPosition = "L-comp_1";
                            break;
                        case "2":
                        case "4":
                        case "6":
                        case "8":
                            targetPosition = "L-comp_2";
                            break;

                    }
                    delayTime(csvData[currentPosition + targetPosition + place],Speed);
                    flag = toLeft(Convert.ToInt32(slot));
                    break;
                case "102":
                    switch (slot)
                    {
                        case "1":
                        case "3":
                        case "5":
                        case "7":
                            targetPosition = "L-comp_3";
                            break;
                        case "2":
                        case "4":
                        case "6":
                        case "8":
                            targetPosition = "L-comp_4";
                            break;

                    }
                    delayTime(csvData[currentPosition + targetPosition + place],Speed);
                    flag = toRight(Convert.ToInt32(slot));
                    break;
            }
            return flag;

        }
        public ROBOTERRORCODE UNLOAD(string location,string slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            switch (location)
            {
                case "101":

                    switch (slot)
                    {
                        case "01":
                        case "03":
                        case "05":
                        case "07":
                            targetPosition = "L-comp_1";
                            break;
                        case "02":
                        case "04":
                        case "06":
                        case "08":
                            targetPosition = "L-comp_2";
                            break;

                    }
                    //currentPosition = targetPosition;
                    delayTime(csvData[currentPosition + targetPosition + pick],Speed);
                    flag = fromLeft(location,Convert.ToInt32(slot));
                    break;
                case "102":
                    switch (slot)
                    {
                        case "01":
                        case "03":
                        case "05":
                        case "07":
                            targetPosition = "L-comp_3";
                            break;
                        case "02":
                        case "04":
                        case "06":
                        case "08":
                            targetPosition = "L-comp_4";
                            break;

                    }
                    delayTime(csvData[currentPosition + targetPosition + pick],Speed);
                    flag = fromRight(location,Convert.ToInt32(slot));
                    break;
            }
            return flag;

        }
        public ROBOTERRORCODE BIN(string station,string slot)
        {

            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            switch (station)
            {
                case "52":
                    targetPosition = "Output";
                    delayTime(csvData[currentPosition + targetPosition + place], Speed);
                    //blowAir(5);
                    DateTime timeStart = DateTime.Now;
                    DateTime timeEnd;
                    string time = null;

                    if (clamp1DUT.Value)
                    {
                        //ADD continue judge

                        while (continueFlag == false)
                        {
                            Thread.Sleep(2);
                            timeEnd = DateTime.Now;
                            time = DateDiff(timeEnd, timeStart);
                            if (Convert.ToInt32(time) >= timeOut)
                            {
                                flag = ROBOTERRORCODE.MoveActionTimeout;
                                break;
                            }
                            if (estop.Value == true)
                            {
                                flag = ROBOTERRORCODE.EmergencyMode;
                                break;
                            }
                            if (abortFlag==true)
                            {
                                abortFlag = false;
                                flag = ROBOTERRORCODE.TaskAbort;
                                break;
                            }
                        }

                        if (continueFlag == true && Convert.ToInt32(time) < timeOut)
                        {
                            fetchOver();
                            flag = ROBOTERRORCODE.SUCCESS;
                            continueFlag = false;
                        }
                        
                    }

                    break;
                case "21":
                    flag = toInBuffer(Convert.ToInt32(slot));
                    break;
                case "11":
                    flag = toNGBuffer(Convert.ToInt32(slot));
                    break;
                case "12":
                    flag = toProcessBuffer(Convert.ToInt32(slot));
                    break;
                case "31":
                    flag = toAuditBuffer(Convert.ToInt32(slot));
                    break;
            }
            return flag;
            
        }
       
        private ROBOTERRORCODE fromInBuffer(string startPosition, int startSlot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;

           // flag=suctionAir(5);
            if (clamp1Opened.Value == true && clamp1Open.Value == true)
            {
                clampReadyFetch();

                if (inBuffer.buffer[startSlot - 1].Value)// inbuffer  have UUT
                {
                    
                    if (pickFlag)
                    {
                        flag = ROBOTERRORCODE.PickFailed;
                    }
                    else
                    {
                        inBuffer.buffer[startSlot - 1].Value = false;
                        getStatus("00000");
                        clamp1DUT.Value = true;
                        getStatus("00000");
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                       
                    
                }
                else
                {
                    //vacuum.Value = false;
                    //getStatus("00");
                    flag = ROBOTERRORCODE.NoFindUUT;
                }
                stationDataEvent(21, startSlot, inBuffer.buffer[startSlot - 1].Value);
            }else
            {
                if (clamp1DUT.Value == true)   // vacuum have UUT
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time)>=timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE fromInput(string startPosition, int startSlot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
           // flag=suctionAir(5);
            
                if (clamp1Opened.Value == true && clamp1Open.Value == true)
                {
                    clampReadyFetch();

                    clamp1DUT.Value = true;
                    getStatus("00000");
                    clampEvent(clamp1DUT, clamp1DUT.Value);
                    if (pickFlag)
                    {
                        flag = ROBOTERRORCODE.PickFailed;
                        clamp1DUT.Value = false;
                        getStatus("00000");
                    }
                    else
                    {
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                }
                else
                {
                    if (clamp1DUT.Value == true)
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                }
                timeEnd = DateTime.Now;
                time = DateDiff(timeEnd, timeStart);
                if (Convert.ToInt32(time) >= timeOut)
                {
                    flag = ROBOTERRORCODE.MoveActionTimeout;
                }
            return flag;
        }
        private ROBOTERRORCODE fromLeft(string startPosition, int startSlot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
           // flag=suctionAir(5);
            
            if (clamp1Opened.Value == true && clamp1Open.Value == true)
            {
                clampReadyFetch();
                
                //make unload error flag
                if (unloadFlag)
                {
                    lefts.buffer[startSlot - 1].Value = true;
                    flag = ROBOTERRORCODE.UnLoadFailed;
                }
                else
                {
                    clamp1DUT.Value = true;
                    getStatus("00000");
                    clampEvent(clamp1DUT, clamp1DUT.Value);
                    lefts.buffer[startSlot - 1].Value = false;
                    flag = ROBOTERRORCODE.SUCCESS;
                }
                

            }
            else
            { 
                if (clamp1DUT.Value == true)
                {
                    flag = ROBOTERRORCODE.UnitAlreadyExist;
                }
            }
            locationDataEvent(101, startSlot, lefts.buffer[startSlot-1].Value);
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE fromRight(string startPosition, int startSlot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
           // flag=suctionAir(5);
            if (clamp1Opened.Value == true && clamp1Open.Value == true)
            {
                clampReadyFetch();
                
                if (unloadFlag)
                {
                    rights.buffer[startSlot - 1].Value = true;//抓不起來
                    flag = ROBOTERRORCODE.UnLoadFailed;
                }
                else
                {
                    clamp1DUT.Value = true;
                    getStatus("00000");
                    clampEvent(clamp1DUT, clamp1DUT.Value);
                    rights.buffer[startSlot - 1].Value = false;
                    flag = ROBOTERRORCODE.SUCCESS;
                }
                
            }else
            {
                if (clamp1DUT.Value == true)
                {
                    flag = ROBOTERRORCODE.UnitAlreadyExist;
                }
            }
            locationDataEvent(102, startSlot, rights.buffer[startSlot - 1].Value);
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE fromAudit(string startPosition, int startSlot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;

            // flag=suctionAir(5);
            if (clamp1Opened.Value == true && clamp1Open.Value == true)
            {
                clampReadyFetch();

                if (audits.buffer[startSlot - 1].Value)// audit  have UUT
                {

                    if (pickFlag)
                    {
                        flag = ROBOTERRORCODE.PickFailed;
                    }
                    else
                    {
                        inBuffer.buffer[startSlot - 1].Value = false;
                        getStatus("00000");
                        clamp1DUT.Value = true;
                        getStatus("00000");
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        flag = ROBOTERRORCODE.SUCCESS;
                    }


                }
                else
                {
                    //vacuum.Value = false;
                    //getStatus("00");
                    flag = ROBOTERRORCODE.NoFindUUT;
                }
                stationDataEvent(31, startSlot, audits.buffer[startSlot - 1].Value);
            }
            else
            {
                if (clamp1DUT.Value == true)   // vacuum have UUT
                {
                    flag = ROBOTERRORCODE.UnitAlreadyExist;
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private void clampReadyFetch()
        {
            clamp1Open.Value = false;
            getStatus("00000");
            clamp1Opened.Value = false;
            getStatus("00000");
            clampEvent(clamp1Opened, clamp1Opened.Value);
            clamp1Close.Value = true;
            getStatus("00000");

        }
        private ROBOTERRORCODE toLeft(int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (clamp1DUT.Value)
            {
                fetchOver();
                lefts.buffer[slot - 1].Value = true;
                flag = ROBOTERRORCODE.SUCCESS;
            }
            else
            {
                flag = ROBOTERRORCODE.NoUnitDetect;
                //lefts.buffer[slot - 1].Value = false;
            }
            locationDataEvent(101, slot, lefts.buffer[slot - 1].Value);
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE toRight(int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (clamp1DUT.Value)
            {
                fetchOver();
                rights.buffer[slot - 1].Value = true;
                flag = ROBOTERRORCODE.SUCCESS;
            }
            else
            {
                flag = ROBOTERRORCODE.NoUnitDetect;
              //  rights.buffer[slot - 1].Value = false;
            }
            locationDataEvent(102, slot, rights.buffer[slot - 1].Value);
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE toAuditBuffer(int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (clamp1DUT.Value)
            {
                if (audits.buffer[slot - 1].Value)
                {
                    flag = ROBOTERRORCODE.PositionIsUsed;
                }
                else
                {
                    fetchOver();

                    audits.buffer[slot - 1].Value = true;
                    getStatus("00000");

                    //sleep some time check again
                    if (audits.buffer[slot - 1].Value == false)
                    {
                        flag = ROBOTERRORCODE.NoDetectSignal;
                    }
                    else
                    {
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                    stationDataEvent(31, slot, inBuffer.buffer[slot - 1].Value);
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE toInBuffer(int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (clamp1DUT.Value)
            {
                if (inBuffer.buffer[slot - 1].Value)
                {
                    flag = ROBOTERRORCODE.PositionIsUsed;
                }
                else
                {
                    fetchOver();

                    inBuffer.buffer[slot - 1].Value = true;
                    getStatus("00000");

                    //sleep some time check again
                    if (inBuffer.buffer[slot - 1].Value == false)
                    {
                        flag = ROBOTERRORCODE.NoDetectSignal;
                    }
                    else
                    {
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                    stationDataEvent(21, slot, inBuffer.buffer[slot - 1].Value);
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE toProcessBuffer(int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (clamp1DUT.Value)
            {
                if (processBuffer.buffer[slot - 1].Value)
                {
                    flag = ROBOTERRORCODE.PositionIsUsed;
                }
                else
                {
                    fetchOver();

                    processBuffer.buffer[slot - 1].Value = true;
                    getStatus("00000");
                    //sleep some time check again

                    if (processBuffer.buffer[slot - 1].Value == false)
                    {
                        flag = ROBOTERRORCODE.NoDetectSignal;
                    }
                    else
                    {
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                    stationDataEvent(12, slot, processBuffer.buffer[slot - 1].Value);
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE toNGBuffer(int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (clamp1DUT.Value)
            {
                if (ngBuffer.buffer[slot - 1].Value)
                {
                    flag = ROBOTERRORCODE.PositionIsUsed;
                }
                else
                {
                    fetchOver();

                    ngBuffer.buffer[slot - 1].Value = true;
                    getStatus("00000");
                    if (ngBuffer.buffer[slot - 1].Value == false)
                    {
                        flag = ROBOTERRORCODE.NoDetectSignal;
                    }
                    else
                    {
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                    stationDataEvent(11, slot, ngBuffer.buffer[slot - 1].Value);
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        //clamp grab uut finished
        private void fetchOver()
        {
            clamp1Close.Value = false;
            getStatus("00000");
            clamp1Open.Value = true;
            getStatus("00000");
            clamp1Opened.Value = true;
            getStatus("00000");
            clampEvent(clamp1Opened, clamp1Opened.Value);
            clamp1DUT.Value = false;
            getStatus("00000");
            clampEvent(clamp1DUT, clamp1DUT.Value);
            Thread.Sleep(850);
        }
        #endregion
        // s 
        private static string DateDiff(DateTime DateTime1, DateTime DateTime2)
        {
            string dateDiff = null;
            TimeSpan ts1 = new TimeSpan(DateTime1.Ticks);
            TimeSpan ts2 = new TimeSpan(DateTime2.Ticks);
            TimeSpan ts = ts1.Subtract(ts2).Duration();
            dateDiff = ts.Seconds.ToString();
            return dateDiff;
        }
        #region make exceptation 
        public bool connect(string recData)
        {
            StringBuilder data = new StringBuilder();
            //string data = null;
            bool flag = false;
            if (client == null&&this.server==null)
            {
                this.server = new SocketTcpServer();
                if (ListenCam())
                {

                    Thread.Sleep(5000);
                    DateTime timeStart = DateTime.Now;
                    DateTime timeEnd;
                    string time = null;
                    while (client == null)
                    {
                        Thread.Sleep(2);
                        timeEnd = DateTime.Now;
                        time = DateDiff(timeEnd, timeStart);
                        if (Convert.ToInt32(time) >= 600)//connect timeout time 600s
                        {
                            flag = false;
                            //data = recData + ",CONNECT,1,connect timeout.";
                            data.Append(recData).Append(",CONNECT,1,connect timeout.");
                            break;
                        }
                    }
                    if (this.client != null)
                    {
                        flag = true;
                        timer.Change(0, 10000);
                        //data = recData + ",CONNECT,0,SUCCESS.";
                        data.Append(recData).Append(",CONNECT,0,SUCCESS.");
                    }
                }
            }
            else
            {
                //data = recData + ",CONNECT,1,please check connect status.";
                data.Append(recData).Append(",CONNECT,1,please check connect status.");
            }
            this.SendAVC(data.ToString());
            return flag;
        }
        public bool disconnect(string recData)
        {
            //string data = null;
            StringBuilder data = new StringBuilder();
            bool flag = false;
            if (client != null)
            {
                timer.Change(0, Timeout.Infinite);
                this.server.StopService();
                
               // client.Disconnect();
                if (this.client!=null)
                {
                    this.client.Disconnect();
                }
                this.client = null;
                this.server = null;
                //this.st
                flag = true;
                //data = recData + ",DISCONNECT,0,SUCCESS.";
                data.Append(recData).Append(",DISCONNECT,0,SUCCESS.");
            }
            else
            {
                //data = recData + ",DISCONNECT,1,please check connect status.";
                data.Append(recData).Append(",DISCONNECT,1,please check connect status.");
            }
            this.SendAVC(data.ToString());
            return flag;
        }
        public bool removeUUT(string[] param)
        {
            bool flag = false;
            //string data = null;
            StringBuilder data = new StringBuilder();
            switch (param[2])
            {
                case "101":
                    lefts.buffer[Convert.ToInt32(param[3])-1].Value = false;
                    getStatus("00000");
                    flag = true;
                    locationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), lefts.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    //data = param[0] + ",REMOVE_UUT," + param[2] + "," + param[3] + ",0,SUCCESS.";
                    data.Append(param[0]).Append(",REMOVE_UUT,").Append(param[2]).Append(",").Append(param[3]).Append(",0,SUCCESS.");
                    break;
                case "102":
                    rights.buffer[Convert.ToInt32(param[3])-1].Value = false;
                    getStatus("00000");
                    flag = true;
                    locationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), rights.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    //data = param[0] + ",REMOVE_UUT," + param[2] + "," + param[3] + ",0,SUCCESS.";
                    data.Append(param[0]).Append(",REMOVE_UUT,").Append(param[2]).Append(",").Append(param[3]).Append(",0,SUCCESS.");
                    break;
                case "21":
                    inBuffer.buffer[Convert.ToInt32(param[3])-1].Value = false;
                    getStatus("00000");
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), inBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value);
                   // data = param[0] + ",REMOVE_UUT," + param[2] + "," + param[3] + ",0,SUCCESS.";
                    data.Append(param[0]).Append(",REMOVE_UUT,").Append(param[2]).Append(",").Append(param[3]).Append(",0,SUCCESS.");
                    break;
                case "31":
                    audits.buffer[Convert.ToInt32(param[3])-1].Value = false;
                    getStatus("00000");
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), audits.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    //data = param[0] + ",REMOVE_UUT," + param[2] + "," + param[3] + ",0,SUCCESS.";
                    data.Append(param[0]).Append(",REMOVE_UUT,").Append(param[2]).Append(",").Append(param[3]).Append(",0,SUCCESS.");
                    break;
                case "11":
                    ngBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value = false;
                    getStatus("00000");
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), ngBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    //data = param[0] + ",REMOVE_UUT," + param[2] + "," + param[3] + ",0,SUCCESS.";
                    data.Append(param[0]).Append(",REMOVE_UUT,").Append(param[2]).Append(",").Append(param[3]).Append(",0,SUCCESS.");
                    break;
                case "12":
                    processBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value = false;
                    getStatus("00000");
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), processBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    //data = param[0] + ",REMOVE_UUT," + param[2] + "," + param[3] + ",0,SUCCESS.";
                    data.Append(param[0]).Append(",REMOVE_UUT,").Append(param[2]).Append(",").Append(param[3]).Append(",0,SUCCESS.");
                    break;
            }
            this.SendAVC(data.ToString());
            return flag;
        }
        public bool addUUT(string[] param)
        {
            bool flag = false;
            //string data = null;
            StringBuilder data = new StringBuilder();
            switch (param[2])
            {
                case "101":
                    lefts.buffer[Convert.ToInt32(param[3]) - 1].Value = true;
                    getStatus("00000");
                    flag = true;
                    locationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), lefts.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    //data = param[0] + ",ADD_UUT," + param[2] + "," + param[3] + ",0,SUCCESS.";
                    data.Append(param[0]).Append(",ADD_UUT,").Append(param[2]).Append(",").Append(param[3]).Append(",0,SUCCESS.");
                    break;
                case "102":
                    rights.buffer[Convert.ToInt32(param[3]) - 1].Value = true;
                    getStatus("00000");
                    flag = true;
                    locationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), rights.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    //data = param[0] + ",ADD_UUT," + param[2] + "," + param[3] + ",0,SUCCESS.";

                    data.Append(param[0]).Append(",ADD_UUT,").Append(param[2]).Append(",").Append(param[3]).Append(",0,SUCCESS.");
                    break;
                case "21":
                    inBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value = true;
                    getStatus("00000");
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), inBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    data.Append(param[0]).Append(",ADD_UUT,").Append(param[2]).Append(",").Append(param[3]).Append(",0,SUCCESS.");
                    break;
                case "31":
                    audits.buffer[Convert.ToInt32(param[3]) - 1].Value = true;
                    getStatus("00000");
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), audits.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    //data = param[0] + ",ADD_UUT," + param[2] + "," + param[3] + ",0,SUCCESS.";
                    data.Append(param[0]).Append(",ADD_UUT,").Append(param[2]).Append(",").Append(param[3]).Append(",0,SUCCESS.");
                    break;
            }
            this.SendAVC(data.ToString());
            return flag;
        }

        public bool makeError(string[] param)
        {
            bool flag = false;
            //string data = null;
            StringBuilder data = new StringBuilder();
            switch (param[2])
            {
                case "PICK":
                    pickFlag = true;
                    break;
                case "BIN":
                    break;
                case "LOAD":
                    break;
                case "UNLOAD":
                    unloadFlag = true;
                    break;
            }
            //data = param[0] + "," + param[1] + "," + param[2] + "," + param[3] + "," + param[4] + ",0,SUCCESS.";
            data.Append(param[0]).Append(",").Append(param[1]).Append(",").Append(param[2]).Append(",").Append(param[3]).Append(",").Append(param[4]).Append(",0,SUCCESS.");
            SendAVC(data.ToString());
            return flag;
        }
        public bool estopError(string mesId,int status)
        {
            bool flag = false;
            //string data=null;
            StringBuilder data = new StringBuilder();
            if (status==1) //pressed
            {
                estop.Value = true;
                Estop(estop.Value);
                getStatus("00000");
                flag = true;
            }
            else
            {
                estop.Value = false;
                Estop(estop.Value);
                getStatus("00000");
                flag = true;

            }
            //data = mesId + ",ESTOP," + status.ToString() + ",0,SUCCESS";
            data.Append(mesId).Append(",ESTOP,").Append(status.ToString()).Append(",0,SUCCESS");
            ioChangeEvent(estop.Name, estop.Value);
            this.SendAVC(data.ToString());
            return flag;
        }
        public bool air(string mesId,int status)
        {
            bool flag = false;
            //string data = null;
            StringBuilder data = new StringBuilder();
            if (status == 1)//abnormal
            {
                airPressure.Value = false;
                Air(airPressure.Value);
                flag = true;
            }
            else
            {
                airPressure.Value = true;
                Air(airPressure.Value);
                flag = true;
            }
           // data = mesId + ",AIR," + status.ToString() + ",0,SUCCESS";
            data.Append(mesId).Append(",AIR,").Append(status.ToString()).Append(",0,SUCCESS");
            this.SendAVC(data.ToString());
            return flag;
        }
        public bool power(string mesId,int status)
        {
            bool flag = false;
            //string data = null;
            StringBuilder data = new StringBuilder();
            if (status == 1)
            {
                electric.Value = false;
                this.Send(UNSOLICITED(electric.Name,"01002"));
                getStatus("00000");
                flag = true;
            }
            else
            {
                electric.Value = true;
                this.Send(UNSOLICITED(electric.Name, "0"));
                getStatus("00000");
                flag = true;
            }
            //data = mesId + ",POWER," + status.ToString() + ",0,SUCCESS";
            data.Append(mesId).Append(",POWER,").Append(status.ToString()).Append(",0,SUCCESS");
            this.SendAVC(data.ToString());
            return flag;
        }
        public void reset(string mesId)
        {
            string data = null;
            // pick  unload error
            pickFlag = false;
            unloadFlag = false;
            //connect error
            if (client == null)
            {

                ListenCam();
                timer.Change(0, 10000);
            }
            //estop
            estop.Value = false;
            getStatus("00000");
            ioChangeEvent(estop.Name, estop.Value);
            //air
            airPressure.Value = true;
            getStatus("00000");
            //electric
            electric.Value = true;
            getStatus("00000");
            UNSOLICITED(electric.Name,"0");
            data = mesId + ",RESET,0,SUCCESS";
            this.SendAVC(data);
        }
        #endregion
        //ms
        private static double timeDiff(DateTime DateTime1, DateTime DateTime2)
        {
            TimeSpan ts1 = new TimeSpan(DateTime1.Ticks);
            
            TimeSpan ts2 = new TimeSpan(DateTime2.Ticks);
            double t3 = ts1.TotalMilliseconds - ts2.TotalMilliseconds;
            //TimeSpan ts = ts1.Subtract(ts2).Duration();
            //dateDiff = ts.Milliseconds.ToString();
            //TimeSpan span = (TimeSpan)(DateTime1 - DateTime2);
           // dateDiff = span.TotalMilliseconds.ToString();
            return t3;
        }
        // Milliseconds
        private void delayTime(int times,int speed)
        {
            if (speed != 100)
            {
                DateTime timeEnd;
                double time = 0;
                DateTime timeStart = DateTime.Now;
                while (true)
                {
                    Thread.Sleep(2);
                    timeEnd = DateTime.Now;
                    time = timeDiff(timeEnd, timeStart);
                    if (Convert.ToInt32(time) >= times)
                    {
                        break;
                    }
                }
                currentPosition = targetPosition;
            }
            
        }
        public void readCSVFile()
        {
            string path = System.Environment.CurrentDirectory;
            StreamReader reader = new StreamReader(System.IO.Path.Combine(path, "testCSV.csv"), Encoding.UTF8);
          //  StreamReader reader = new StreamReader(path, Encoding.UTF8,true);
            string line = "";
            line = reader.ReadLine();
            while (line != "")
            {
                Thread.Sleep(2);
                string[] data = line.Split(',');
                if (data[0] == "")
                {
                    break;
                }
                if(data.Length>=3)
                {
                    csvData.Add(data[0] + data[1] + data[2], Convert.ToInt32(data[3]));
                    
                }
                line = reader.ReadLine();
            }
            reader.Close();
        }
        public void stopListenCam()
        {
            try
            {
                if (this.server.ServiceRunning)
                {
                    client.Disconnect();
                    client = null;
                    if (motionThread.IsAlive)
                    {
                        motionThread.Abort();
                    }
                    this.server.StopService();
                }
            }
            catch (System.Exception)
            {
            }
        }
        public void stopListenAVC()
        {
            try
            {
                if (this.serverAVC.ServiceRunning)
                {
                    clientAVC.Disconnect();
                    clientAVC = null;
                    this.serverAVC.StopService();
                }
            }
            catch (System.Exception)
            {
            }
        }
        private void requestChangeDevState(string mesId,int devID, int state)
        {
            DateTime timeEnd;
            double time = 0;
            DateTime timeStart = DateTime.Now;
            
            if (devID == 20)
            {
                if (state == 1)// request open
                {
                    rejectButton.Value = true;
                    getStatus("00000");
                    requestModeChange(20, 1, 0);
                    while (drawerFlag==false)//opened
                    {
                            Thread.Sleep(2);
                            timeEnd = DateTime.Now;
                            time = timeDiff(timeEnd, timeStart);
                            if (Convert.ToInt32(time) >= 10000)
                            {
                                break;
                            }
                    }
                    if(drawerFlag)
                    {
                        this.SendAVC(mesId + ",REQUEST_CHANGE_DEVSTATE," + devID + "," + state + ",0,Success");
                    }else
                    {
                        this.SendAVC(mesId + ",REQUEST_CHANGE_DEVSTATE," + devID + "," + state + ",1,timeout");
                    }
                    
                }
                else
                {
                    rejectButton.Value = false;
                    getStatus("00000");
                    requestModeChange(20, 0, 1);
                    while (drawerFlag)//closed
                    {
                            Thread.Sleep(4);
                            timeEnd = DateTime.Now;
                            time = timeDiff(timeEnd, timeStart);
                            if (Convert.ToInt32(time) >= 10000)
                            {
                                break;
                            }
                    }
                    if(drawerFlag==false)
                    {
                        this.SendAVC(mesId + ",REQUEST_CHANGE_DEVSTATE," + devID + "," + state + ",0,Success");
                    }else
                    {
                        this.SendAVC(mesId + ",REQUEST_CHANGE_DEVSTATE," + devID + "," + state + ",1,timeout");
                    }
                    
                }
            }
            else if (devID == 21)
            {
                if (state == 1)
                {
                    goldenButten.Value = true;
                    getStatus("00000");
                    requestModeChange(21, 1, 0);
                    Thread.Sleep(4);
                    while (goldenDoorFlag==false)
                    {
                        //time out
                            Thread.Sleep(4);
                            timeEnd = DateTime.Now;
                            time = timeDiff(timeEnd, timeStart);
                            if (Convert.ToInt32(time) >= 10000)
                            {
                                break;
                            }
                    }
                    if(goldenDoorFlag)
                    {
                        this.SendAVC(mesId + ",REQUEST_CHANGE_DEVSTATE," + devID + "," + state + ",0,Success");
                    }else
                    {
                        this.SendAVC(mesId + ",REQUEST_CHANGE_DEVSTATE," + devID + "," + state + ",1,timeout");
                    }
                    
                }
                else
                {
                    goldenButten.Value = false;
                    getStatus("00000");
                    requestModeChange(21, 0, 1);
                    Thread.Sleep(4);
                    while (goldenDoorFlag)
                    {
                        //time out
                            Thread.Sleep(4);
                            timeEnd = DateTime.Now;
                            time = timeDiff(timeEnd, timeStart);
                            if (Convert.ToInt32(time) >= 10000)
                            {
                                break;
                            }
                    }
                    if (goldenDoorFlag == false)
                    {
                        this.SendAVC(mesId + ",REQUEST_CHANGE_DEVSTATE," + devID + "," + state + ",0,Success");
                    }
                    else
                    {
                        this.SendAVC(mesId + ",REQUEST_CHANGE_DEVSTATE," + devID + "," + state + ",1,timeout");
                    }
                }
            }


        }
    }
}

