﻿using System;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Threading;

namespace Pegatron.Foundation
{
    /// <summary>
    /// Log Type Definition
    /// </summary>
    public enum ELogType
    {
        Error, //error message
        Information, //information message
        Warnning, //warnning message
    }

    public class Logger
    {
        public static string FileExtension = ".log";

        #region Start/Stop

        public static void Start(bool consoleEnabled = false)
        {
            LoggingCenter.DefaultCenter.Enabled = true;
            ConsoleLogger.Enabled = consoleEnabled;
            LoggingCenter.DefaultCenter.StartLogging();
        }

        public static void Disable(bool consoleEnabled = false)
        {
            LoggingCenter.DefaultCenter.Enabled = false;
        }

        public static void Stop()
        {
            LoggingCenter.DefaultCenter.ReqeustToExitLogging();
        }

        #endregion

        #region Logging
        public static bool Logging(
            string message,
            string filePath = null,
            object sender = null,
            ELogType logType = ELogType.Information,
            bool autoPrefix = true,
            bool consoleEnabled = false,
            bool autoLineFeed = true,
            bool notificationEnabled = true,
            string category = null
            )
        {
            return Logger.Logging(TimeCounter.Now, message, filePath, sender, logType, autoPrefix, consoleEnabled, autoLineFeed, notificationEnabled, category);
        }

        public static bool Logging(
            DateTime time,
            string message,
            string filePath = null,
            object sender = null,
            ELogType logType = ELogType.Information,
            bool autoPrefix = true,
            bool consoleEnabled = false,
            bool autoLineFeed = true,
            bool notificationEnabled = true,
            string category = null
            )
        {
            return LoggingCenter.DefaultCenter.Logging(time, message, filePath, sender, logType, autoPrefix, consoleEnabled, autoLineFeed, notificationEnabled, category);
        }
        #endregion

        #region Thread Logging
        /// <summary>
        /// Thread Logging function
        /// </summary>
        /// <param name="message">message to be output</param>
        /// <param name="addPrefixFlag">enable/disable timestamp prefix</param>
        public static void ThreadLogging(IManagedThread thread, string message, ELogType logType = ELogType.Information, bool notificationEnabled=false, string fileName = null)
        {
            if (thread != null && thread.DebugEnabled && message != null)
            {
                DateTime time = TimeCounter.Now;
                string defaultPrefix = Utility.CreateTag(thread.GetType().FullName, thread.Name, thread.ID)
                    + Utility.CreateTag(AssemblyFuncs.GetMethodName(2));
                if (string.IsNullOrEmpty(fileName))
                {
                    fileName = Utility.ToString(thread.Name) + Logger.FileExtension;
                }
                Logger.Logging(
                        time,
                        defaultPrefix + message,
                        System.IO.Path.Combine(FileLogger.LogsFolder, (FileLogger.GetDateTimeWithShift() + FileLogger.FileNameInnerConnector + fileName)),
                        thread,
                        logType,
                        true,
                        true,
                        true,
                        notificationEnabled,
                        null
                        );
            }
        }
        #endregion

        #region Default Logging

        public static bool DefaultLogging(
            string message,
            object sender = null,
            ELogType logType = ELogType.Information,
            bool autoPrefix = true,
            bool consoleEnabled = false
            )
        {
            return Logger.DefaultLogging(TimeCounter.Now, message, sender, logType, autoPrefix, consoleEnabled);
        }

        public static bool DefaultLogging(
            DateTime time,
            string message,
            object sender = null,
            ELogType logType = ELogType.Information,
            bool autoPrefix = true,
            bool consoleEnabled = false
            )
        {
            return LoggingCenter.DefaultCenter.DefaultLogging(time, message, sender, logType, autoPrefix, consoleEnabled);
        }

        #endregion

        #region Default Logging

        public static bool ErrorLogging(
            string message,
            object sender = null,
            ELogType logType = ELogType.Information,
            bool autoPrefix = true,
            bool consoleEnabled = false
            )
        {
            return Logger.ErrorLogging(TimeCounter.Now, message, sender, logType, autoPrefix, consoleEnabled);
        }

        public static bool ErrorLogging(
            DateTime time,
            string message,
            object sender = null,
            ELogType logType = ELogType.Information,
            bool autoPrefix = true,
            bool consoleEnabled = false
            )
        {
            return LoggingCenter.DefaultCenter.ErrorLogging(time, message, sender, logType, autoPrefix, consoleEnabled);
        }

        #endregion

        #region Exception Logging
        public static void ExceptionLogging(Exception ex)
        {
            ATSException.Logging(ex);
        }
        #endregion
    }
}
