﻿using System;
using System.IO;
using System.Text;

namespace Pegatron.Foundation
{
    /// <summary>
    /// FileLogger class contains some static functions for logging
    /// </summary>
    public class FileLogger
    {
        #region fields
        public static string DateFormat = "yyyy-MM-dd";

        public static string FileNameInnerConnector = "_";

        public static string FileLineFeedString = "\n";

        public static string DayShiftTag = "DayShift";

        public static string NightShiftTag = "NightShift";

        public static int ShiftCutPoint = 8;//0~11

        public static string LogsFolderName = "logs";

        protected static string LogsFolderPath = null;

        protected static object LockObj = new object();
        #endregion

        #region properties
        public static string LogsFolder
        {
            get
            {
                if (FileLogger.LogsFolderPath == null)
                {
                    lock (FileLogger.LockObj)
                    {
                        if (FileLogger.LogsFolderPath == null)
                        {
                            FileLogger.LogsFolderPath = System.IO.Path.Combine(AssemblyFuncs.GetMainModuleDirectory(), FileLogger.LogsFolderName);
                        }
                    }
                }
                return FileLogger.LogsFolderPath;
            }
            set
            {
                lock (FileLogger.LockObj)
                {
                    if (value != null)
                    {
                        FileLogger.LogsFolderPath = value;
                    }
                }
            }
        }
        #endregion

        /// <summary>
        /// writing log into file path
        /// </summary>
        /// <param name="content">content to be written</param>
        /// <param name="filePath">file path</param>
        /// <param name="autoLineFeed">auto add line feed</param>
        public static void WriteLogByPath(string content, string filePath, bool autoLineFeed = false)
        {
            if (content != null && filePath != null)
            {
                StreamWriter sw = null;
                try
                {
                    string folderPath = System.IO.Path.GetDirectoryName(filePath);
                    if (!string.IsNullOrEmpty(folderPath))
                    {
                        if (!Directory.Exists(folderPath))
                        {
                            Directory.CreateDirectory(folderPath);
                        }
                        sw = new StreamWriter(filePath, true);
                        if (autoLineFeed && !content.EndsWith(FileLogger.FileLineFeedString))
                        {
                            sw.WriteLine(content);
                        }
                        else
                        {
                            sw.Write(content);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ATSException.Throw(ex);
                }
                finally
                {
                    if (sw != null)
                    {
                        sw.Close();
                    }
                }
            }
        }

        /// <summary>
        /// writing log into file with giving folder and file name
        /// the absolute file path will be current directory + folder + file
        /// </summary>
        /// <param name="content">content to be written</param>
        /// <param name="folderName">folder name</param>
        /// <param name="fileName">file name</param>
        /// <param name="autoLineFeed">auto add line feed</param>
        public static void WriteLogByName(string content, string folderName, string fileName, bool autoLineFeed = false)
        {
            FileLogger.WriteLogByPath(content, Path.Combine(FileLogger.LogsFolder, folderName, (FileLogger.GetDateTimeWithShift() + FileLogger.FileNameInnerConnector + fileName)), autoLineFeed);
        }

        /// <summary>
        /// get shift string
        /// </summary>
        /// <returns>shift string like 'DayShift' or 'NightShift'</returns>
        public static string GetDateTimeWithShift()
        {
            if (TimeCounter.Now.Hour >= FileLogger.ShiftCutPoint && TimeCounter.Now.Hour < FileLogger.ShiftCutPoint + 12)
            {
                return TimeCounter.Now.ToString(FileLogger.DateFormat) + FileLogger.FileNameInnerConnector + FileLogger.DayShiftTag;
            }
            else if (TimeCounter.Now.Hour >= FileLogger.ShiftCutPoint + 12)
            {
                return TimeCounter.Now.ToString(FileLogger.DateFormat) + FileLogger.FileNameInnerConnector + FileLogger.NightShiftTag;
            }
            else
            {
                return TimeCounter.Now.AddDays(-1).ToString(FileLogger.DateFormat) + FileLogger.FileNameInnerConnector + FileLogger.NightShiftTag;
            }
        }
    }
}
