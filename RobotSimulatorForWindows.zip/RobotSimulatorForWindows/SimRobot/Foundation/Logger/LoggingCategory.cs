﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    class LoggingCategory
    {
        public string Category
        {
            get;
            set;
        }

        public bool Enabled
        {
            get;
            set;
        }

        public bool ConsoleEnabled
        {
            get;
            set;
        }

        public bool NotificationEnabled
        {
            get;
            set;
        }

        public int LogLevel
        {
            get;
            set;
        }

        public LoggingFileAttribute LogFileAttribute
        {
            get;
            set;
        }


        public LoggingInfoFormatter LogInfoFormatter
        {
            get;
            set;
        }

        public LoggingFileFormatter LogFileFormatter
        {
            get;
            set;
        }


        public LoggingCategory(string category, bool enabled, int logLevel, bool consoleEnabled, bool notificationEnabled, LoggingFileAttribute attribute,
            LoggingInfoFormatter logInfoFormatter, LoggingFileFormatter logFileFormatter)
        {
            this.Category = category;
            this.Enabled = enabled;
            this.LogLevel = logLevel;
            this.ConsoleEnabled = consoleEnabled;
            this.NotificationEnabled = notificationEnabled;
            this.LogFileAttribute = attribute;
            this.LogInfoFormatter = logInfoFormatter;
            this.LogFileFormatter = logFileFormatter;
        }
    }
}
