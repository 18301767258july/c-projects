﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    class LoggingFileAttribute
    {
        public string Category
        {
            get;
            set;
        }

        public string LogFolder
        {
            get;
            set;
        }

        public double MaxSizeMB
        {
            get;
            set;
        }

        public LoggingFileAttribute(string category, string logFolder, double maxSizeMB)
        {
            this.Category = category;
            this.LogFolder = logFolder;
            this.MaxSizeMB = maxSizeMB;
        }
    }
}
