﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

namespace Pegatron.Foundation
{
    public class LoggingInfo
    {
        public string Category
        {
            get;
            set;
        }

        public DateTime Time
        {
            get;
            set;
        }

        public string Message
        {
            get;
            set;
        }

        public string FileHead
        {
            get;
            protected set;
        }

        public ELogType LogType
        {
            get;
            protected set;
        }

        public object Sender
        {
            get;
            protected set;
        }

        public string FilePath
        {
            get;
            protected set;
        }

        public bool AutoPrefix
        {
            get;
            set;
        }

        public bool AutoLineFeed
        {
            get;
            set;
        }

        public bool ConsoleEnabled
        {
            get;
            set;
        }

        public bool NotificationEnabled
        {
            get;
            set;
        }

        public LoggingInfo(
            DateTime time,
            string message,
            string filePath,
            object sender = null,
            ELogType type = ELogType.Information
            )
            : this(time, message, filePath, sender, type, true, false, true, true, null, null)
        {
        }

        public LoggingInfo(
            DateTime time,
            string message,
            string filePath,
            object sender,
            ELogType logType,
            bool autoPrefix,
            bool consoleEnabled,
            bool autoLineFeed = true,
            bool notificationEnabled = true,
            string category = null,
            string fileHead = null
            )
        {
            this.Time = time;
            this.Message = message;
            this.FilePath = filePath;
            this.Sender = sender;
            this.LogType = logType;
            this.FileHead = fileHead;
            this.AutoPrefix = autoPrefix;
            this.ConsoleEnabled = consoleEnabled;
            this.AutoLineFeed = autoLineFeed;
            this.NotificationEnabled = notificationEnabled;
            this.Category = category;
        }
    }

    public class LoggingQueueManager : MessageQueueManager<LoggingInfo>
    {

        public override bool AddMessage(LoggingInfo loggingInfo)
        {
            bool result = false;
            this.PendingQueue.PerformWithLockWrite(() =>
            {
                if (this.MessagePurgeStarted || this.PendingQueue.Count > 0)
                {
                    result = this.PendingQueue.AddDevice(loggingInfo, baseLoggingInfo => this.Convert(baseLoggingInfo, this.PendingQueue), convertedLoggingInfo => convertedLoggingInfo != null);
                }
                else
                {
                    result = this.WorkingQueue.AddDevice(loggingInfo, baseLoggingInfo => this.Convert(baseLoggingInfo, this.WorkingQueue), convertedLoggingInfo => convertedLoggingInfo != null);
                }
            });
            return result;
        }

        protected LoggingInfo Convert(LoggingInfo baseLoggingInfo, QueueManager<LoggingInfo> queue)
        {
            LoggingInfo convertedLoggingInfo = null;
            string defaultPrefix = baseLoggingInfo.AutoPrefix
                ? (Utility.CreateTag(Utility.GetTimeString(baseLoggingInfo.Time)) + Utility.CreateTag(baseLoggingInfo.LogType.ToString()))
                : string.Empty;
            baseLoggingInfo.Message = defaultPrefix + (Utility.ToString(baseLoggingInfo.Message, string.Empty));
            baseLoggingInfo.AutoPrefix = false;
            if (baseLoggingInfo.AutoLineFeed)
            {
                if (baseLoggingInfo.Message == null || !baseLoggingInfo.Message.EndsWith(FileLogger.FileLineFeedString))
                {
                    baseLoggingInfo.Message = Utility.ToString(baseLoggingInfo.Message, string.Empty) + FileLogger.FileLineFeedString;
                }
                baseLoggingInfo.AutoLineFeed = false;
            }
            LoggingInfo existedLoggingInfo = queue.GetDevice(
                log => log != null
                    && log.FilePath == baseLoggingInfo.FilePath
                    && log.ConsoleEnabled == baseLoggingInfo.ConsoleEnabled
                    && log.FileHead == baseLoggingInfo.FileHead
                    && log.Sender == baseLoggingInfo.Sender
                    && log.LogType == baseLoggingInfo.LogType
                );
            if (existedLoggingInfo != null)
            {
                existedLoggingInfo.Message = Utility.ToString(existedLoggingInfo.Message, string.Empty)
                    + Utility.ToString(baseLoggingInfo.Message, string.Empty);
                convertedLoggingInfo = null;
            }
            else
            {
                convertedLoggingInfo = baseLoggingInfo;
            }
            return convertedLoggingInfo;
        }
    }

    public class LoggingQueue : MessageProcessor<LoggingInfo>, IMessageHandler<LoggingInfo>
    {

        protected LoggingQueueManager mLoggingQueueManager = new LoggingQueueManager();
        public string FilePath
        {
            get;
            protected set;
        }

        public LoggingQueue()
            : this(null)
        {

        }

        public LoggingQueue(string name, string filePath = null, bool enableCombination = true)
            : base(name)
        {
            this.DebugEnabled = false;
            this.FilePath = filePath;
            this.MessageHandler = this;
            this.MessageManager = mLoggingQueueManager;
        }

        public virtual void PreHandling(LoggingInfo loggingInfo)
        {

        }

        public virtual IExitCode HandleMessage(LoggingInfo loggingInfo)
        {
            IExitCode exitCode = null;
            try
            {
                if (loggingInfo != null)
                {
                    string filePath = Utility.ToString(loggingInfo.FilePath, this.FilePath);
                    if (!string.IsNullOrEmpty(loggingInfo.FileHead) &&
                        !string.IsNullOrEmpty(filePath) &&
                        System.IO.Path.IsPathRooted(filePath) &&
                        !System.IO.File.Exists(filePath))
                    {
                        FileLogger.WriteLogByPath(loggingInfo.FileHead, filePath);
                    }
                    FileLogger.WriteLogByPath(loggingInfo.Message, filePath, false);
                    if (loggingInfo.ConsoleEnabled)
                    {
                        ConsoleLogger.TraceLog(loggingInfo.Message, loggingInfo.LogType, loggingInfo.Sender);
                    }
                    exitCode = ExitCode.ZeroCode;
                }
                else
                {
                    exitCode = ExitCode.UnexpectedCode;
                }
            }
            catch (Exception ex)
            {
                exitCode = ExitCode.CreateExitCode(ExitCode.Unexpected, ex.Message, null, ex);
            }
            finally
            {
            }
            return exitCode;
        }

        public virtual void PostHandling(LoggingInfo loggingInfo, IExitCode exitCode)
        {
            return;
        }
    }
}
