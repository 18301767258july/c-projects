﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pegatron.Foundation;
using Pegatron.Foundation.Xml;

namespace Pegatron.Foundation
{
    /// <summary>
    /// 
    /// </summary>
    /// <author>
    /// Brice_Du
    /// </author>
    public interface IComponent : ILoadable<XDict>, ISyncExec<object>, IAsyncExec<object>
    {
    }
}
