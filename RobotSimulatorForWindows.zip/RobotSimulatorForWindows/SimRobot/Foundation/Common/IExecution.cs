﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    public interface ISyncExec<TArgs>
    {
        IExitCode SyncExec(TArgs args);

        bool RequestExitSyncExec();
    }

    public interface IAsyncExec<TArgs>
    {
        bool Running
        {
            get;
        }

        bool Finished
        {
            get;
        }

        bool ExitRequested
        {
            set;
            get;
        }

        IExitCode FinishCode
        {
            get;
        }

        bool AsyncExec(IAsyncExecCallback<TArgs> observer, TArgs args);

        bool StopExec(int timeoutMilliseconds);

        bool AbortExec(int timeoutMilliseconds);

        bool WaitUntilExit(int timeoutMilliseconds);
    }

    public interface IAsyncExecCallback<TArgs>
    {
        void AsyncExecCallback(IAsyncExec<TArgs> target, IExitCode exitCode, TArgs args);
    }

    public interface IAsyncExecPool<TElement> : IAsyncExec<object>
    {
        bool PurgeStarted
        {
            get;
            set;
        }
        bool AddPoolElements(params TElement[] elements);
        bool WaitUntilEmpty(int timeoutMilliseconds);
    }
}