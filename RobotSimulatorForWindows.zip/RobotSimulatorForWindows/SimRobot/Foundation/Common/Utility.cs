using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Reflection;
using Pegatron.Foundation;
using Pegatron.Foundation.Xml;
using System.Windows.Forms;

namespace Pegatron.Foundation
{
    /// <summary>
    /// Common Class that contains static common functions
    /// </summary>
    /// <author>
    /// Brice_Du
    /// </author>
    public class Utility
    {
        #region byte to numic string
        public static string AppendZeroStringWithSpecifiedLengh(string source, int limit)
        {
            string result = string.IsNullOrEmpty(source) ? string.Empty : source;
            int lenghToBeAppend = limit - source.Length;
            while (lenghToBeAppend-- > 0)
            {
                result = "0" + result;
            }
            return result;
        }

        public static string Byte2StringWithBase(byte aByte, int toBase)
        {
            string result = Convert.ToString(aByte, toBase);
            switch (toBase)
            {
                case 2:
                    result = Utility.AppendZeroStringWithSpecifiedLengh(result, 4);
                    break;
                case 8:
                    result = Utility.AppendZeroStringWithSpecifiedLengh(result, 3);
                    break;
                case 10:
                    result = Utility.AppendZeroStringWithSpecifiedLengh(result, 3);
                    break;
                case 16:
                    result = Utility.AppendZeroStringWithSpecifiedLengh(result, 2);
                    break;
                default:
                    break;
            }
            return result;
        }

        public static string Bytes2StringWithBase16(byte[] bytes)
        {
            return Utility.Bytes2StringWithBase(bytes, 16);
        }

        public static string Bytes2StringWithBase10(byte[] bytes)
        {
            return Utility.Bytes2StringWithBase(bytes, 10);
        }

        public static string Bytes2StringWithBase8(byte[] bytes)
        {
            return Utility.Bytes2StringWithBase(bytes, 8);
        }

        public static string Bytes2StringWithBase2(byte[] bytes)
        {
            return Utility.Bytes2StringWithBase(bytes, 2);
        }

        public static string Bytes2StringWithBase(byte[] bytes, int toBase)
        {
            string result = string.Empty;
            if (bytes != null)
            {
                foreach(byte aByte in bytes)
                {
                    string temp = Utility.Byte2StringWithBase(aByte, toBase);
                    if (string.IsNullOrEmpty(result))
                    {
                        result += temp;
                    }
                    else
                    {
                        result += (" " + temp);
                    }
                }
            }
            return result;
        }
        #endregion

        #region UI
        public const string TextBoxNewLineString = "\r\n";
        public const string TextWhiteSpaceString = " ";

        public static string ConvertUISpecialCharacters(string source)
        {
            source = (source == null ? string.Empty : source);
            source = source.Replace("\r", "\\r");
            source = source.Replace("\n", "\\n");
            source = source.Replace("\t", "\\t");
            return source;
        }

        public static void UpdateTextBox(TextBox textBox, string message, DateTime time, bool enableNewLine = false,
            bool enableDataTime = false, bool enableUpdateTime = false, bool appendEnabled = false)
        {
            if (textBox != null)
            {
                if (enableNewLine)
                {
                    message = (message == null ? string.Empty : message) + TextBoxNewLineString;
                }
                if (enableDataTime)
                {
                    string dataTimestamp = Utility.GetTimeString(time);
                    message = Utility.CreateTag("Data:" + dataTimestamp) + TextWhiteSpaceString + (message == null ? string.Empty : message);
                    Utility.UpdateTextBox(textBox, message, enableUpdateTime, appendEnabled);
                }
                else
                {
                    Utility.UpdateTextBox(textBox, message, enableUpdateTime, appendEnabled);
                }
            }
        }

        public static void UpdateTextBox(TextBox textBox, string message, bool enableUpdateTime = false, bool appendEnabled =false)
        {
            if (textBox != null && !textBox.IsDisposed)
            {
                if (textBox.InvokeRequired)
                {
                    textBox.BeginInvoke(new Action<TextBox, string, bool, bool>(Utility.UpdateTextBox), textBox, message, enableUpdateTime, appendEnabled);
                }
                else
                {
                    if (enableUpdateTime)
                    {
                        string updateTimestamp = Utility.GetNowTimeString();
                        message = Utility.CreateTag("UI:" + updateTimestamp) + TextWhiteSpaceString + (message == null ? string.Empty : message);
                    }
                    if (appendEnabled)
                    {
                        message = (message == null ? string.Empty : message);
                        textBox.AppendText(message);
                    }
                    else
                    {
                        textBox.Text = message;
                    }
                    Utility.ScrollTextBoxToEnd(textBox);
                }
            }
        }

        public static void ScrollTextBoxToEnd(TextBox textBox)
        {
            if (textBox != null && !textBox.IsDisposed)
            {
                if (textBox.InvokeRequired)
                {
                    textBox.BeginInvoke(new Action<TextBox>(Utility.ScrollTextBoxToEnd), textBox);
                }
                else
                {
                    if (string.IsNullOrEmpty(textBox.SelectedText))
                    {
                        textBox.Select(textBox.TextLength, 0);
                        textBox.ScrollToCaret();
                    }
                }
            }
        }

        public static void UpdateCommConnection(TextBox textBox, string message, DateTime time, string fromEndPoint, string toEndPoint, bool succeed = true, object error = null)
        {
            Utility.UpdateCommMessageWithType(textBox, message, "connect", time, fromEndPoint, toEndPoint, succeed, error);
        }

        public static void UpdateCommRecv(TextBox textBox, byte[] bytes, DateTime time, string fromEndPoint, string toEndPoint, bool succeed = true, object error = null)
        {
            Utility.UpdateCommRecv(textBox, Encoding.ASCII.GetString(bytes), time, fromEndPoint, toEndPoint, succeed, error);
        }

        public static void UpdateCommRecv(TextBox textBox, string message, DateTime time, string fromEndPoint, string toEndPoint, bool succeed = true, object error = null)
        {
            Utility.UpdateCommMessageWithType(textBox, message, "recv", time, fromEndPoint, toEndPoint, succeed, error, false);
        }

        public static void UpdateCommRecvRaw16(TextBox textBox, byte[] bytes, DateTime time, string fromEndPoint, string toEndPoint, bool succeed = true, object error = null)
        {
            Utility.UpdateCommMessageWithType(textBox, Utility.Bytes2StringWithBase16(bytes), "recv-raw(16)", time, fromEndPoint, toEndPoint, succeed, error, false);
        }

        public static void UpdateCommSend(TextBox textBox, string message, DateTime time, string fromEndPoint, string toEndPoint, bool succeed = true, object error = null)
        {
            Utility.UpdateCommMessageWithType(textBox, message, "send", time, fromEndPoint, toEndPoint, succeed, error);
        }

        public static void UpdateCommSendRaw16(TextBox textBox, byte[] bytes, DateTime time, string fromEndPoint, string toEndPoint, bool succeed = true, object error = null)
        {
            Utility.UpdateCommMessageWithType(textBox, Utility.Bytes2StringWithBase16(bytes), "send-raw(16)", time, fromEndPoint, toEndPoint, succeed, error);
        }

        public static void UpdateCommMessageWithType(TextBox textBox, string message, string type, DateTime time, string fromEndPoint, string toEndPoint, bool succeed = true, object error = null, bool startWithFrom = true)
        {
            string from = (fromEndPoint == null ? "unknown FROM" : fromEndPoint);
            string to = (toEndPoint == null ? "unknown End" : toEndPoint);
            string fromTo = startWithFrom ? (from + "->" + to) : (to + "<-" + from);

            type = (type == null ? string.Empty : type);

            message = Utility.ConvertUISpecialCharacters(message);
            message = fromTo + Utility.TextWhiteSpaceString + Utility.CreateTag(type)
                + Utility.TextWhiteSpaceString + Utility.CreateTag(message)
                + (succeed ? string.Empty : (Utility.TextWhiteSpaceString + "failed"))
                + (error == null ? string.Empty : (Utility.TextWhiteSpaceString + "with error:" + Utility.TextWhiteSpaceString + error));

            Utility.UpdateTextBox(textBox, message, time, true, true, true, true);
        }

        public static void UpdateCommMessageWithType(TextBox textBox, string message, string type, DateTime time, string localEndPoint, bool succeed = true, object error = null)
        {
            string local = (localEndPoint == null ? "unknown LOCAL" : localEndPoint);

            type = (type == null ? string.Empty : type);

            message = (message == null ? string.Empty : message);
            message = Utility.ConvertUISpecialCharacters(message);
            message = local + Utility.TextWhiteSpaceString + Utility.CreateTag(type)
                + Utility.TextWhiteSpaceString + Utility.CreateTag(message)
                + (succeed ? string.Empty : (Utility.TextWhiteSpaceString + "failed"))
                + (error == null ? string.Empty : (Utility.TextWhiteSpaceString + "with error:" + Utility.TextWhiteSpaceString + error));

            Utility.UpdateTextBox(textBox, message, time, true, true, true, true);
        }
        #endregion

        #region Create Tag
        public static string CreateTag(string tagPrefix, string tagSuffix, string tagClass, string tagInnerSeparator, object tagContent)
        {
            return Utility.ToString(tagPrefix, string.Empty)
                + (string.IsNullOrEmpty(tagClass) ? Utility.ToString(tagContent) : (tagClass + Utility.ToString(tagInnerSeparator, string.Empty) + Utility.ToString(tagContent)))
                + Utility.ToString(tagSuffix, string.Empty);
        }

        public static string CreateTag(string tagClass, object tagContent, object tagSubContent)
        {
            return Utility.CreateTag("[", "]", tagClass, ": ", (Utility.ToString(tagContent) + "(" + Utility.ToString(tagSubContent) + ")"));
        }

        public static string CreateTag(string tagClass, object tagContent)
        {
            return Utility.CreateTag("[", "]", tagClass, ": ", tagContent);
        }

        public static string CreateTag(object tagContent)
        {
            return Utility.CreateTag(null, tagContent);
        }
        #endregion

        #region Get Random result for test
        /// <summary>
        /// Get random result 
        /// </summary>
        /// <param name="failRate">specify fail rate, 0~1</param>
        /// <returns>random result pass or fail based on fail rate</returns>
        public static bool GetRandomResult(double failRate = 0.5)
        {
            return new Random().NextDouble() > failRate;
        }
        #endregion

        #region Time string
        /// <summary>
        /// Get time string for current time with default format("yyyy-MM-dd HH:mm:ss.fff")
        /// </summary>
        /// <returns>string of current time</returns>
        public static string GetNowTimeString()
        {
            return GetTimeString(TimeCounter.Now);
        }

        /// <summary>
        /// Get time string for current time with specified format
        /// </summary>
        /// <param name="format">the string format</param>
        /// <returns>string of current time</returns>
        public static string GetNowTimeString(string format)
        {
            return GetTimeString(TimeCounter.Now, format);
        }

        /// <summary>
        /// Get time string for the specified time with specified format
        /// </summary>
        /// <param name="time">the time data to generate string</param>
        /// <param name="format">the string format</param>
        /// <returns>string of time</returns>
        public static string GetTimeString(DateTime time, string format = "yyyy-MM-dd HH:mm:ss.fff")
        {
            return time.ToLocalTime().ToString(format);//time.Millisecond.ToString(format);
        }
        #endregion

        #region type array
        /// <summary>
        /// Get a new Type Array by Adding a type into a existed type array
        /// </summary>
        /// <param name="type">type for adding</param>
        /// <param name="Types">type array to be added a new type</param>
        /// <returns>a new type array</returns>
        public static Type[] NewTypeArrayByAddType(Type type, params Type[] Types)
        {
            List<Type> typeArray = null;
            if (Types != null)
            {
                typeArray = Types.ToList<Type>();
            }
            if (typeArray == null)
            {
                typeArray = new List<Type>();
            }
            if (!typeArray.Contains(type))
            {
                typeArray.Add(type);
            }
            return typeArray.ToArray();
        }

        public static Type[] GetTypeArray(object[] objs)
        {
            List<Type> typeArray = new List<Type>();
            if(objs!=null)
            {
                foreach (object obj in objs)
                {
                    typeArray.Add(obj.GetType());
                }
            }
            return typeArray.ToArray();
        }
        #endregion

        #region array to list
        public static List<object> CreateObjectList(params object[] objects)
        {
            List<object> result = null;
            if (objects != null)
            {
                result = objects.ToList<object>();
            }
            return result;
        }

        public static List<string> CreateStringList(params string[] strings)
        {
            List<string> result = null;
            if (strings != null)
            {
                result = strings.ToList<string>();
            }
            return result;
        }
        #endregion

        #region lock
        /// <summary>
        /// Lock a object instance using Monitor.Enter(obj) function
        /// </summary>
        /// <param name="lockObj">object instance to be locked</param>
        public static void Lock(object lockObj)
        {
            if (lockObj != null)
            {
                Monitor.Enter(lockObj);
            }
        }

        /// <summary>
        /// Unlock a object instance using Monitor.Exit(obj) function 
        /// </summary>
        /// <param name="lockObj">object instance to be unlocked</param>
        public static void Unlock(object lockObj)
        {
            if (lockObj != null)
            {
                Monitor.Exit(lockObj);
            }
        }

        /// <summary>
        /// TryLock a object instance using Monitor.TryEnter(obj) function
        /// </summary>
        /// <param name="lockObj">object instance to be trylocked</param>
        /// <param name="milliSeconds">milliseconds to try</param>
        /// <returns></returns>
        public static bool TryLock(object lockObj, int milliSeconds = 0)
        {
            bool result = false;
            if (lockObj != null)
            {
                if (milliSeconds == 0)
                {
                    result = Monitor.TryEnter(lockObj);
                }
                else
                {
                    result = Monitor.TryEnter(lockObj, milliSeconds);
                }
            }
            return result;
        }

        #endregion

        #region split / combine string
        /// <summary>
        /// generate string list by separator. will remove empty entries
        /// </summary>
        /// <param name="sourceString">source string that to be split</param>
        /// <param name="stringSeparator">string separator</param>>
        /// <returns></returns>
        public static string[] SplitString(string source, params string[] stringSeparators)
        {
            string[] stringArray = null;
            if (!string.IsNullOrEmpty(source))
            {
                if ( stringSeparators != null && stringSeparators.Length > 0 )
                {
                    stringArray = source.Split(stringSeparators, StringSplitOptions.RemoveEmptyEntries);
                }
                else
                {
                    stringArray = new string[] { source };
                }
            }
            return stringArray;
        }

        public static string SplitOutIncompleteData(string source, string seperator, ref string incompleteData)
        {
            string result = source;
            incompleteData = null;
            if (!string.IsNullOrEmpty(source) && !string.IsNullOrEmpty(seperator))
            {
                if (!source.EndsWith(seperator))
                {//not end with
                    int index = source.LastIndexOf(seperator);
                    if (index != -1)
                    {//found the index
                        if (index != (source.Length - 1))
                        {//found the index and index isn't the last index
                            result = source.Substring(0, index + 1);
                            incompleteData = source.Substring(index + 1, source.Length - index - 1);
                        }
                    }
                    else
                    {
                        result = null;
                        incompleteData = source;
                    }
                }
            }
            return result;
        }

        public static string[] SplitStringWithSeperatorKept(string source, string seperator, StringSplitOptions options)
        {
            List<string> result = new List<string>();
            
            if (!string.IsNullOrEmpty(seperator))
            {
                if (!string.IsNullOrEmpty(source))
                {
                    int index = source.IndexOf(seperator);
                    while (index != -1)
                    {//foud the index
                        string seperated = source.Substring(0, index + 1);
                        if (!string.IsNullOrEmpty(seperated) || options != StringSplitOptions.RemoveEmptyEntries)
                        {
                            result.Add(seperated);
                        }
                        source = source.Substring(index + 1, source.Length - index - 1);
                        if (string.IsNullOrEmpty(source))
                        {//source is null or empty
                            break;
                        }
                        else
                        {//source is not null or empty
                            index = source.IndexOf(seperator);
                        }
                    }
                }
            }

            if (!string.IsNullOrEmpty(source) || options != StringSplitOptions.RemoveEmptyEntries)
            {
                result.Add(source);
            }
            return result.ToArray();
        }

        public static string CombineString(string stringSeparator, params string[] subStrings)
        {
            return Utility.CombineString(subStrings, stringSeparator);
        }

        public static string CombineString(string[] subStrings, string stringSeparator)
        {
            string result = string.Empty;
            if (stringSeparator != null && subStrings != null && subStrings.Length > 0)
            {
                foreach( string subString in subStrings )
                {
                    if( subString != null )
                    {
                        result += ( ( ( string.IsNullOrEmpty(result) || stringSeparator == null ) ? string.Empty : stringSeparator ) + subString );
                    }
                }
            }
            return result;
        }
        #endregion

        #region array contails / equals / null check

        public static bool IsNullOrNullElements(params object[] objects)
        {
            bool result = true;
            if( objects != null && objects.Length > 0 )
            {
                foreach(object obj in objects)
                {
                    if( obj != null )
                    {
                        result = false;
                        break;
                    }
                }
            }
            return result;
        }

        public static bool IsContainsNullElements(params object[] objects)
        {
            bool result = false;
            if( objects != null && objects.Length > 0 )
            {
                foreach( object obj in objects )
                {
                    if( obj == null )
                    {
                        result = true;
                        break;
                    }
                }
            }
            return result;
        }

        public static bool ArrayElementContains(List<object> one, List<object> another)
        {
            bool result = false;
            if (one != null && another != null)
            {
                result = true;
                foreach (object element in another)
                {
                    if (!one.Contains(element))
                    {
                        result = false;
                        break;
                    }
                }
            }
            return result;
        }

        public static bool ArrayContainsAny(List<object> one, List<object> another)
        {
            bool result = false;
            if( one != null && another != null )
            {
                foreach( object element in another )
                {
                    if( one.Contains(element) )
                    {
                        result = true;
                        break;
                    }
                }
            }
            return result;
        }

        public static bool ArrayElementEquals(List<object> one, List<object> another)
        {
            return Utility.ArrayElementContains(one, another) && Utility.ArrayElementContains(another,one);
        }

        public static List<object> ArrayIntersect(List<object> one, List<object> another)
        {
            List<object> result = null;
            if( one != null && another != null )
            {
                List<object> biggerList = ( one.Count > another.Count ? one : another );
                List<object> smallerList = ( one.Count > another.Count ? another : one );
                foreach( object obj in smallerList )
                {
                    if( biggerList.Contains(obj) )
                    {
                        if( result == null ) result = new List<object>();
                        if( result != null )
                        {
                            result.Add(obj);
                        }
                    }
                }
            }
            return result;
        }

        public static List<object> ArrayComplement(List<object> source, List<object> sub)
        {
            List<object> result = null;
            if( source != null )
            {
                result = new List<object>(source);
                if( result != null && sub != null )
                {
                    result.RemoveAll(obj => sub.Contains(obj));
                }
            }
            return result;
        }
        #endregion

        #region [x,y,z]
        /// <summary>
        /// get coordinate from a string([x,y,z] is valid format)
        /// </summary>
        /// <param name="locationString">should be [x,y,z] format string</param>
        /// <param name="x">to get double value of x-axis</param>
        /// <param name="y">to get double value of y-axis</param>
        /// <param name="z">to get double value of z-axis</param>
        /// <returns></returns>
        public static bool GetCoordiante3DValue(string coordinateString, ref double x, ref double y, ref double z)
        {
            bool result = false;
            try
            {
                if( coordinateString != null )
                {
                    string coordinateStringAfterTrim = coordinateString.Trim();
                    if( coordinateStringAfterTrim != null && coordinateStringAfterTrim.Length > 6 )
                    {
                        string coordinateStringAfterDelPrefixSuffix = coordinateStringAfterTrim.Substring(1, coordinateStringAfterTrim.Length - 2);
                        if( !string.IsNullOrEmpty(coordinateStringAfterDelPrefixSuffix) )
                        {
                            string[] strArray = coordinateStringAfterDelPrefixSuffix.Split(new char[] { ',', ' ' }, System.StringSplitOptions.RemoveEmptyEntries);
                            if( strArray != null && strArray.Length == 3 )
                            {
                                x = Convert.ToDouble(strArray[0]);
                                y = Convert.ToDouble(strArray[1]);
                                z = Convert.ToDouble(strArray[2]);
                                result = true;
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result = false;
                ATSException.Throw(ex);
            }
            return result;
        }
        /// <summary>
        /// get coordinate from a string([x,y] is valid format)
        /// </summary>
        /// <param name="locationString">should be [x,y] format string</param>
        /// <param name="x">to get double value of x-axis</param>
        /// <param name="y">to get double value of y-axis</param>
        /// <returns></returns>
        public static bool GetCoordiante2DValue(string coordinateString, ref double x, ref double y)
        {
            bool result = false;
            try
            {
                if( coordinateString != null )
                {
                    string coordinateStringAfterTrim = coordinateString.Trim();
                    if( coordinateStringAfterTrim != null && coordinateStringAfterTrim.Length > 4 )
                    {
                        string coordinateStringAfterDelPrefixSuffix = coordinateStringAfterTrim.Substring(1, coordinateStringAfterTrim.Length - 2);
                        if( !string.IsNullOrEmpty(coordinateStringAfterDelPrefixSuffix) )
                        {
                            string[] strArray = coordinateStringAfterDelPrefixSuffix.Split(new char[] { ',', ' ' }, System.StringSplitOptions.RemoveEmptyEntries);
                            if( strArray != null && strArray.Length == 2 )
                            {
                                x = Convert.ToDouble(strArray[0]);
                                y = Convert.ToDouble(strArray[1]);
                                result = true;
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result = false;
                ATSException.Throw(ex);
            }
            return result;
        }

        /// <summary>
        /// convert coordinate to a formated string->[0.000,0.000,0.000]
        /// </summary>
        /// <param name="x">double value of x-axis</param>
        /// <param name="y">double value of y-axis</param>
        /// <param name="z">double value of z-axis</param>
        public static string GetCoordianteString(double x, double y, double z)
        {
            return "[" + x.ToString("F3") + "," + y.ToString("F3") + "," + z.ToString("F3") + "]";
        }

        /// <summary>
        /// convert coordinate to a formated string->[0.000,0.000]
        /// </summary>
        /// <param name="x">double value of x-axis</param>
        /// <param name="y">double value of y-axis</param>
        /// <param name="z">double value of z-axis</param>
        public static string GetCoordianteString(double x, double y)
        {
            return "[" + x.ToString("F3") + "," + y.ToString("F3") + "]";
        }
        #endregion

        #region ToString
        public static string ToString(object obj, string defaultString = "null")
        {
            return ( obj == null || obj.ToString() == null ) ? defaultString : obj.ToString();
        }
        #endregion
    }
}
