﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    /// <summary>
    /// Loadable interface
    /// </summary>
    public interface ILoadable<TClass>
    {
        IExitCode Load(TClass obj);
    }
}
