﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    /// <summary>
    /// interface to describe exit code of a action
    /// </summary>
    public interface IExitCode
    {
        /// <summary>
        /// int type code, usually 0 means succeed / pass
        /// </summary>
        int Code
        {
            get;
            set;
        }

        /// <summary>
        /// string type value to describe the result
        /// </summary>
        string Description
        {
            get;
            set;
        }

        /// <summary>
        /// exception along the code
        /// </summary>
        Exception Exception
        {
            get;
            set;
        }

        /// <summary>
        /// extra arguments along the code
        /// </summary>
        object Args
        {
            get;
            set;
        }

        /// <summary>
        /// low level codes to achieve nested structure
        /// </summary>
        IExitCode[] LowLevelExitCodes
        {
            get;
            set;
        }
    }
}
