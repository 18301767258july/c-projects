﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    /// <summary>
    /// Class for Exit Code
    /// </summary>
    public class ExitCode : IExitCode
    {
        /// <summary>
        /// Zero code
        /// </summary>
        public const int Zero = 0;

        /// <summary>
        /// -1
        /// </summary>
        public const int Unexpected = -1;

        /// <summary>
        /// int type value to indicate the result. Usually 0 represents pass and others represent fail
        /// </summary>
        public int Code
        {
            get;
            set;
        }

        /// <summary>
        /// string type value to describe the result
        /// </summary>
        public string Description
        {
            get;
            set;
        }

        /// <summary>
        /// exception along the code
        /// </summary>
        public Exception Exception
        {
            get;
            set;
        }

        /// <summary>
        /// extra arguments along the code
        /// </summary>
        public object Args
        {
            get;
            set;
        }
        
        /// <summary>
        /// low level codes to achieve nested structure
        /// </summary>
        public IExitCode[] LowLevelExitCodes
        {
            get;
            set;
        }
        
        /// <summary>
        /// default ExitCode with default zero code value;
        /// </summary>
        public static ExitCode ZeroCode
        {
            get
            {
                return ExitCode.ZeroExitCode(string.Empty);
            }
        }

        /// <summary>
        /// unexcepted ExitCode with unexpected code value;
        /// </summary>
        public static ExitCode UnexpectedCode
        {
            get
            {
                return ExitCode.UnexpectedExitCode(string.Empty);
            }
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public ExitCode()
            : this(ExitCode.Zero)
        {
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public ExitCode(int code)
            : this(code, string.Empty, null, null, null)
        {
        }

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="code">int type value</param>
        /// <param name="desc">string type description</param>
        /// <param name="lowLevelCode">code from low level</param>
        /// <param name="args">extra args</param>
        public ExitCode(int code, string desc, IExitCode lowLevelCode = null, Exception ex = null, object args = null)
        {
            this.Code = code;
            this.Description = desc;
            this.Exception = ex;
            this.Args = args;
            this.LowLevelExitCodes = (lowLevelCode != null ? new IExitCode[] { lowLevelCode } : null);
        }

        /// <summary>
        /// To string
        /// </summary>
        /// <returns>string description</returns>
        public override string ToString()
        {
            return Utility.CreateTag(
                this.GetType().FullName, 
                Utility.CreateTag(this.Code) + Utility.CreateTag(this.Description) + Utility.CreateTag(this.Args)
                );
        }

        public static ExitCode CreateExitCode(int code, string desc, IExitCode lowLevelCode = null, Exception ex = null, object args = null)
        {
            return new ExitCode(code, desc, lowLevelCode, ex, args);
        }

        /// <summary>
        /// Zero ExitCode
        /// </summary>
        public static ExitCode ZeroExitCode(string description = null)
        {
            return new ExitCode(ExitCode.Zero, description, null, null, null);
        }

        /// <summary>
        /// Unexpected ExitCode
        /// </summary>
        public static ExitCode UnexpectedExitCode(string description = null, Exception ex = null)
        {
            return new ExitCode(ExitCode.Unexpected, description, null, ex, null);
        }

        /// <summary>
        /// Unexpected ExitCode
        /// </summary>
        public static ExitCode ExceptionExitCode(Exception ex)
        {
            return new ExitCode(ExitCode.Unexpected, (ex != null ? ex.Message : null), null, ex, null);
        }
    }
}
