using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Pegatron.Foundation;
using Pegatron.Foundation.Xml;

namespace Pegatron.Automation
{
    public enum CoordinateAxis
    {
        AxisNone = 0,
        AxisX    = 1,
        AxisY    = 2,
        AxisZ    = 3,
    }

    /// <summary>
    /// Coordinate2D is a 2D Coordinate
    /// </summary>
    [XDict]
    public class Coordinate2D
    {
        #region properties
        [property: XDict]
        public double x
        {
            get;
            set;
        }
        [property: XDict]
        public double y
        {
            get;
            set;
        }
        #endregion

        #region constructor
        public Coordinate2D()
            : this(0, 0)
        {

        }
        public Coordinate2D(Coordinate2D coordinate2D)
            : this((coordinate2D == null) ? 0 : coordinate2D.x, (coordinate2D == null) ? 0 : coordinate2D.y)
        {
        }

        public Coordinate2D(double x, double y)
        {
            this.x = x;
            this.y = y;
        }
        #endregion

        #region functions
        /// <summary>
        /// description like [0,1]
        /// </summary>
        /// <returns>Coordinate string</returns>
        public override string ToString()
        {
            return Utility.GetCoordianteString(this.x, this.y);
        }

        public static Coordinate2D GetCoordinate2D(string coordinateString)
        {
            Coordinate2D result = null;
            double tempX = -1;
            double tempY = -1;
            if( Utility.GetCoordiante2DValue(coordinateString, ref tempX, ref tempY) )
            {
                result = new Coordinate2D(tempX, tempY);
            }
            return result;
        }

        /// <summary>
        /// compare Coordinate with anther Coordinate2D object
        /// if both X-Coordinate and Y-Coordinate are the same then return true
        /// </summary>
        /// <param name="obj">object to be compared with</param>
        /// <returns>comparision result</returns>
        public override bool Equals(object obj)
        {
            Coordinate2D another = obj as Coordinate2D;
            if (another != null)
            {

                return this.x == another.x && this.y == another.y;
            }
            else
            {
                return base.Equals(obj);
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();//????
        }

        /// <summary>
        /// + operate implementation
        /// </summary>
        /// <param name="one">the first coordinate</param>
        /// <param name="another">the second coordinate</param>
        /// <returns>coordinate after + </returns>
        public static Coordinate2D operator +(Coordinate2D one, Coordinate2D another)
        {
            Coordinate2D result = null;
            if (one != null && one is Coordinate2D && another != null && another is Coordinate2D)
            {
                result = new Coordinate2D(one.x + another.x, one.y + another.y);
            }
            return result;
        }

        /// <summary>
        /// Calculate distance to destination 2D coordinate
        /// </summary>
        /// <param name="desCoordinate">destination coordinate</param>
        /// <returns>distance</returns>
        public double DistanceTo(Coordinate2D desCoordinate)
        {
            double result = -1;
            if (desCoordinate != null && desCoordinate is Coordinate2D)
            {
                double offsetX = (desCoordinate.x - this.x);
                double offsetY = (desCoordinate.y - this.y);
                result = Math.Sqrt(Math.Pow(offsetX, 2) + Math.Pow(offsetY, 2));
            }
            return result;
        }

        /// <summary>
        /// compare distance with anther coodinate refer to a reference coordinate to see if it is nearer
        /// </summary>
        /// <param name="another">anther coodinate to be compared with</param>
        /// <param name="reference">reference coordinate</param>
        /// <returns>if distance less than anther coodinate then return true</returns>
        public bool IsNearer(Coordinate2D another, Coordinate2D reference = null)
        {
            bool result = false;
            if (reference == null) reference = new Coordinate2D(0, 0);
            if (another != null && another is Coordinate2D && reference != null && reference is Coordinate2D)
            {
                result = this.DistanceTo(reference) < another.DistanceTo(reference);
            }
            return result;
        }
        #endregion
    }

    /// <summary>
    /// Coordinate3D is a 3D Coordinate and inherited from Coordinate2D
    /// </summary>
    [XDict]
    public class Coordinate3D : Coordinate2D
    {
        #region properties
        [property: XDict]
        public double z
        {
            get;
            set;
        }
        #endregion

        #region constructor
        public Coordinate3D()
            : this(0, 0, 0)
        {

        }
        public Coordinate3D(double x, double y, double z):base(x,y)
        {
            this.z = z;
        }
        public Coordinate3D(Coordinate3D coordinate)
            : base(coordinate)
        {
            this.z = 0;
            if (coordinate != null) this.z = coordinate.z;
        }
        #endregion

        #region functions
        /// <summary>
        /// description like [0,1,1]
        /// </summary>
        /// <returns>Coordinate string</returns>
        public override string ToString()
        {
            return Utility.GetCoordianteString(this.x, this.y, this.z);
        }


        public static Coordinate3D GetCoordinate3D(string coordinateString)
        {
            Coordinate3D result = null;
            double tempX = -1;
            double tempY = -1;
            double tempZ = -1;
            if( Utility.GetCoordiante3DValue(coordinateString, ref tempX, ref tempY, ref tempZ) )
            {
                result = new Coordinate3D(tempX, tempY, tempZ);
            }
            return result;
        }

        /// <summary>
        /// Calculate distance to destination 3D coordinate
        /// </summary>
        /// <param name="desCoordinate">destination coordinate</param>
        /// <returns>distance</returns>
        public double DistanceTo(Coordinate3D desCoordinate)
        {
            double result = -1;
            if (desCoordinate != null && desCoordinate is Coordinate3D)
            {
                double offsetZ = (desCoordinate.z - this.z);
                result = Math.Sqrt(Math.Pow(base.DistanceTo(desCoordinate), 2) + Math.Pow(offsetZ, 2));
            }
            return result;
        }

        /// <summary>
        /// compare Coordinate with anther Coordinate3D object
        /// if X-Coordinate and Y-Coordinate and Z-Coordinate are the same then return true
        /// </summary>
        /// <param name="obj">object to be compared with</param>
        /// <returns>comparision result</returns>
        public override bool Equals(object obj)
        {
            Coordinate3D another = obj as Coordinate3D;
            if (another != null)
            {

                return (base.Equals(obj)) && this.z == (another).z;
            }
            else
            {
                return base.Equals(obj);
            }
        }

        /// <summary>
        /// + operate implementation
        /// </summary>
        /// <param name="one">the first coordinate</param>
        /// <param name="another">the second coordinate</param>
        /// <returns>coordinate after + </returns>
        public static Coordinate3D operator +(Coordinate3D one, Coordinate3D another)
        {
            Coordinate3D result = null;
            if (one != null && one is Coordinate3D && another != null && another is Coordinate3D)
            {
                result = new Coordinate3D(one.x + another.x, one.y + another.y, one.z + another.z);
            }
            return result;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();//????
        }

        /// <summary>
        /// compare distance with anther coodinate refer to a reference coordinate to see if it is nearer
        /// </summary>
        /// <param name="another">anther coodinate to be compared with</param>
        /// <param name="reference">reference coordinate</param>
        /// <returns>if distance less than anther coodinate then return true</returns>
        public bool IsNearer(Coordinate3D another, Coordinate3D reference = null)
        {
            return this.IsNearer(another, reference, CoordinateAxis.AxisNone);
        }


        /// <summary>
        /// compare distance with anther coodinate refer to a reference coordinate to see if it is nearer
        /// </summary>
        /// <param name="another">anther coodinate to be compared with</param>
        /// <param name="reference">reference coordinate</param>
        /// <param name="exceptIndex">ignored axis, 1 means x axis, 2 means y axis, 3 means z axis, 0 means ignore none</param>
        /// <returns>if distance less than anther coodinate then return true</returns>
        public bool IsNearer(Coordinate3D another, Coordinate3D reference = null, CoordinateAxis exceptAxis = CoordinateAxis.AxisNone)
        {
            bool result = false;
            if (reference == null) reference = new Coordinate3D(0, 0, 0);
            if (another != null && another is Coordinate3D && reference != null && reference is Coordinate3D)
            {
                switch (exceptAxis)
                {
                    case CoordinateAxis.AxisX:
                        result = (new Coordinate2D(this.y, this.z)).IsNearer(new Coordinate2D(another.y, another.z), new Coordinate2D(reference.y, reference.z));
                        break;
                    case CoordinateAxis.AxisY:
                        result = (new Coordinate2D(this.x, this.z)).IsNearer(new Coordinate2D(another.x, another.z), new Coordinate2D(reference.x, reference.z));
                        break;
                    case CoordinateAxis.AxisZ:
                        result = (new Coordinate2D(this.x, this.y)).IsNearer(new Coordinate2D(another.x, another.y), new Coordinate2D(reference.x, reference.y));
                        break;
                    default:
                        result = this.DistanceTo(reference) < another.DistanceTo(reference);
                        break;
                }

            }
            return result;
        }

        #endregion
    }
}