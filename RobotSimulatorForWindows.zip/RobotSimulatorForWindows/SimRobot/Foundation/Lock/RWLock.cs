using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections;
using System.Runtime.InteropServices;
using System.IO;
using System.Diagnostics;
using System.Reflection;

namespace Pegatron.Foundation
{
    /// <summary>
    /// read / write lock
    /// </summary>
    public class RWLock
    {
        public const int DefaultReadMaxCount = -1;// -1 means no limit
        public const int DefaultLockWriteWaitMilliseconds = System.Threading.Timeout.Infinite;
        public const int DefaultLockReadWaitMilliseconds = System.Threading.Timeout.Infinite;
        protected object mLockObj = new object();
        protected int mReadMaxCount = RWLock.DefaultReadMaxCount;
        protected int mReadingCount = 0;
        public RWLock(int readMaxCount)
        {
            mReadMaxCount = readMaxCount;
        }

        public RWLock()
            : this(RWLock.DefaultReadMaxCount)
        {

        }

        public bool Lock()
        {
            bool lockTaken = false;
            Monitor.Enter(mLockObj, ref lockTaken);
            return lockTaken;
        }

        public void Unlock()
        {
            Monitor.Exit(mLockObj);
        }

        public bool TryLock(int milliSeconds = 0)
        {
            bool lockTaken = false;
            if( milliSeconds == 0 )
            {
                Monitor.TryEnter(mLockObj, ref lockTaken);
            }
            else
            {
                Monitor.TryEnter(mLockObj, milliSeconds, ref lockTaken);
            }
            return lockTaken;
        }

        public bool LockWrite(int waitMilliseconds = RWLock.DefaultLockWriteWaitMilliseconds)
        {
            bool lockTaken = false;
            if ((lockTaken = this.Lock()))
            {
                while (mReadingCount > 0)
                {
                    Monitor.Wait(mLockObj, waitMilliseconds);
                }
            }
            return lockTaken;
        }

        public void UnlockWrite()
        {
            this.Signal();
            this.Unlock();
        }

        protected void Signal()
        {
            Monitor.Pulse(mLockObj);
        }

        protected bool Wait(int waitMilliseconds)
        {
            return Monitor.Wait(mLockObj, waitMilliseconds);
        }

        protected void Wait()
        {
            Monitor.Wait(mLockObj);
        }
        /*
        public bool LockRead(Func<bool> condition = null)
        {
            bool result = false;
            bool lockTaken = false;
            try
            {
                if ((lockTaken = this.Lock()))
                {
                    if (mReadingCount >= 0 && (mReadMaxCount < 0 || mReadingCount < mReadMaxCount) && (condition == null || condition.Invoke()))
                    {
                        mReadingCount++;
                        result = true;
                    }
                }
            }
            finally
            {
                if (lockTaken) this.Unlock();
            }
            return result;
        }
         * */
        public bool LockRead(Func<bool> condition = null)
        {
            bool result = false;
            bool lockTaken = false;
            try
            {
                if ((lockTaken = this.Lock()))
                {
                    if (mReadingCount >= 0)
                    {
                        while ((mReadMaxCount > 0 && mReadingCount >= mReadMaxCount) )
                        {
                            this.Wait();
                        }
                        if (condition == null || condition.Invoke())
                        {
                            mReadingCount++;
                            result = true;
                        }
                    }
                }
            }
            finally
            {
                if (lockTaken) this.Unlock();
            }
            return result;
        }

        public bool LockReadWithTimeout(int timeoutMilliseconds, Func<bool> condition = null, int waitMilliseconds = RWLock.DefaultLockReadWaitMilliseconds)
        {
            bool result = false;
            bool lockTaken = false;
            try
            {
                if ((lockTaken = this.Lock()))
                {
                    TimeCounter timeCounter = new TimeCounter();
                    timeCounter.Start();
                    while (timeoutMilliseconds < 0 || timeCounter.LastRunningTime < timeoutMilliseconds)
                    {
                        if (mReadingCount >= 0)
                        {
                            if ((mReadMaxCount < 0 || mReadingCount <= mReadMaxCount))
                            {
                                if (condition == null || condition.Invoke())
                                {
                                    mReadingCount++;
                                    result = true;
                                    break;
                                }
                            }
                        }
                        this.Wait(waitMilliseconds);
                    }
                }
            }
            finally
            {
                if (lockTaken) this.Unlock();
            }
            return result;
        }

        public bool UnlockRead()
        {
            bool result = false;
            bool lockTaken = false;
            try
            {
                if ((lockTaken = this.Lock()))
                {
                    if (mReadingCount > 0)
                    {
                        mReadingCount--;
                        this.Signal();
                        result = true;
                    }
                }
            }
            finally
            {
                if (lockTaken) this.Unlock();
            }
            return result;
        }

        public bool TryLockWrite()
        {
            bool result = false;
            bool lockTaken = false;
            try
            {
                if ((lockTaken = this.Lock()))
                {
                    if (mReadingCount <= 0)
                    {
                        result = true;
                    }
                }
            }
            finally
            {
                if (lockTaken && !result)
                {
                    this.Unlock();
                }
            }
            return result;
        }

        public bool TryLockRead()
        {
            bool result = false;
            bool lockTaken = false;
            try
            {
                if ((lockTaken = this.TryLock()))
                {
                    if (mReadingCount >= 0 && (mReadMaxCount < 0 || mReadingCount < mReadMaxCount))
                    {
                        mReadingCount++;
                        result = true;
                    }
                }
            }
            finally
            {
                if (lockTaken) this.Unlock();
            }
            return result;
        }

        public bool WaitUntil(int timeoutMilliseconds, Func<bool> condition = null, int waitMilliseconds = RWLock.DefaultLockReadWaitMilliseconds)
        {
            bool result = false;
            try
            {
                result = this.LockReadWithTimeout(timeoutMilliseconds, condition, waitMilliseconds);
            }
            finally
            {
                if (result) this.UnlockRead();
            }
            return result;
        }

        public void PerformWithLockWrite(Action action)
        {
            if (action != null)
            {
                this.LockWrite();
                try
                {
                    action.Invoke();
                }
                catch (Exception ex)
                {
                    ATSException.Throw(ex);
                }
                finally
                {
                    this.UnlockWrite();
                }
            }
        }

        public void PerformWithLockRead(Action action)
        {
            if (action != null)
            {
                if (this.LockRead())
                {
                    try
                    {
                        action.Invoke();
                    }
                    catch (Exception ex)
                    {
                        ATSException.Throw(ex);
                    }
                    finally
                    {
                        this.UnlockRead();
                    }
                }
            }
        }

        public TResult PerformWithLockWrite<TResult>(Func<TResult> func, TResult defaultValue = default(TResult))
        {
            TResult result = defaultValue;
            if (func != null)
            {
                this.PerformWithLockWrite(() =>
                {
                    result = func.Invoke();
                });
            }
            return result;
        }

        public TResult PerformWithLockRead<TResult>(Func<TResult> func, TResult defaultValue = default(TResult))
        {
            TResult result = defaultValue;
            if (func != null)
            {
                this.PerformWithLockRead(() =>
                {
                    result = func.Invoke();
                });
            }
            return result;
        }
    }
}
