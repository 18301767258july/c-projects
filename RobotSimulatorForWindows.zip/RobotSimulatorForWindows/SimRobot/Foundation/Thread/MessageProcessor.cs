﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections;
using Pegatron.Foundation.Xml;

namespace Pegatron.Foundation
{
    /// <summary>
    /// interface defined receive message function ProtoType
    /// </summary>
    public interface IMessageReceiver<TMessage>
    {
        bool ReceivedMessage(object sender, TMessage message);
    }

    public interface IMessageManager<TMessage>
    {
        int MessageCount
        {
            get;
        }

        bool MessagePurgeStarted
        {
            get;
            set;
        }

        bool AddMessage(TMessage message);

        bool RemoveMessage(TMessage message);

        void ClearMessages();

        TMessage GetMessage();

        bool WaitMessage(int timeoutMilliseconds, Func<bool> breakCondition);

        TMessage[] EnumMessages();

        TMessage[] EnumMessages(Predicate<TMessage> condition);
    }

    public interface IMessageHandler<TMessage>
    {
        void PreHandling(TMessage message);
        IExitCode HandleMessage(TMessage message);
        void PostHandling(TMessage message, IExitCode exitCode);
    }

    public class MessageProcessor<TMessage> : LoopProcessor, IMessageReceiver<TMessage>, IAsyncExecPool<TMessage>
    {
        #region fields
        
        public const int DefaultWaitSleepMilliseconds = 10;//ms
        protected IMessageHandler<TMessage> mMessageHandler = null;
        protected IMessageManager<TMessage> mMessageManager = null;
        
        #endregion

        #region property

        public TMessage[] Messages
        {
            get
            {
                return (this.MessageManager != null) ? (this.MessageManager.EnumMessages()) : null;
            }
        }

        public IMessageHandler<TMessage> MessageHandler
        {
            get
            {
                return this.PerformWithLockRead(() => mMessageHandler);
            }
            set
            {
                this.PerformWithLockWrite(() =>
                    {
                        if (!this.Running)
                        {
                            mMessageHandler = value;
                        }
                    });
            }
        }

        public IMessageManager<TMessage> MessageManager
        {
            get
            {
                return this.PerformWithLockRead(() => mMessageManager);
            }
            set
            {
                this.PerformWithLockWrite(() =>
                {
                    if (!this.Running)
                    {
                        mMessageManager = value;
                    }
                });
            }
        }

        public bool PurgeStarted
        {
            get
            {
                return this.mMessageManager != null ? this.mMessageManager.MessagePurgeStarted : false;
            }
            set
            {
                if (this.mMessageManager != null)
                {
                    this.mMessageManager.MessagePurgeStarted = value;
                }
            }
        }
        #endregion

        #region constructor & destructor
        /// <summary>
        /// Constructor
        /// </summary>
        public MessageProcessor()
            : this(null)
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        public MessageProcessor(string name, IMessageHandler<TMessage> handler = null, IMessageManager<TMessage> manager = null)
            : base(name, LoopProcessor.ZeroLoopSleepMilliseconds)
        {
            this.LoopHandler = this.loop;
            this.MessageHandler = handler;
            this.MessageManager = manager;
        }

        #endregion

        public override bool AsyncExec(IAsyncExecCallback<object> observer = null, object args = null)
        {
            this.PurgeStarted = false;
            return base.AsyncExec(observer, args);
        }

        #region message related functions

        public virtual bool WaitUntilEmpty(int timeoutMilliseconds = System.Threading.Timeout.Infinite)
        {
            return this.WaitUntilEmpty(timeoutMilliseconds, MessageProcessor<TMessage>.DefaultWaitSleepMilliseconds);
        }

        protected bool WaitUntilEmpty(int timeoutMilliseconds, int sleepMilliseconds)
        {
            bool result = false;
            TimeCounter timeCounter = new TimeCounter();
            timeCounter.Start();
            while (timeoutMilliseconds == System.Threading.Timeout.Infinite || timeCounter.LastRunningTime < (double)timeoutMilliseconds)
            {
                TMessage[] messages = this.Messages;
                if (messages == null || messages.Length <= 0)
                {
                    result = true;
                    break;
                }
                Thread.Sleep(sleepMilliseconds);
            }
            return result;
        }

        /// <summary>
        /// receive message into message list and pulse a signal
        /// </summary>
        /// <param name="sender">who send this message</param>
        /// <param name="message">message data</param>
        /// <returns></returns>
        public virtual bool ReceivedMessage(object sender, TMessage message)
        {
            return this.AddPoolElements(message);
        }

        public virtual bool AddPoolElements(params TMessage[] messages)
        {
            bool result = false;
            if (messages != null && this.MessageManager != null)
            {
                foreach (TMessage message in messages)
                {
                    this.MessageManager.AddMessage(message);
                }
                result = true;
            }
            return result;
        }

        #endregion

        #region loop function
        /// <summary>
        /// loop function for the thread, default is to handle message
        /// </summary>
        /// <param name="arg">parameter transfered into function</param>
        /// <returns></returns>
        protected virtual bool loop(object arg)
        {
            this.DoEvent();
            return true;
        }

        /// <summary>
        /// get message and handle it
        /// </summary>
        protected void DoEvent()
        {
            if (this.mMessageManager != null)
            {
                TMessage message = this.mMessageManager.GetMessage();
                if (message != null)
                {
                    if (this.mMessageHandler != null)
                    {
                        this.mMessageHandler.PreHandling(message);
                        IExitCode exitCode = this.mMessageHandler.HandleMessage(message);
                        this.mMessageHandler.PostHandling(message, exitCode);
                    }
                    else
                    {
                        Logger.ThreadLogging(this, "ERROR: no message handler to handle->" + message);
                    }
                }
                else
                {
                    this.mMessageManager.WaitMessage(System.Threading.Timeout.Infinite, () => this.mMessageManager.MessageCount > 0 || this.ExitRequested);
                }
            }
        }
        #endregion

    }
}
