﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Pegatron.Foundation
{
    public class HashSetManager<TElement> : SetManager<HashSet<TElement>, TElement>
    {
        #region override functions
        public override int RemoveDevices(Predicate<TElement> match)
        {
            int result = 0;
            if( match != null )
            {
                result = this.PerformWithLockWrite(() => this.Devices.RemoveWhere(match));
            }
            return result;
        }
        #endregion
    }
}
