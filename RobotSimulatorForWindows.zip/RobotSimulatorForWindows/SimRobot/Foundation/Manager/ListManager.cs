﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Pegatron.Foundation
{
    public class ListManager<TCollection, TElement> : TCollectionManager<TCollection, TElement>
        where TCollection : IList<TElement>, new()
    {
        #region property
        public virtual TElement this[int index]
        {
            get
            {
                return this.DeviceAt(index);
            }
        }
        #endregion

        #region new functions
        protected virtual int InnerIndexOf(TElement device)
        {
            return this.Devices.IndexOf(device);
        }

        protected virtual bool InnerInsert(int index, TElement device)
        {
            this.Devices.Insert(index, device);
            return true;
        }

        protected virtual bool InnerRemoveAt(int index)
        {
            this.Devices.RemoveAt(index);
            return true;
        }

        protected virtual bool InnerDeviceAt(int index, ref TElement outDevice)
        {
            bool result = false;
            if (index >= 0 && index < this.InnerDevicesCount)
            {
                outDevice = this.Devices[index];
                result = true;
            }
            return result;
        }

        protected virtual TElement InnerDeviceAt(int index, TElement defaultValue = default(TElement))
        {
            TElement result = defaultValue;
            this.InnerDeviceAt(index, ref result);
            return result;
        }

        public int IndexOf(TElement device)
        {
            return this.PerformWithLockRead(() => this.InnerIndexOf(device), -1);
        }

        public bool Insert(int index, TElement device)
        {
            return this.PerformWithLockWrite(() => this.InnerInsert(index, device));
        }

        public bool RemoveAt(int index)
        {
            return this.PerformWithLockWrite(() => this.InnerRemoveAt(index));
        }

        public TElement DeviceAt(int index, TElement defaultValue = default(TElement))
        {
            return this.PerformWithLockRead(() => this.InnerDeviceAt(index, defaultValue), defaultValue);
        }

        public TElement GetFirstDevice(bool remove = false, TElement defaultValue = default(TElement))
        {
            TElement result = defaultValue;
            if (remove)
            {
                result = this.PerformWithLockWrite(() =>
                    {
                        TElement firstDevice = defaultValue;
                        if (this.InnerDevicesCount > 0)
                        {
                            firstDevice = this[0];
                            this.InnerRemoveAt(0);
                        }
                        return firstDevice;
                    }, defaultValue);
            }
            else
            {
                result = this[0];
            }
            return result;
        }

        public virtual bool AddFirstDevice(TElement device)
        {
            return this.Insert(0, device);
        }

        public bool AddFirstDevice(TElement device, Predicate<TElement> match)
        {
            if( match != null )
            {
                return this.PerformWithLockWrite(() => match.Invoke(device) ? this.AddFirstDevice(device) : false);
            }
            else
            {
                return this.AddFirstDevice(device);
            }
        }

        public bool AddFirstDevice(TElement device, Func<bool> match)
        {
            if( match != null )
            {
                return this.PerformWithLockWrite(() => match.Invoke() ? this.AddFirstDevice(device) : false);
            }
            else
            {
                return this.AddFirstDevice(device);
            }
        }

        public bool AddFirstDevice(TElement baseDevice, Func<TElement, TElement> convertor)
        {
            if( convertor != null )
            {
                return this.PerformWithLockWrite(() => this.AddFirstDevice(convertor.Invoke(baseDevice)));
            }
            else
            {
                return this.AddFirstDevice(baseDevice);
            }
        }

        public int AddFirstDevices(params TElement[] devices)
        {
            return this.AddFirstDevices(null, devices);
        }

        public int AddFirstDevices(Predicate<TElement> match, params TElement[] devices)
        {
            int result = 0;
            if( devices != null && devices.Length > 0 )
            {
                List<TElement> deviceList = devices.ToList();
                deviceList.Reverse();
                result = this.PerformWithLockWrite(() =>
                    {
                        int count = 0;
                        foreach (TElement device in deviceList)
                        {
                            if (this.AddFirstDevice(device, match))
                            {
                                count++;
                            }
                        }
                        return count;
                    }
                    );
            }
            return result;
        }
        #endregion
    }

    public class ListManager<TElement> : ListManager<List<TElement>, TElement>
    {
        #region properties
        public virtual int Capacity
        {
            get
            {
                return this.PerformWithLockRead(() => this.Devices.Capacity);
            }
            set
            {
                this.PerformWithLockWrite(() => this.Devices.Capacity = value);
            }
        }
        #endregion

        #region override functions
        public override int RemoveDevices(Predicate<TElement> match)
        {
            int result = 0;
            if (match != null)
            {
                result = this.PerformWithLockWrite(() => this.Devices.RemoveAll(match));
            }
            return result;
        }

        public override TElement GetDevice(Predicate<TElement> match, TElement defaultValue = default(TElement))
        {
            TElement result = defaultValue;
            if( match != null )
            {
                result = this.PerformWithLockRead(() => this.Devices.Find(match));
            }
            return result;
        }

        public override TElement[] EnumDevices(Predicate<TElement> match = null)
        {
            return ((match == null) ? base.EnumDevices() : this.PerformWithLockRead(() => {
                List<TElement> matches = this.Devices.FindAll(match);
                return matches != null ? matches.ToArray() : null;
            }));
        }
        #endregion
    }
}
