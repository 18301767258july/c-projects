﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Pegatron.Foundation
{
    public class QueueManager<TElement> : CollectionManager<Queue<TElement>, TElement>
    {
        #region override functions

        protected override bool InnerAddDevice(TElement device)
        {
            this.Devices.Enqueue(device);
            return true;
        }

        protected override bool InnerRemoveDevice(TElement device)
        {
            ATSException.Throw(new NotImplementedException());
            return false;
        }

        protected override void InnerClearDevices()
        {
            this.Devices.Clear();
        }

        protected override bool InnerContainsDevice(TElement device)
        {
            return this.Devices.Contains(device);
        }
        #endregion

        #region new functions
        public TElement Dequeue()
        {
            return this.PerformWithLockWrite(() =>
                {
                    TElement result = default(TElement);
                    if (this.Count > 0)
                    {
                        result = this.Devices.Dequeue();
                    }
                    return result;
                });
        }

        public bool Enqueue(TElement device)
        {
            return this.AddDevice(device);
        }

        public TElement Peek()
        {
            return this.PerformWithLockRead(() =>
                {
                    TElement result = default(TElement);
                    if (this.Count > 0)
                    {
                        result = this.Devices.Peek();
                    }
                    return result;
                });
        }
        #endregion
    }
}
