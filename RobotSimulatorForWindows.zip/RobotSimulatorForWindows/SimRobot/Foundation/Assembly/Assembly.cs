using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Reflection;
using Pegatron.Foundation;
using Pegatron.Foundation.Xml;

namespace Pegatron.Foundation
{
    /// <summary>
    /// Common Class that contains static common functions
    /// </summary>
    public class AssemblyFuncs
    {
        #region MethodInfo PropertyInfo Delegete
        public static string GetMethodName(int index = 1)
        {
            string result = string.Empty;
            MethodInfo methodInfo = new StackTrace().GetFrame(index).GetMethod() as MethodInfo;
            if (methodInfo != null)
            {
                result = methodInfo.Name;
                PropertyInfo[] propertyInfos = methodInfo.DeclaringType.GetProperties(
                    BindingFlags.Instance |
                    BindingFlags.Static |
                    BindingFlags.Public |
                    BindingFlags.NonPublic);
                if (propertyInfos != null && propertyInfos.Length > 0)
                {
                    foreach (PropertyInfo propertyInfo in propertyInfos)
                    {
                        if (propertyInfo.GetGetMethod(true) == methodInfo || propertyInfo.GetSetMethod(true) == methodInfo)
                        {
                            result = propertyInfo.Name;
                            break;
                        }
                    }
                }
            }
            return result == null ? string.Empty : result;
        }

        public static Delegate CreateDelegate(Type type, object firstArgument, MethodInfo method, bool throwOnBindFailure = true)
        {
            Delegate result = null;
            try
            {
                result = Delegate.CreateDelegate(type, firstArgument, method, throwOnBindFailure);
            }
            catch (Exception ex)
            {
                result = null;
                ATSException.Throw(ex);
            }
            return result;
        }

        public static Delegate CreateDelegate(Type type, object target, string method, Type[] types, bool throwOnBindFailure = true)
        {
            Delegate result = null;
            try
            {
                result = AssemblyFuncs.CreateDelegate(
                            type,
                            target,
                            target.GetType().GetMethod(method, types),
                            throwOnBindFailure
                            );
            }
            catch (Exception ex)
            {
                result = null;
                ATSException.Throw(ex);
            }
            return result;
        }
        #endregion

        #region Create Instance
        public static object CreateInstance(string typeFullName, string assemblyFile)
        {
            object result = null;
            if (!string.IsNullOrEmpty(assemblyFile))
            {
                result = AssemblyFuncs.CreateInstance(typeFullName, Assembly.LoadFrom(assemblyFile));
            }
            else
            {
                result = AssemblyFuncs.CreateInstance(typeFullName);
            }
            return result;
        }

        public static object CreateInstance(string typeFullName, Assembly assembly)
        {
            object result = null;
            if (assembly != null)
            {
                if (!string.IsNullOrEmpty(typeFullName))
                {
                    result = assembly.CreateInstance(typeFullName);
                }
            }
            if (result == null && assembly != Assembly.GetEntryAssembly())
            {
                result = AssemblyFuncs.CreateInstance(typeFullName, Assembly.GetEntryAssembly());
            }
            return result;
        }


        public static object CreateInstance(string typeFullName, string assemblyFile, params object[] parameters)
        {
            object result = null;
            if (!string.IsNullOrEmpty(assemblyFile))
            {
                result = AssemblyFuncs.CreateInstance(typeFullName, Assembly.LoadFrom(assemblyFile), parameters);
            }
            else
            {
                result = AssemblyFuncs.CreateInstance(typeFullName, parameters);
            }
            return result;
        }

        public static object CreateInstance(string typeFullName, Assembly assembly, params object[] parameters)
        {
            object result = null;
            if (assembly != null)
            {
                if (!string.IsNullOrEmpty(typeFullName))
                {
                    result = assembly.CreateInstance(typeFullName, false, 0, null, parameters, null, null);
                }
            }
            if (result == null)
            {
                result = AssemblyFuncs.CreateInstance(typeFullName, parameters);
            }
            return result;
        }

        public static object CreateInstance(Type type)
        {
            object result = null;
            if (type != null)
            {
                ConstructorInfo ci = type.GetConstructor(System.Type.EmptyTypes);
                if (ci != null)
                {
                    result = ci.Invoke(null);
                }
            }
            return result;
        }

        public static object CreateInstance(Type type, params object[] parameters)
        {
            object result = null;
            if (type != null)
            {
                List<Type> paramTypes = new List<Type>();
                foreach (object param in parameters)
                {
                    paramTypes.Add(param.GetType());
                }
                ConstructorInfo ci = type.GetConstructor(paramTypes.ToArray());
                if (ci != null)
                {
                    result = ci.Invoke(parameters);
                }
            }
            return result;
        }

        public static object CreateInstance(Type type, Type[] paramTypes, params object[] parameters)
        {
            object result = null;
            if (type != null)
            {
                ConstructorInfo ci = type.GetConstructor(paramTypes);
                if (ci != null)
                {
                    result = ci.Invoke(parameters);
                }
            }
            return result;
        }

        public static object CreateInstance(string typeFullName)
        {
            object result = null;
            if( !string.IsNullOrEmpty(typeFullName) )
            {
                Type type = Type.GetType(typeFullName);
                if (type != null)
                {
                    ConstructorInfo ci = type.GetConstructor(System.Type.EmptyTypes);
                    if (ci != null)
                    {
                        result = ci.Invoke(null);
                    }
                }
                else
                {
                    result = AssemblyFuncs.CreateInstance(typeFullName, Assembly.GetEntryAssembly());
                }
            }
            return result;
        }

        public static object CreateInstance(string typeFullName, params object[] parameters)
        {
            object result = null;
            if( !string.IsNullOrEmpty(typeFullName) )
            {
                if (parameters == null || parameters.Length <= 0)
                {
                    result = AssemblyFuncs.CreateInstance(typeFullName);
                }
                else
                {
                    Type type = Type.GetType(typeFullName);
                    if (type != null)
                    {
                        result = AssemblyFuncs.CreateInstance(type, parameters);
                    }
                    else
                    {
                        result = AssemblyFuncs.CreateInstance(typeFullName, parameters, Assembly.GetEntryAssembly());
                    }
                }
            }
            return result;
        }

        public static object CreateInstance(string typeFullName, Type[] paramTypes, params object[] parameters)
        {
            object result = null;
            if (!string.IsNullOrEmpty(typeFullName))
            {
                if (parameters == null || parameters.Length <= 0)
                {
                    result = AssemblyFuncs.CreateInstance(typeFullName);
                }
                else
                {
                    Type type = Type.GetType(typeFullName);
                    if (type != null)
                    {
                        result = AssemblyFuncs.CreateInstance(type, paramTypes, parameters);
                    }
                    else
                    {
                        result = AssemblyFuncs.CreateInstance(typeFullName, parameters, Assembly.GetEntryAssembly());
                    }
                }
            }
            return result;
        }
        #endregion

        #region Get Type
        public static Type GetType(string typeFullName)
        {
            Type result = Type.GetType(typeFullName);
            if (result == null)
            {
                result = AssemblyFuncs.GetType(typeFullName, Assembly.GetEntryAssembly());
            }
            return result;
        }

        public static Type GetType(string typeFullName, string assemblyFile)
        {
            Type result = null;
            if (!string.IsNullOrEmpty(assemblyFile))
            {
                result = AssemblyFuncs.GetType(typeFullName, Assembly.LoadFrom(assemblyFile));
            }
            else
            {
                result = AssemblyFuncs.GetType(typeFullName);
            }
            return result;
        }

        public static Type GetType(string typeFullName, Assembly assembly)
        {
            Type result = null;
            if (assembly != null)
            {
                result = assembly.GetType(typeFullName);
            }
            else
            {
                result = AssemblyFuncs.GetType(typeFullName);
            }
            return result;
        }
        #endregion

        #region Main Module
        public static string GetMainModuleDirectory()
        {
            return System.IO.Path.GetDirectoryName(AssemblyFuncs.GetMainModuleFile());
        }

        public static string GetMainModuleName()
        {
            return System.Diagnostics.Process.GetCurrentProcess().MainModule.ModuleName;
        }

        public static string GetMainModuleFile()
        {
            return System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
        }
        #endregion
    }
}
