﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    class BinaryResource : BaseResource
    {
        public bool Available
        {
            get
            {
                return this.AvailableCount == 1;
            }
        }
        public object Owner
        {
            get
            {
                object[] owners = this.Owners;
                return (owners != null && owners.Length == 1) ? owners[0] : null;
            }
        }
        public BinaryResource(string type, string name)
            : base(type, name, 1)
        {
        }
    }
}
