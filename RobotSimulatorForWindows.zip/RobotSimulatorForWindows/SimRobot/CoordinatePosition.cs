﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimRobot
{
    public class CoordinatePosition
    {
        public double X
        {
            get;
            set;
        }
        public double Y
        {
            get;
            set;
        }
        public double Z
        {
            get;
            set;
        }
    }
}
