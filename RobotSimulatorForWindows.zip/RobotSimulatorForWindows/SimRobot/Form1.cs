﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;


namespace SimRobot
{
    
    public partial class Form1 : Form
    {
        private RobotL_COMP robot;
        bool flagBeacon = false;
        bool flagE_Stop = true;
       // bool goldenDoorFlag = true;
       // bool drawerFlag = true;
        ShowCamLog camLog = null;
        ShowAVCLog avcLog = null;
        
        setSpeed speedEvent;
        //初始化
        public Form1()
        {
            InitializeComponent();
            
        }
        Label showCAMLogFlag;
        Label showAVCLogFlag;
        public delegate void LightTowersUIDelegate(bool buzzer, bool red, bool yellow, bool green);
        public delegate void clampDelegate(Sensor sensor, bool result);
        public delegate void ioDelegate(string deviceId, bool state);
        public delegate void setSpeed(string speed);
        public delegate void updateUUT(PictureBox box, bool result);
        private void Form1_Load(object sender, EventArgs e)
        {
            robot = new RobotL_COMP();
            camLog = new ShowCamLog();
            avcLog = new ShowAVCLog();
            //init beacon
            pbxBeacon.Image = imgBeacon.Images[1];
            pbxRed.Image = imgLight0.Images[0];
            pbxYellow.Image = imgLight1.Images[1];
            pbxGreen.Image = imgLight1.Images[2];
            
            //init inbuffer
           // pbxInBuffer1.Image = SimRobot.Properties.Resources.phone;
            pbxInBuffer1.Image = imgBuffer.Images[1];
            pbxInBuffer2.Image = imgBuffer.Images[1];
            //pbxInBuffer3.Image = imgBuffer.Images[1];
           // pbxInBuffer4.Image = imgBuffer.Images[1];
            //left 
            pbxLeft1.Image = imgBuffer.Images[0];
            pbxLeft2.Image = imgBuffer.Images[0];
            pbxLeft3.Image = imgBuffer.Images[0];
            pbxLeft4.Image = imgBuffer.Images[0];
            pbxLeft5.Image = imgBuffer.Images[0];
            pbxLeft6.Image = imgBuffer.Images[0];
            pbxLeft7.Image = imgBuffer.Images[0];
            pbxLeft8.Image = imgBuffer.Images[0];
            //right
            pbxRight1.Image = imgBuffer.Images[0];
            pbxRight2.Image = imgBuffer.Images[0];
            pbxRight3.Image = imgBuffer.Images[0];
            pbxRight4.Image = imgBuffer.Images[0];
            pbxRight5.Image = imgBuffer.Images[0];
            pbxRight6.Image = imgBuffer.Images[0];
            pbxRight7.Image = imgBuffer.Images[0];
            pbxRight8.Image = imgBuffer.Images[0];
            //audit
            pbxAudit1.Image = imgBuffer.Images[1];
            pbxAudit2.Image = imgBuffer.Images[1];
            pbxAudit3.Image = imgBuffer.Images[1];
            pbxAudit4.Image = imgBuffer.Images[1];
            //processbuffer
            pbxProcessBuffer1.Image = imgBuffer.Images[1];
            pbxProcessBuffer2.Image = imgBuffer.Images[1];
            pbxProcessBuffer3.Image = imgBuffer.Images[1];
            pbxProcessBuffer4.Image = imgBuffer.Images[1];
            //NGbuffer
            pbxNGBuffer1.Image = imgBuffer.Images[1];
            pbxNGBuffer2.Image = imgBuffer.Images[1];
            pbxNGBuffer3.Image = imgBuffer.Images[1];
            pbxNGBuffer4.Image = imgBuffer.Images[1];
            // rejectDrawer
            pbxRejectLock.Image = imgIO.Images[1];
            pbxRejectClosed.Image = imgIO.Images[0];
          
            //E_Stop
            pbxE_Stop.Image = imgIO.Images[3];
            // NG DOOR
            pbxGoldenDoor.Image = imgIO.Images[0];//red
            pbxGoldenDoorLock.Image=imgIO.Images[1];//GREEN
            pbxGoldenDoorLight.Image = imgIO.Images[0];
            //speed
            tbxSpeed.Text = "100";
            //airPressure
            tbxAirPressure.Text = "500";
            //suction   blow 
            pbxClamp1Closed.Image=imgIO.Images[0];
            pbxClamp1Open.Image = imgIO.Images[0];
            pbxClamp1Dut.Image = imgIO.Images[0];
            // load event data
            robot.locationData += updateLocationData;
            robot.clampData += updateClamp;
            robot.stationData += updateStationData;
            robot.uutMapData += updateUUTMap;
            robot.lightTowerData += updateLightTower;
            robot.speedData += updateSpeed;
           // robot.LockData += updateLock;
            robot.ioChangeData += updateIOChange;
            robot.writeCAMLog += updateCAMLog;
            robot.writeAVCLog += updateAVCLog;
            robot.robotMotion += updateRobotMotion;
            robot.removeRobotMotion += updateRemoveRobotMotion;

            showCAMLogFlag = new Label();
            showCAMLogFlag.TextChanged += sendDataToShowCamLog;

            showAVCLogFlag = new Label();
            showAVCLogFlag.TextChanged += sendDataToShowAvcLog;
            
            // load robot handing time file
           // robot.readCSVFile("D:\\Users\\July_Zhao\\Desktop\\L-comp.csv");
            robot.readCSVFile();

        }
        public void updateLock(string deviceId, bool result)
        {
            ioDelegate lockUI = new ioDelegate(updateLockUI);
            if (deviceId == "20")
            {
                if (pbxRejectLock.InvokeRequired)
                {
                    pbxRejectLock.BeginInvoke(lockUI, deviceId, result);
                }
                else
                {
                    if (result)//lock
                    {
                        pbxRejectLock.Image = imgIO.Images[1];
                        pbxRejectClosed.Image = imgIO.Images[0];
                    }
                    else
                    {
                        pbxRejectLock.Image = imgIO.Images[0];
                        pbxRejectClosed.Image = imgIO.Images[1];
                    }
                }
                
            }
            else if (deviceId == "21")
            {
                if (pbxGoldenDoorLock.InvokeRequired)
                {
                    pbxGoldenDoorLock.BeginInvoke(lockUI, deviceId, result);
                }
                else
                {
                    if (result)//lock
                    {
                        pbxGoldenDoorLock.Image = imgIO.Images[1];
                        pbxGoldenDoor.Image = imgIO.Images[0];
                        pbxGoldenDoorLight.Image = imgIO.Images[0];
                    }
                    else
                    {
                        pbxGoldenDoorLock.Image = imgIO.Images[0];
                        pbxGoldenDoor.Image = imgIO.Images[1];
                        pbxGoldenDoorLight.Image = imgIO.Images[1];
                    }
                }
                
            }
        }
        public void updateLockUI(string deviceId, bool state)
        {
            switch (deviceId)
            {
                case "20":
                    if (state)//lock
                    {
                        pbxRejectLock.Image = imgIO.Images[1];
                        pbxRejectClosed.Image = imgIO.Images[0];
                    }
                    else
                    {
                        pbxRejectLock.Image = imgIO.Images[0];
                        pbxRejectClosed.Image = imgIO.Images[1];
                    }
                    break;
                case "21":
                    if (state)//lock
                    {
                        pbxGoldenDoorLock.Image = imgIO.Images[1];
                        pbxGoldenDoor.Image = imgIO.Images[0];
                        pbxGoldenDoorLight.Image = imgIO.Images[0];
                    }
                    else
                    {
                        pbxGoldenDoorLock.Image = imgIO.Images[0];
                        pbxGoldenDoor.Image = imgIO.Images[1];
                        pbxGoldenDoorLight.Image = imgIO.Images[1];
                    }
                    break;
            }
        }
        public void ioChangeUI(string name, bool status)
        {
            switch (name)
            {
                case "Estop":
                    if (status)
                    {
                        pbxE_Stop.Image = imgIO.Images[2];
                    }
                    else
                    {
                        pbxE_Stop.Image = imgIO.Images[3];
                    }
                    break;
                case "electric":

                    break;
                case "airPressure":
                    break;
            }
        }
        private void updateIOChange(string name,bool status)
        {
            ioDelegate estop = new ioDelegate(ioChangeUI);
            if (pbxE_Stop.InvokeRequired)
            {
                pbxE_Stop.BeginInvoke(estop, name, status);
            }
            else
            {
                pbxE_Stop.Image = status ? imgIO.Images[2] : imgIO.Images[3];
            }
            
        }
        private void beaconClick(object sender, EventArgs e)
        {
            if (flagBeacon == false)
            {
                flagBeacon = true;
                pbxBeacon.Image = imgBeacon.Images[1];
            }
            else
            {
                flagBeacon = false;
                pbxBeacon.Image = imgBeacon.Images[0];
            }
            
        }
        // E-Stop chick
        private void E_StopClick(object sender, EventArgs e)
        {
            if (flagE_Stop == true)
            {
                flagE_Stop = false;
                robot.Estop(true);
                pbxE_Stop.Image = imgIO.Images[2];
            }
            else
            {
                flagE_Stop = true;
                robot.Estop(false);
                pbxE_Stop.Image = imgIO.Images[3];
            }
        }
       // suction blow event
        public void updateClamp(Sensor sensor,bool result)
        {
            updateUUT clamp = new updateUUT(clampUI);
            
           //clampUI(sensor, result);
            if (sensor == robot.clamp1Opened)
            {
                pbxClamp1Open.BeginInvoke(clamp, pbxClamp1Open, result);
            }else if (sensor == robot.clamp1Closed)
            {
                 pbxClamp1Closed.BeginInvoke(clamp, pbxClamp1Closed, result);
            }
            else if (sensor == robot.clamp1DUT)
            {
                if (imgIO.Images.Count < 2)
                {
                    //write log 
                    //update UI thread place main thread 
                    Log.WriteLog("robot.clamp1DUT:imgIO count:" + imgIO.Images.Count);
                }
                else
                {
                    if (pbxClamp1Dut.InvokeRequired)
                    {
                        pbxClamp1Dut.BeginInvoke(clamp, pbxClamp1Dut, result);
                    }
                    else
                    {
                        pbxClamp1Dut.Image = result ? imgIO.Images[1] : imgIO.Images[0];
                    }
                    
                }
            }
        }
        

        public void clampUI(PictureBox box, bool result)
        {
                box.Image = result ? imgIO.Images[1] : imgIO.Images[0];
        }
        public void updateLocationData(int location,int slot,bool result)
        {
            switch(location)
            {
                case 101:
                    switch (slot)
                    {
                        case 1:
                            picBoxValue(pbxLeft1, result);
                            break;
                        case 2:
                            picBoxValue(pbxLeft2, result);
                            break;
                        case 3:
                            picBoxValue(pbxLeft3, result);
                            break;
                        case 4:
                            picBoxValue(pbxLeft4, result);
                            break;
                        case 5:
                            picBoxValue(pbxLeft5, result);
                            break;
                        case 6:
                            picBoxValue(pbxLeft6, result);
                            break;
                        case 7:
                            picBoxValue(pbxLeft7, result);
                            break;
                        case 8:
                            picBoxValue(pbxLeft8, result);
                            break;

                    }
                    break;
                case 102:
                    switch (slot)
                    {
                        case 1:
                            picBoxValue(pbxRight1, result);
                            break;
                        case 2:
                            picBoxValue(pbxRight2, result);
                            break;
                        case 3:
                            picBoxValue(pbxRight3, result);
                            break;
                        case 4:
                            picBoxValue(pbxRight4, result);
                            break;
                        case 5:
                            picBoxValue(pbxRight5, result);
                            break;
                        case 6:
                            picBoxValue(pbxRight6, result);
                            break;
                        case 7:
                            picBoxValue(pbxRight7, result);
                            break;
                        case 8:
                            picBoxValue(pbxRight8, result);
                            break;

                    }
                    break;
            }
        }
        public void picBoxValue(PictureBox pic,bool result)
        {
            pic.Image = result ? imgBuffer.Images[2] : imgBuffer.Images[1];
        }
        public void updateStationData(int station, int slot, bool result)
        {
            switch (station)
            {
                case 12://processBuffer
                    switch (slot)
                    {
                        case 1:
                            picBoxValue(pbxProcessBuffer1, result);
                            break;
                        case 2:
                            picBoxValue(pbxProcessBuffer2, result);
                            break;
                        case 3:
                            picBoxValue(pbxProcessBuffer3, result);
                            break;
                        case 4:
                            picBoxValue(pbxProcessBuffer4, result);
                            break;
                    }
                    break;
                case 11:
                    switch (slot)
                    {
                        case 1:
                            picBoxValue(pbxNGBuffer1, result);
                            break;
                        case 2:
                            picBoxValue(pbxNGBuffer2, result);
                            break;
                        case 3:
                            picBoxValue(pbxNGBuffer3, result);
                            break;
                        case 4:
                            picBoxValue(pbxNGBuffer4, result);
                            break;
                    }
                    break;
                case 21:
                    switch (slot)
                    {
                        case 1:
                            picBoxValue(pbxInBuffer1, result);
                            break;
                        case 2:
                            picBoxValue(pbxInBuffer2, result);
                            break;
                    }
                    break;

                case 31:
                    switch (slot)
                    {
                        case 1:
                            picBoxValue(pbxAudit1, result);
                            break;
                        case 2:
                            picBoxValue(pbxAudit2, result);
                            break;
                        case 3:
                            picBoxValue(pbxAudit3, result);
                            break;
                        case 4:
                            picBoxValue(pbxAudit4, result);
                            break;
                    }
                    break;
            }
        }
        public void updateUUTMap(int location,int slot,bool result=false)
        {
            switch (location)
            {
                case 101:
                    switch (slot)
                    {
                        case 1:
                            picBoxValue(pbxLeft1, result);
                            break;
                        case 2:
                            picBoxValue(pbxLeft2, result);
                            break;
                        case 3: 
                            picBoxValue(pbxLeft3, result);
                            break;
                        case 4:
                            picBoxValue(pbxLeft4, result);
                            break;
                        case 5:
                            picBoxValue(pbxLeft5, result);
                            break;
                        case 6:
                            picBoxValue(pbxLeft6, result);
                            break;
                        case 7:
                            picBoxValue(pbxLeft7, result);
                            break;
                        case 8:
                            picBoxValue(pbxLeft8, result);
                            break;

                    }
                    break;
                case 102:
                    switch (slot)
                    {
                        case 1:
                            picBoxValue(pbxRight1, result);
                            break;
                        case 2:
                            picBoxValue(pbxRight2, result);
                            break;
                        case 3:
                            picBoxValue(pbxRight3, result);
                            break;
                        case 4:
                            picBoxValue(pbxRight4, result);
                            break;
                        case 5:
                            picBoxValue(pbxRight5, result);
                            break;
                        case 6:
                            picBoxValue(pbxRight6, result);
                            break;
                        case 7:
                            picBoxValue(pbxRight7, result);
                            break;
                        case 8:
                            picBoxValue(pbxRight8, result);
                            break;
                    }
                    break;
            }
        }
        public void updateLightTower(LightTower towers)
        {
            LightTowersUIDelegate lightTower = new LightTowersUIDelegate(updateLightTower);
            pbxBeacon.BeginInvoke(lightTower,towers.Buzzer,towers.Red,towers.Yellow,towers.Green);
            
        }
        
        public void updateLightTower(bool buzzer, bool red, bool yellow, bool green)
        {

            pbxBeacon.Image = buzzer ? imgBeacon.Images[0] : imgBeacon.Images[1];
            pbxRed.Image = red ? imgLight1.Images[0] : imgLight0.Images[0];
            pbxYellow.Image = yellow ? imgLight1.Images[1] : imgLight0.Images[1];
            pbxGreen.Image = green ? imgLight1.Images[2] : imgLight0.Images[2];
        }
        public void updateSpeed(string speed)
        {
            if (tbxSpeed.InvokeRequired)
            {
                speedEvent = (string s) => { tbxSpeed.Text = s; };
               // tbxSpeed.Invoke(speedEvent, speed);
                tbxSpeed.BeginInvoke(speedEvent, speed);
            }
            else
            {
                tbxSpeed.Text = speed;
            }
        }
       
        public void updateCAMLog(string data)
        {
            if (data == showCAMLogFlag.Text)
            {
                showCAMLogFlag.Text =  "!"+data ;
            }
            else
            {
                showCAMLogFlag.Text = data;
            }
            
        }
        public void updateAVCLog(string data)
        {
            if (data == showAVCLogFlag.Text)
            {
                showAVCLogFlag.Text = "!"+data;
            }
            else
            {
                showAVCLogFlag.Text = data;
            }
        }
        //set speed
        private void button2_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(tbxSpeed.Text) >= 1 && Convert.ToInt32(tbxSpeed.Text) <= 100)
            {
                robot.Speed = Convert.ToInt32(tbxSpeed.Text);
            }
            else
            {
                MessageBox.Show("set speed error,please enter right speed again");
            }
            
        }
        // request Golden door open
        private void button3_Click(object sender, EventArgs e)
        {
            if (robot.goldenButten.Value == false)//请求开门
            {
                //goldenDoorFlag = true;
                robot.goldenButten.Value = true;
                robot.getStatus("00000");
                robot.requestModeChange(21, 1, 0);
            }
            else
            {
               // goldenDoorFlag = false;
                robot.goldenButten.Value = false;
                robot.getStatus("00000");
                robot.requestModeChange(21,0,1);
            }
        }
        // drawer butten
        private void button1_Click(object sender, EventArgs e)
        {
            if (robot.rejectButton.Value == false)//请求开门
            {
               // drawerFlag = true;
                robot.rejectButton.Value = true; //pressed
                robot.getStatus("00000");
                robot.requestModeChange(20, 1, 0);
            }
            else
            {
                //drawerFlag = false;
                robot.rejectButton.Value = false;
                robot.getStatus("00000");
                robot.requestModeChange(20, 0, 1);
            }
        }

        private void airPressure_TextChange(object sender, EventArgs e)
        {
           // airPressureEvent(Convert.ToDouble(tbxAirPressure.Text));
            
            robot.Pressure = Convert.ToDouble(tbxAirPressure.Text);
        }
      

        private void addDeleteUUTLeft1(object sender, EventArgs e)
        {
            if (robot.lefts.buffer[0].Value)
            {
                robot.lefts.buffer[0].Value = false;
                pbxLeft1.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.lefts.buffer[0].Value = true;
                pbxLeft1.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTLeft2(object sender, EventArgs e)
        {
            if (robot.lefts.buffer[1].Value)
            {
                robot.lefts.buffer[1].Value = false;
                pbxLeft2.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.lefts.buffer[1].Value = true;
                pbxLeft2.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTLeft3(object sender, EventArgs e)
        {
            if (robot.lefts.buffer[2].Value)
            {
                robot.lefts.buffer[2].Value = false;
                pbxLeft3.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.lefts.buffer[2].Value = true;
                pbxLeft3.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTLeft4(object sender, EventArgs e)
        {
            if (robot.lefts.buffer[3].Value)
            {
                robot.lefts.buffer[3].Value = false;
                pbxLeft4.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.lefts.buffer[3].Value = true;
                pbxLeft4.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTLeft5(object sender, EventArgs e)
        {
            if (robot.lefts.buffer[4].Value)
            {
                robot.lefts.buffer[4].Value = false;
                pbxLeft5.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.lefts.buffer[4].Value = true;
                pbxLeft5.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTLeft6(object sender, EventArgs e)
        {
            if (robot.lefts.buffer[5].Value)
            {
                robot.lefts.buffer[5].Value = false;
                pbxLeft6.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.lefts.buffer[5].Value = true;
                pbxLeft6.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTLeft7(object sender, EventArgs e)
        {
            if (robot.lefts.buffer[6].Value)
            {
                robot.lefts.buffer[6].Value = false;
                pbxLeft7.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.lefts.buffer[6].Value = true;
                pbxLeft7.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTLeft8(object sender, EventArgs e)
        {
            if (robot.lefts.buffer[7].Value)
            {
                robot.lefts.buffer[7].Value = false;
                pbxLeft8.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.lefts.buffer[7].Value = true;
                pbxLeft8.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTRight1(object sender, EventArgs e)
        {
            if (robot.rights.buffer[0].Value)
            {
                robot.rights.buffer[0].Value = false;
                pbxRight1.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.rights.buffer[0].Value = true;
                pbxRight1.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTRight2(object sender, EventArgs e)
        {
            if (robot.rights.buffer[1].Value)
            {
                robot.rights.buffer[1].Value = false;
                pbxRight2.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.rights.buffer[1].Value = true;
                pbxRight2.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTRight3(object sender, EventArgs e)
        {
            if (robot.rights.buffer[2].Value)
            {
                robot.rights.buffer[2].Value = false;
                pbxRight3.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.rights.buffer[2].Value = true;
                pbxRight3.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTRight4(object sender, EventArgs e)
        {
            if (robot.rights.buffer[3].Value)
            {
                robot.rights.buffer[3].Value = false;
                pbxRight4.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.rights.buffer[3].Value = true;
                pbxRight4.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTRight5(object sender, EventArgs e)
        {
            if (robot.rights.buffer[4].Value)
            {
                robot.rights.buffer[4].Value = false;
                pbxRight5.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.rights.buffer[4].Value = true;
                pbxRight5.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTRight6(object sender, EventArgs e)
        {
            if (robot.rights.buffer[5].Value)
            {
                robot.rights.buffer[5].Value = false;
                pbxRight6.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.rights.buffer[5].Value = true;
                pbxRight6.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTRight7(object sender, EventArgs e)
        {
            if (robot.rights.buffer[6].Value)
            {
                robot.rights.buffer[6].Value = false;
                pbxRight7.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.rights.buffer[6].Value = true;
                pbxRight7.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTRight8(object sender, EventArgs e)
        {
            if (robot.rights.buffer[7].Value)
            {
                robot.rights.buffer[7].Value = false;
                pbxRight8.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.rights.buffer[7].Value = true;
                pbxRight8.Image = imgBuffer.Images[2];
            }
        }
        private void addDeleteUUTInBuffer1(object sender, EventArgs e)
        {
            if (robot.inBuffer.buffer[0].Value)
            {
                robot.inBuffer.buffer[0].Value = false;
                pbxInBuffer1.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.inBuffer.buffer[0].Value = true;
                pbxInBuffer1.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTInBuffer2(object sender, EventArgs e)
        {
            if (robot.inBuffer.buffer[1].Value)
            {
                robot.inBuffer.buffer[1].Value = false;

                pbxInBuffer2.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.inBuffer.buffer[1].Value = true;
                pbxInBuffer2.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTAuditBuffer1(object sender, EventArgs e)
        {
            if (robot.audits.buffer[0].Value)
            {
                robot.audits.buffer[0].Value = false;
                pbxAudit1.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.audits.buffer[0].Value = true;
                pbxAudit1.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTAuditBuffer2(object sender, EventArgs e)
        {
            if (robot.audits.buffer[1].Value)
            {
                robot.audits.buffer[1].Value = false;
                pbxAudit2.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.audits.buffer[1].Value = true;
                pbxAudit2.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTAuditBuffer3(object sender, EventArgs e)
        {
            if (robot.audits.buffer[2].Value)
            {
                robot.audits.buffer[2].Value = false;
                pbxAudit3.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.audits.buffer[2].Value = true;
                pbxAudit3.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTAuditBuffer4(object sender, EventArgs e)
        {
            if (robot.audits.buffer[3].Value)
            {
                robot.audits.buffer[3].Value = false;
                pbxAudit4.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.audits.buffer[3].Value = true;
                pbxAudit4.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTNGBuffer1(object sender, EventArgs e)
        {
            if (robot.ngBuffer.buffer[0].Value)
            {
                robot.ngBuffer.buffer[0].Value = false;
                pbxNGBuffer1.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.ngBuffer.buffer[0].Value = true;
                pbxNGBuffer1.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTNGBuffer2(object sender, EventArgs e)
        {
            if (robot.ngBuffer.buffer[1].Value)
            {
                robot.ngBuffer.buffer[1].Value = false;
                pbxNGBuffer2.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.ngBuffer.buffer[1].Value = true;
                pbxNGBuffer2.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTNGBuffer3(object sender, EventArgs e)
        {
            if (robot.ngBuffer.buffer[2].Value)
            {
                robot.ngBuffer.buffer[2].Value = false;
                pbxNGBuffer3.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.ngBuffer.buffer[2].Value = true;
                pbxNGBuffer3.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTNGBuffer4(object sender, EventArgs e)
        {
            if (robot.ngBuffer.buffer[3].Value)
            {
                robot.ngBuffer.buffer[3].Value = false;
                pbxNGBuffer4.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.ngBuffer.buffer[3].Value = true;
                pbxNGBuffer4.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        
        private void addDeleteUUTProcessBuffer1(object sender, EventArgs e)
        {
            if (robot.processBuffer.buffer[0].Value)
            {
                robot.processBuffer.buffer[0].Value = false;
                pbxProcessBuffer1.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.processBuffer.buffer[0].Value = true;
                pbxProcessBuffer1.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTProcessBuffer2(object sender, EventArgs e)
        {
            if (robot.processBuffer.buffer[1].Value)
            {
                robot.processBuffer.buffer[1].Value = false;
                pbxProcessBuffer2.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.processBuffer.buffer[1].Value = true;
                pbxProcessBuffer2.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTProcessBuffer3(object sender, EventArgs e)
        {
            if (robot.processBuffer.buffer[2].Value)
            {
                robot.processBuffer.buffer[2].Value = false;
                pbxProcessBuffer3.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.processBuffer.buffer[2].Value = true;
                pbxProcessBuffer3.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }
        private void addDeleteUUTProcessBuffer4(object sender, EventArgs e)
        {
            if (robot.processBuffer.buffer[3].Value)
            {
                robot.processBuffer.buffer[3].Value = false;
                pbxProcessBuffer4.Image = imgBuffer.Images[1];
            }
            else
            {
                robot.processBuffer.buffer[3].Value = true;
                pbxProcessBuffer4.Image = imgBuffer.Images[2];
            }
            robot.getStatus("00000");
        }

        
        //NGDoor click
        private void DoorStatus(object sender, EventArgs e)
        {
            if (robot.rejectDrawerClosed.Value)
            {
                robot.rejectDrawerClosed.Value = false;//opened
                robot.getStatus("00000");
                pbxGoldenDoor.Image=imgIO.Images[1];//green
            }
            else
            {
                robot.rejectDrawerClosed.Value = true;//closed
                robot.getStatus("00000");
                pbxGoldenDoor.Image = imgIO.Images[0];
            }
            
        }
        //Ethernet wire
        private void button4_Click(object sender, EventArgs e)
        {
            if (robot.client != null)
            {
                robot.timer.Change(0,Timeout.Infinite);
                robot.client.Disconnect();
            }
            else
            {
               // robot.timerFlag = true;
                robot.ListenCam();
                
                robot.timer.Change(0,10000);
            }
        }
        //Unload error   vacuum
        private void button5_Click(object sender, EventArgs e)
        {
            robot.clamp1DUT.Value = false;
            robot.getStatus("00000");
        }
        //  UPS  
        private void button6_Click(object sender, EventArgs e)
        {
            if (robot.electric.Value)
            {
                robot.electric.Value = false;
                robot.getStatus("00000");
                btnUPS.Text = "UPS Unormal";
            }
            else
            {
                robot.electric.Value = true;
                robot.getStatus("00000");
                btnUPS.Text = "UPS Normal";
            }
        }
        //close status change
        private void pbxClose_Click(object sender, EventArgs e)
        {
            if (robot.clamp1Closed.Value == true)
            {
                robot.clamp1Closed.Value = false;
                robot.getStatus("00000");
                pbxClamp1Closed.Image = imgIO.Images[0];
            }
            else
            {
                robot.clamp1Closed.Value = true;
                robot.getStatus("00000");
                pbxClamp1Closed.Image = imgIO.Images[1];
            }
        }
        //open change
        private void pbxBlow_Click(object sender, EventArgs e)
        {
            if (robot.clamp1Open.Value == true)
            {
                robot.clamp1Open.Value = false;
                robot.getStatus("00000");
                pbxClamp1Open.Image = imgIO.Images[0];
            }
            else
            {
                robot.clamp1Open.Value = true;
                robot.getStatus("00000");
                pbxClamp1Open.Image = imgIO.Images[1];
            }
        }
        //vacuum  change
        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            if (robot.clamp1DUT.Value == true)
            {
                robot.clamp1DUT.Value = false;
                robot.getStatus("00000");
                pbxClamp1Dut.Image=imgIO.Images[0];
            }
            else
            {
                robot.clamp1DUT.Value = true;
                robot.getStatus("00000");
                pbxClamp1Dut.Image = imgIO.Images[1];
            }
        }
        //shoe cam log
        private void button6_Click_1(object sender, EventArgs e)
        {
            camLog.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
            avcLog.Show();
        }
        private void sendDataToShowCamLog(object sender, EventArgs e)
        {
            camLog.ReceiveData = showCAMLogFlag.Text;
            camLog.showCAMLog();
        }
        private void sendDataToShowAvcLog(object sender, EventArgs e)
        {
            avcLog.ReceiveData = showAVCLogFlag.Text;
            avcLog.showAVCLog();
        }
        public void updateRobotMotion(string start, int startSlot, string end, int endSlot)
        {
            selectUISlot(start, startSlot);
            selectUISlot(end, endSlot);
        }
        public void updateRemoveRobotMotion(string start, int startSlot, string end, int endSlot)
        {
            deleteSelectUISlot(start, startSlot);
            deleteSelectUISlot(end, endSlot);
        }
        private void drawPixtureBoxBorder(PictureBox pbx )
        {
            Graphics g = pbx.CreateGraphics();
            Pen pen = new Pen(Color.Red, 5);
            //g.Clear(this.BackColor);
            g.DrawRectangle(pen, pbx.ClientRectangle.X, pbx.ClientRectangle.Y,
                                       pbx.ClientRectangle.X + pbx.ClientRectangle.Width,
                                       pbx.ClientRectangle.Y + pbx.ClientRectangle.Height);
        }
        private void deletePixtureBoxBorder(PictureBox pbx)
        {
            Graphics g = pbx.CreateGraphics();
            Pen pen = new Pen(Color.WhiteSmoke, 8);
            //g.Clear(this.BackColor);
            g.DrawRectangle(pen, pbx.ClientRectangle.X, pbx.ClientRectangle.Y,
                                       pbx.ClientRectangle.X + pbx.ClientRectangle.Width,
                                       pbx.ClientRectangle.Y + pbx.ClientRectangle.Height);
        }
        private void selectUISlot(string station, int slot)
        {
            switch (station)
            {
                case "21":
                    switch (slot)
                    {
                        case 1:
                            drawPixtureBoxBorder(pbxInBuffer1);
                            break;
                        case 2:
                            drawPixtureBoxBorder(pbxInBuffer2);
                            break;
                    }
                    break;
                case "101":
                    switch (slot)
                    {
                        case 1:
                            drawPixtureBoxBorder(pbxLeft1);
                            break;
                        case 2:
                            drawPixtureBoxBorder(pbxLeft2);
                            break;
                        case 3:
                            drawPixtureBoxBorder(pbxLeft3);
                            break;
                        case 4:
                            drawPixtureBoxBorder(pbxLeft4);
                            break;
                        case 5:
                            drawPixtureBoxBorder(pbxLeft5);
                            break;
                        case 6:
                            drawPixtureBoxBorder(pbxLeft6);
                            break;
                        case 7:
                            drawPixtureBoxBorder(pbxLeft7);
                            break;
                        case 8:
                            drawPixtureBoxBorder(pbxLeft8);
                            break;
                    }

                    break;
                case "102":
                    switch (slot)
                    {
                        case 1:
                            drawPixtureBoxBorder(pbxRight1);
                            break;
                        case 2:
                            drawPixtureBoxBorder(pbxRight2);
                            break;
                        case 3:
                            drawPixtureBoxBorder(pbxRight3);
                            break;
                        case 4:
                            drawPixtureBoxBorder(pbxRight4);
                            break;
                        case 5:
                            drawPixtureBoxBorder(pbxRight5);
                            break;
                        case 6:
                            drawPixtureBoxBorder(pbxRight6);
                            break;
                        case 7:
                            drawPixtureBoxBorder(pbxRight7);
                            break;
                        case 8:
                            drawPixtureBoxBorder(pbxRight8);
                            break;
                    }
                    break;
                case "31":
                    switch (slot)
                    {
                        case 1:
                            drawPixtureBoxBorder(pbxAudit1);
                            break;
                        case 2:
                            drawPixtureBoxBorder(pbxAudit2);
                            break;
                        case 3:
                            drawPixtureBoxBorder(pbxAudit3);
                            break;
                        case 4:
                            drawPixtureBoxBorder(pbxAudit4);
                            break;
                    }
                    break;
            }
        }
        private void deleteSelectUISlot(string station, int slot)
        {
            switch (station)
            {
                case "21":
                    switch (slot)
                    {
                        case 1:
                            deletePixtureBoxBorder(pbxInBuffer1);
                            break;
                        case 2:
                            deletePixtureBoxBorder(pbxInBuffer2);
                            break;
                    }
                    break;
                case "101":
                    switch (slot)
                    {
                        case 1:
                            deletePixtureBoxBorder(pbxLeft1);
                            break;
                        case 2:
                            deletePixtureBoxBorder(pbxLeft2);
                            break;
                        case 3:
                            deletePixtureBoxBorder(pbxLeft3);
                            break;
                        case 4:
                            deletePixtureBoxBorder(pbxLeft4);
                            break;
                        case 5:
                            deletePixtureBoxBorder(pbxLeft5);
                            break;
                        case 6:
                            deletePixtureBoxBorder(pbxLeft6);
                            break;
                        case 7:
                            deletePixtureBoxBorder(pbxLeft7);
                            break;
                        case 8:
                            deletePixtureBoxBorder(pbxLeft8);
                            break;
                    }

                    break;
                case "102":
                    switch (slot)
                    {
                        case 1:
                            deletePixtureBoxBorder(pbxRight1);
                            break;
                        case 2:
                            deletePixtureBoxBorder(pbxRight2);
                            break;
                        case 3:
                            deletePixtureBoxBorder(pbxRight3);
                            break;
                        case 4:
                            deletePixtureBoxBorder(pbxRight4);
                            break;
                        case 5:
                            deletePixtureBoxBorder(pbxRight5);
                            break;
                        case 6:
                            deletePixtureBoxBorder(pbxRight6);
                            break;
                        case 7:
                            deletePixtureBoxBorder(pbxRight7);
                            break;
                        case 8:
                            deletePixtureBoxBorder(pbxRight8);
                            break;
                    }
                    break;
                case "31":
                    switch (slot)
                    {
                        case 1:
                            deletePixtureBoxBorder(pbxAudit1);
                            break;
                        case 2:
                            deletePixtureBoxBorder(pbxAudit2);
                            break;
                        case 3:
                            deletePixtureBoxBorder(pbxAudit3);
                            break;
                        case 4:
                            deletePixtureBoxBorder(pbxAudit4);
                            break;
                    }
                    break;
            }
        }
        public bool listenFlag = false;
        private void button8_Click(object sender, EventArgs e)
        {
            
            robot.ip = tbxIP.Text;
            robot.camPort = Convert.ToInt32(tbxCAMPort.Text);
            robot.avcPort = Convert.ToInt32(tbxAVCPort.Text);
            
            if (listenFlag == false)
            {
                robot.ListenCam();
                robot.ListenAVC();
                listenFlag = true;
                btnConnect.Text = "stop";
            }
            else
            {
                robot.stopListenCam();
                robot.stopListenAVC();
                listenFlag = false;
                btnConnect.Text = "listen";
            }
            
        }

        //reset right fixture
        private void button9_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <8;i++ )
            {
                robot.rights.buffer[i].Value = false;

            }
            foreach(Control ctr in groupBox6.Controls)
            {
                if(ctr is PictureBox)
                {
                    PictureBox pix = ctr as PictureBox;
                    pix.Image = imgBuffer.Images[1];
                }
            }
        }
        //reset left fixture
        private void button8_Click_1(object sender, EventArgs e)
        {
            for (int i = 0; i < 8; i++)
            {
                robot.lefts.buffer[i].Value = false;

            }
            foreach (Control ctr in groupBox5.Controls)
            {
                if (ctr is PictureBox)
                {
                    PictureBox pix = ctr as PictureBox;
                    pix.Image = imgBuffer.Images[1];
                }
            }
        }
        //reset audit buffer
        private void button10_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 4; i++)
            {
                robot.audits.buffer[i].Value = false;
            }
            robot.getStatus("00000");
            foreach (Control ctr in groupBox7.Controls)
            {
                if (ctr is PictureBox)
                {
                    PictureBox pix = ctr as PictureBox;
                    pix.Image = imgBuffer.Images[1];
                }
            }
        }
        //reset processBuffer
        private void button11_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 4; i++)
            {
                robot.processBuffer.buffer[i].Value = false;
            }
            robot.getStatus("00000");
            foreach (Control ctr in groupBox4.Controls)
            {
                if (ctr is PictureBox)
                {
                    PictureBox pix = ctr as PictureBox;
                    pix.Image = imgBuffer.Images[1];
                }
            }
        }
        //reset 11 NGBuffer 
        private void button12_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 4; i++)
            {
                robot.ngBuffer.buffer[i].Value = false;
            }
            robot.getStatus("00000");
            foreach (Control ctr in groupBox1.Controls)
            {
                if (ctr is PictureBox)
                {
                    PictureBox pix = ctr as PictureBox;
                    pix.Image = imgBuffer.Images[1];
                }
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 2; i++)
            {
                robot.inBuffer.buffer[i].Value = false;
            }
            robot.getStatus("00000");
            foreach (Control ctr in groupBox2.Controls)
            {
                if (ctr is PictureBox)
                {
                    PictureBox pix = ctr as PictureBox;
                    pix.Image = imgBuffer.Images[1];
                }
            }
        }
        

        
    }
  
    
   
}
