﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimRobot
{
    public class Gripper
    {
        public string name;
        public Sensor suction;
        public Sensor slow;
        public Sensor inductor;
    }
}
