﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.IO;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;
using Pegatron.Automation;
using Pegatron.Communication;
using Pegatron.Automation.SAC.Protocol.RMT;
using Pegatron.Communication.Socket;
using Pegatron.Foundation;


namespace SimRobot
{
    public enum RobotStatus
    {
        Stop,
        Running
    }
    public class RobotL_COMP : Robot
    {
        private bool goldenDoorFlag = false;
        //public bool GoldenDoorFlag
        //{
        //    get;
        //    set {
        //        this.goldenDoorFlag = value;

        //    }
        //}
        private bool drawerFlag = false;
        private int listenCAMPort = 49152;
        private int listenAVCPort = 49155;
        private string currentPosition = "Input";
        private string targetPosition = null;
        private string pick = "pick";
        private string place = "place";
        Dictionary<string, int> csvData = new Dictionary<string, int>();
        public int avcPort = 49155;
        private static Object obj = new object();
        private static Object robotDataObj = new object();
        private static Object AVCDataLockObj = new object();
        public bool continueFlag = false;
        public bool abortFlag = false;
        public List<string[]> motionDataList = new List<string[]>();
        public Timer timer;
        public bool timerFlag=true;
        private int timeOut=30;//s
        private bool pickFlag = false;
       // private bool loadFlag = false;
        private bool unloadFlag = false;
       // private bool binFlag = false;
        //suctionBlow  event
        public delegate void clampEventHander(Sensor sensor, bool suction);
        public delegate void lockHander(string num, bool result);
        //locationData  event
        public delegate void locationEventHander(int location, int slot, bool result);
        public delegate void lightTowerEventHander(LightTower lightTower);
        public delegate void airPressureSpeedHnader(string value);
        public delegate void showLog(string data);
        public delegate void displayRobotMotion(string start, int startSlot, string end, int endSlot);

        public displayRobotMotion robotMotion;
        public displayRobotMotion removeRobotMotion;
        public showLog writeCAMLog;
        public showLog writeAVCLog;
        public clampEventHander clampData;
        public locationEventHander locationData;
        //stationData   event
        public locationEventHander stationData;
        // UUTMAP event 
        public locationEventHander uutMapData;
        //lightTower
        public lightTowerEventHander lightTowerData;
        // set speed
        public airPressureSpeedHnader speedData;
        public lockHander LockData;
        public lockHander ioChangeData;

        private string successCode = "0";
        private string successMessage = "Success";

        public SocketTcpServer server = new SocketTcpServer();
        public SocketTcpServer serverAVC = new SocketTcpServer();
        public RMTClient client = null;

        public RMTClient clientAVC = null;
       
        public Bin lefts = new Bin(8);
        public Bin rights = new Bin(8);

        private string sendDataToAVCFromRobot = null;
        public string SendDataToAVCFromRobot
        {
            get { return sendDataToAVCFromRobot; }
            set
            {
                if (clientAVC != null)
                {
                    sendDataToAVCFromRobot = value;
                    string[] data = sendDataToAVCFromRobot.Split(',');
                    ArrayList args=new ArrayList();
                    for(int i=2;i<sendDataToAVCFromRobot.Length;i++)
                    {
                        args.Add(data[i]);
                    }
                    SendAVC(data[0],data[1], (string[])args.ToArray(typeof(string)));
                }

            }
        }
        Thread motionThread;
        private double pressureNum = 500;
        public double Pressure
        {
            
            get { return this.pressureNum; }
            set
            {
                this.pressureNum = value;
                if (pressureNum >= 400 && pressureNum <= 600)
                {
                    this.airPressure.Value = true;
                    //clientAVC.UnsolicitedSend();
                    this.Send("00000","UNSOLICITED", UNSOLICITED(airPressure.Name, "0"));
                }
                else
                {
                    this.airPressure.Value = false;
                    this.Send("00000","UNSOLICITED", UNSOLICITED(airPressure.Name, "01003"));
                }
            }
        }

        string gripper_config_file = "query_gripper_config.csv";
        string io_mapping_config_file = "query_io_mapping.csv";
        string location_config_file = "query_location_config.csv";

        ArrayList query_gripper_config_args = new ArrayList();
        ArrayList query_location_config_args = new ArrayList();
        ArrayList query_io_mapping_config_args = new ArrayList();

        ArrayList query_accessable_config_args = new ArrayList();
        ArrayList query_reset_devices_args = new ArrayList();
        ArrayList query_movable_devices_args = new ArrayList();
        string[] accessable_config = {"UPDATE_ACCESS_DEVICES","RejectDrawer","20","1","GoldenDoor","21","1","0","Success" };
        string[] reset_devices = { "UPDATE_RESET_DEVICES", "1", "no support reset device" };
        string[] movable_devices = { "UPDATE_MOVABLE_DEVICES", "1", "no support movable device" };
        public RobotL_COMP():base()
        {
            motionThread = new Thread(checkMotionDataListThread);     
            motionThread.IsBackground = true;

            loadConfigFile(query_gripper_config_args, gripper_config_file);
            loadConfigFile(query_location_config_args, location_config_file);
            loadConfigFile(query_io_mapping_config_args, io_mapping_config_file);
            
            query_accessable_config_args.AddRange(accessable_config);
            query_reset_devices_args.AddRange(reset_devices);
            query_movable_devices_args.AddRange(movable_devices);
        }

        private void config_query_info(string id,ArrayList mes)
        {
            string[] args = (string[])mes.ToArray(typeof(string));
            //mes.RemoveAt(0);
           // string str = string.Join(",",(string[])mes.ToArray(typeof(string)));
          //  string data = mesId +","+ str+",0,success";
            ArrayList data = new ArrayList();
            for (int i = 1; i < args.Length;i++ )
            {
                data.Add(args[i]);
            }
            this.Send(id,args[0], (string[])data.ToArray(typeof(string)));
            //Log.WriteLog(args[0] + string.Join(",", (string[])data.ToArray(typeof(string))));
        }
        
        public void Air(bool value)
        {
            this.airPressure.Value = value;
            string[] data = null;
            object error = null;
            getStatus();
            if (this.airPressure.Value)
            {
                data=UNSOLICITED(airPressure.Name, "0");
            }
            else
            {
                data=UNSOLICITED(airPressure.Name, "01003");
            }
            if (client != null)
            {
                client.UnsolicitedSend("UNSOLICITED", ref error, data);
            }
        }
        public void Estop(bool value)
        {
            this.estop.Value = value;
            string[] data = null;
            object error=null;
            getStatus();
            if (this.estop.Value == true)
            {
                data = UNSOLICITED(estop.Name, "01001");
            }
            else
            {
                data=UNSOLICITED(estop.Name, "0");
            }
            if (client != null)
            {
                //this.Send("UNSOLICITED", data);
                client.UnsolicitedSend("UNSOLICITED", ref error, data);
            }
           // getStatus("00");
        }
        
        #region socket listen
        private void OnTcpConnectionReceived(object sender, CommConnectionReceivedEventArgs connection)
        {
            if (connection != null && connection is SocketTcpConnectionReceivedEventArgs)
            {
                SocketTcpConnectionReceivedEventArgs tcpConnection = connection as SocketTcpConnectionReceivedEventArgs;
                this.OnClientSelected(tcpConnection.Client as SocketTcpClient);
            }
        }

        private void timerGetStatus(object args)
        {
            if (timerFlag)
            {
                getStatus();
            }
            else
            {
                GC.Collect();
            }
        }
        private void OnClientSelected(SocketTcpClient newClient)
        {
           // this.client = newClient;

            if (newClient.LocalPort == listenCAMPort)
            {
                this.client = new RMTClient("camClient", newClient);
                this.client.RMTCommandReceived += this.OnSocketDataReceived;
                
                if (this.client != null && this.client.Connected)
                {
                    timer = new Timer(timerGetStatus,"00",0, 15000);
                    GC.KeepAlive(timer);
                    Log.WriteLog("--->CAM connect succeed");
                    //if (!this.client.AsyncReceiving )
                    //{
                    //     this.client.RMTCommandReceived == null
                    //    this.client.EndAsyncRecv();
                    //    this.client.BeginAsyncRecv(SocketAsyncRecvParam.Default, this.OnSocketDataReceived);
                    //}
                }
            }
            else if (newClient.LocalPort == listenAVCPort)
            {
                this.clientAVC = new RMTClient("avcClient", newClient);
                
                if (this.clientAVC != null && this.clientAVC.Connected)
                {
                    this.clientAVC.RMTCommandReceived += this.OnSocketDataReceived;
                    Log.WriteLog("--->AVC connect succeed");
                    //if (!this.clientAVC.AsyncReceiving || this.clientAVC.RMTCommandReceived ==null)
                    //{
                    //    this.clientAVC.EndAsyncRecv();
                    //    this.clientAVC.BeginAsyncRecv(SocketAsyncRecvParam.Default, this.OnSocketDataReceived);
                    //}
                    
                }
            }
            
        }
      
        //send data to AVC
        private bool SendAVC(string id, string commandName,string[] args)
        {
            bool result = false;
            object error = null;
            if (clientAVC != null)
            {
                RMTCommand argsData = new RMTCommand(Convert.ToInt32(id), commandName, args);
                this.clientAVC.Reply(argsData, commandName, ref error, args);
                //RMTCommand command=this.clientAVC.Send(commandName, ref error,args);
                if (argsData != null)
                {
                    Log.WriteLog("----->AVC " + argsData.CommandID + "," + argsData.CommandName + "," + string.Join(",", args));
                    writeAVCLogEvent("----->" + argsData.CommandID + "," + argsData.CommandName + "," + string.Join(",", args) + "\r");
                    result = true;
                }
                else
                {
                    if (error != null)
                    {
                        Log.WriteLog("----->AVC " + id + "," + commandName + "," + string.Join(",", args) + " with error: " + error);
                        writeAVCLogEvent("----->" + id + "," + commandName + "," + string.Join(",", args) + " with error: " + error + "\r");
                    }
                }
            }
            return result;
        }
        // send data to CAM
        private bool Send(string id,string commandName,string[] args)
        {
            bool result = false;
            object error = null;
            if(this.client!=null)
            {
                RMTCommand argsData = new RMTCommand(Convert.ToInt32(id),commandName,args);
                this.client.Reply(argsData, commandName, ref error, args);

                if (argsData != null)
                {
                    Log.WriteLog("----->CAM " + argsData.CommandID.ToString() + "," + argsData.CommandName + "," + string.Join(",", args));
                    writeCAMLogEvent("----->" + argsData.CommandID.ToString() + "," + argsData.CommandName + "," + string.Join(",", args) + "\r");
                    result = true;

                    SendDataToAVCFromRobot = argsData.CommandID.ToString() + "," + argsData.CommandName + "," + string.Join(",", args) + "\r";
                }
                else
                {
                    if (error != null)
                    {
                        Log.WriteLog("----->AVC " + id + "," + commandName + "," + string.Join(",", args) + " with error: " + error);
                        writeAVCLogEvent("----->" + id + "," + commandName + "," + string.Join(",", args) + " with error: " + error + "\r");
                    }
                }
            }
            
            return result;
        }

        private void OnSocketDataReceived(object sender, RMTCommand data)
        {
            if (data != null && data is RMTCommand)
            {
                RMTCommand socketData = data as RMTCommand;

                if (socketData.CommandName!= null)
                {
                    ArrayList recData = new ArrayList();
                    recData.Add(socketData.CommandID.ToString());
                    recData.Add(socketData.CommandName);
                    if (socketData.Args == null)
                    {
                        Log.WriteLog("<-----" + socketData.CommandID + "," + socketData.CommandName);
                    }
                    else
                    {
                        Log.WriteLog("<-----" + socketData.CommandID + "," + socketData.CommandName + "," + string.Join(",", socketData.Args));
                        for (int i = 0; i < socketData.Args.Length; i++)
                        {
                            recData.Add(socketData.Args[i]);
                        }
                    }
                    
                    
                    string[] allData=(string[])recData.ToArray(typeof(string));

                    handleReceiveData(string.Join(",",allData),allData );
                }
            }
        }
        private void handleReceiveData(string mes,string[] data)
        {
            //处理数据
            switch (data[1])
            {
                case "REQUEST_CHANGE_DEVSTATE":
                case "CONNECT":
                case "DISCONNECT":
                case "REMOVE_UUT":
                case "ADD_UUT":
                case "MAKE_ERROR":
                case "ESTOP":
                case "AIR":
                case "POWER":
                case "RESET":
                    writeAVCLogEvent("<-----" + mes);
                    break;
                case "PL":
                case "UB":
                case "UL":
                case "HOME":
                case "PICK":
                case "LOAD":
                case "UNLOAD":
                case "BIN":
                case "ACQUIRE_UUT_MAP":
                case "PULB":
                case "UBPL":
                case "UULL":
                    writeCAMLogEvent("<-----" + mes);
                    continueFlag = false;
                   // Log.WriteLog("COMMAND: " + client.RemotePort.ToString());
                    lock (obj)
                    {
                        motionDataList.Add(data);

                    }
                    motionThread.Start();                   
                    break;
                default:
                    writeCAMLogEvent("<-----" + mes);
                    break;
            }
            MoveAction(data);
        }
        
        public bool ListenCam()
        {
            bool result = false;
            CommResult commResult=null;
            if (client == null)
            {
                commResult = this.server.StartService(new SocketTcpServiceStartParam(this.ip, this.camPort), this.OnTcpConnectionReceived);
            }
            if (commResult.Result)
            {
                Log.WriteLog(ip + "--->listen CAM succeed");
                result = true;
            }
            else
            {
                if (commResult.Error == null)
                {
                    commResult.Error = "failed but no error generated";
                }
                Log.WriteLog(ip + "->listen failed with error: " + commResult.Error);
            }
            return result;
        }
        public bool ListenAVC()
        {
            bool result = false;
            CommResult commResult = null;
            // 192.168.8.11
            // 127.0.0.1
            commResult = this.serverAVC.StartService(new SocketTcpServiceStartParam(this.ip, this.avcPort), this.OnTcpConnectionReceived);
           
            if (commResult.Result)
            {
                Log.WriteLog(ip + "--->listen AVC succeed");
                result = true;
            }
            else
            {
                if (commResult.Error == null)
                {
                    commResult.Error = "failed but no error generated";
                }
                Log.WriteLog(ip + "->listen failed with error: " + commResult.Error);
            }
            return result;
        }
        #endregion
        #region event
        private void uutMapEvent(int location, int slot, bool result = false)
        {
            if (uutMapData != null)
            {
                uutMapData(location, slot, result);
            }
        }
        private void stationDataEvent(int station, int slot, bool result)
        {
            if (stationData != null)
            {
                stationData(station, slot, result);
            }

        }
        private void locationDataEvent(int location, int slot, bool result)
        {
            if (locationData != null)
            {
                locationData(location, slot, result);
            }
        }
        private void clampEvent(Sensor sensor, bool status)
        {
            if (clampData != null)
            {
                clampData(sensor, status);
            }
        }
        private void lightTowerEvent(LightTower sensors)
        {
            if (lightTowerData != null)
            {
                lightTowerData(sensors);
            }
        }
        private void setSpeedEvent(string speed)
        {
            if (speedData!=null)
            {
                speedData(speed);
            }
        }
        private void writeCAMLogEvent(string data)
        {
            if(writeCAMLog!=null)
            {
                writeCAMLog(data);
            }
        }
        private void writeAVCLogEvent(string data)
        {
            if (writeAVCLog != null)
            {
                writeAVCLog(data);
            }
        }
        private void lockEvent(string lockOne,bool result)
        {
            if (LockData!=null)
            {
                LockData(lockOne,result);
            }
        }
        private void ioChangeEvent(string io,bool status)
        {
            if (ioChangeData != null)
            {
                ioChangeData(io,status);
            }
        }
        private void robotMotionEvent(string start, int startSlot, string end, int endSlot)
        {
            if(robotMotion!=null)
            {
                robotMotion(start,startSlot,end,endSlot);
            }
        }
        private void removeRobotMotionEvent(string start, int startSlot, string end, int endSlot)
        {
            if(removeRobotMotion!=null)
            {
                removeRobotMotion(start, startSlot, end, endSlot);
            }
        }
        #endregion
        #region robot action
        private void MoveAction(string[] recData)
        {
            bool flag = false;
            string[] data = null;
            //处理数据
            switch (recData[1])
            {
                case "REQUEST_CHANGE_DEVSTATE":
                    requestChangeDevState(recData[0], Convert.ToInt32(recData[2]), Convert.ToInt32(recData[3]));
                    break;
                case "CONNECT":
                    flag = connect(recData[0]);
                    break;
                case "DISCONNECT":
                    flag = disconnect(recData[0]);
                    break;
                case "REMOVE_UUT":
                    flag = removeUUT(recData);
                    break;
                case "ADD_UUT":
                    flag = addUUT(recData);
                    break;
                case "MAKE_ERROR":
                    flag = makeError(recData);
                    break;
                case "ESTOP":
                    flag = estopError(recData[0],Convert.ToInt32(recData[2]));
                    break;
                case "AIR":
                    flag = air(recData[0],Convert.ToInt32(recData[2]));
                    break;
                case "POWER":
                    flag = power(recData[0], Convert.ToInt32(recData[2]));
                    break;
                case "RESET":
                    reset(recData[0]);
                    flag = true;
                    break;
                case "GET_SPEED":
                    data=GetSpeed();
                    this.Send(recData[0],"GET_SPEED",data);
                    break;
                case "SET_SPEED":
                    data=SetSpeed(recData);
                    this.Send(recData[0], "SET_SPEED", data);
                    break;
                case "QUERY_STATUS":
                    string[] args=updateStatus();
                    this.Send(recData[0], "UPDATE_STATUS", args);
                    break;
                case "GET_CONFIG":
                    data=getConfig(recData);
                    this.Send(recData[0], "GET_CONFIG", data);
                    break;
                case "GET_IO":
                    break;
                case "SET_IO":
                    break;
                case "ACQUIRE_UUT_MAP":
                    data=acquireUUTMap(recData);
                    this.Send(recData[0], "ACQUIRE_UUT_MAP", data);
                    break;
                case "BEACON":
                    data=BEACON(recData);
                    this.Send(recData[0], "BEACON", data);
                    break;
                case "SET_CONFIG":

                    break;
                case "GET_MODE":
                    data = reportMode(recData);
                    this.Send(recData[0], "REPORT_MODE", data);
                    break;
                case "SET_MODE":
                    data = reportMode(recData);
                    this.Send(recData[0], "REPORT_MODE", data);
                    break;
                case "CONTINUE":
                    data = CONTINUE();
                    //Log.WriteLog("CONTINUE: "+client.RemotePort.ToString());
                    this.Send(recData[0], "CONTINUE", data);
                    break;
                case "ABORT":
                    data = ABORT();
                    this.Send(recData[0], "ABORT", data);
                    break;
                case "QUERY_LOCATION_CONFIG":
                    config_query_info(recData[0], query_location_config_args);
                    break;
                case "QUERY_GRIPPER_CONFIG":
                    config_query_info(recData[0], query_gripper_config_args);
                    break;
                case "QUERY_IO_MAPPING":
                    config_query_info(recData[0], query_io_mapping_config_args);
                    break;
                case "QUERY_RESET_DEVICES":
                    config_query_info(recData[0], query_reset_devices_args);
                    break;
                case "QUERY_ACCESS_DEVICES":
                    config_query_info(recData[0], query_accessable_config_args);
                    break;
                case "QUERY_MOVABLE_DEVICES":
                    config_query_info(recData[0], query_movable_devices_args);
                    break;
                //default:
                //    data = recData[0] + "," + recData[1] + "," + ((int)ROBOTERRORCODE.UndefineAction).ToString() + "," + ROBOTERRORCODE.UndefineAction.ToString();
                //    this.Send(data);
                //    break;
            }
          //  this.Send(data);
        }
        
        public void checkMotionDataListThread()
        {
            //string data = null;
            string[] homeData=null;
            string[] querData = null; 
            ROBOTERRORCODE flag = ROBOTERRORCODE.UNOVERWRITE;
            while (true)
            {
                Thread.Sleep(2);
                if (motionDataList.Count >= 1)
                {
                    lock (obj)
                    {
                        string[] motion = motionDataList[0];
                        // update robot motion

                        switch (motion[1])
                        {
                            case "PL":
                                robotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                PL(motion);
                                removeRobotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                break;
                            case "UB":
                                robotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                Thread.Sleep(1000);
                                UB(motion);
                                removeRobotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                break;
                            case "UL":
                                robotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                UL(motion);
                                removeRobotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                break;
                            case "HOME":
                                homeData = HOME(motion);
                                this.Send(motion[0],"HOME",homeData);
                                break;
                            case "PICK":
                                flag=PICK(Convert.ToInt32(motion[2]), motion[3], motion[4]);
                                break;
                            case "LOAD":
                                flag = LOAD(Convert.ToInt32(motion[2]), motion[3], motion[4]);
                                break;
                            case "UNLOAD":
                                flag = UNLOAD(Convert.ToInt32(motion[2]), motion[3], motion[4]);
                                break;
                            case "BIN":
                                flag = BIN(Convert.ToInt32(motion[2]), motion[3], motion[4]);
                                break;
                            case "ACQUIRE_UUT_MAP":
                                querData = acquireUUTMap(motion);
                                this.Send(motion[0], "ACQUIRE_UUT_MAP", querData);
                                break;
                            case "PULB":
                                robotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                PULB(motion);
                                removeRobotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                break;
                            case "UBPL":
                                robotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                UBPL(motion);
                                removeRobotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                break;
                            case "UULL":
                                robotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                UULL(motion);
                                removeRobotMotionEvent(motion[3], Convert.ToInt32(motion[4]), motion[6], Convert.ToInt32(motion[7]));
                                break;
                        }
                        if (flag == ROBOTERRORCODE.SUCCESS)
                        {
                            string[] data  = { motion[2], motion[3], motion[4],"0","Success" };
                            this.Send(motion[0], motion[1], data);
                            flag = ROBOTERRORCODE.UNOVERWRITE;
                        }
                        else if (flag != ROBOTERRORCODE.UNOVERWRITE)
                        {
                            string[] data = { motion[2], motion[3], motion[4], "1", flag.ToString() };
                            this.Send(motion[0], motion[1], data);
                            flag = ROBOTERRORCODE.UNOVERWRITE;
                        }
                        
                        motionDataList.RemoveAt(0);
                    }
                }



            }
        }

        


        private string[] HOME(string[] recData)
        {
            ArrayList args = new ArrayList();
            args.Add(recData[2]);
            args.Add(home());
            args.Add(successCode);
            args.Add(successMessage);
            abortFlag = false;
            continueFlag = false;
            return (string[])args.ToArray(typeof(string));
        }
        
        
       
        private string[] ABORT()
        {
            abortFlag = true;
            continueFlag = false;
            ArrayList args = new ArrayList();
            args.Add(successCode);
            args.Add(successMessage);
            return (string[])args.ToArray(typeof(string));
        }
        public string setIO(string[] recData)
        {
            return "";
        }
        private string getIO(string[] recData)
        {
            return "";
        }
        private string[] updateStatus()
        {
            ArrayList args = new ArrayList();
            args.Add("AUTOMATION");
            args.Add("0x00");
            args.Add("0x"+getIOBitMap());
            args.Add("0x00");
            args.Add(successCode);
            args.Add(successMessage);
            return (string[])args.ToArray(typeof(string));
        }
        public void getStatus()
        {
            string[] args=updateStatus();
           // this.Send("UPDATE_STATUS",(string[])args.ToArray());
            object error = null;
            if (client != null)
            {
                client.UnsolicitedSend("UPDATE_STATUS",ref error,args);
                Log.WriteLog("00000,UPDATE_STATUS," + string.Join(",", args));
            }
        }  //GET_STATUS

        /// <summary>
        /// 回复CAM的SET_MODE命令
        /// </summary>
        /// <param name="recData"></param>
        public string[] reportMode(string[] recData)
        {
            //06977,SET_MODE,20,0[0x0d]
            //06977,REPORT_MODE,20, 0,0,Succeed[0x0d]
            ArrayList args = new ArrayList();
            
            if (recData[1] == "GET_MODE")
            {
                switch (recData[2])
                {
                    case "20":

                        args.Add("20");
                        args.Add(Convert.ToInt32(rejectDrawerClosed.Value));
                        
                        break;
                    case "21":
                        args.Add("21");
                        args.Add(Convert.ToInt32(goldenDoorClosed.Value));
                        break;
                }
                args.Add(successCode);
                args.Add(successMessage);
            }
            else if (recData[1] == "SET_MODE")
            {
                switch (recData[2])
                {
                    case "20":
                        if (recData[3] == "1")// Access enabled
                        {
                           // doorLock.Value = false;
                            rejectDrawerLock.Value = true;
                          //  rejectRight.Value = true;
                            rejectDrawerClosed.Value = true;
                            getStatus();
                            drawerFlag = true;
                            args.Add("20");
                            args.Add(Convert.ToInt32(rejectDrawerLock.Value));
                            args.Add(successCode);
                            args.Add(successMessage);
                        }
                        else  //Access disabled
                        {
                            if (rejectDrawerClosed.Value)
                            {
                                rejectDrawerLock.Value = false;
                                rejectDrawerClosed.Value = false;
                                getStatus();
                                drawerFlag = false;
                                args.Add("20");
                                args.Add(Convert.ToInt32(rejectDrawerLock.Value));
                                args.Add(successCode);
                                args.Add(successMessage);
                            }
                            else
                            {
                                //error
                                args.Add("20");
                                args.Add(Convert.ToInt32(rejectDrawerLock.Value));
                                args.Add(((int)ROBOTERRORCODE.DoorNotClosed).ToString());
                                args.Add(ROBOTERRORCODE.DoorNotClosed.ToString());
                            }
                        }
                        lockEvent("20", rejectDrawerLock.Value);
                        break;
                    case "21":
                        if (recData[3] == "1")// Access enabled
                        {
                            goldenDoorLock.Value = true;
                            goldenDoorClosed.Value = true;
                            goldenDoorLight.Value = true;
                            getStatus();
                            goldenDoorFlag = true;
                            args.Add("21");
                            args.Add(Convert.ToInt32(goldenDoorLock.Value));
                            args.Add(successCode);
                            args.Add(successMessage);
                        }
                        else  //Access disabled
                        {
                            if (goldenDoorClosed.Value)
                            {
                                goldenDoorLock.Value = false;
                                goldenDoorClosed.Value = false;
                                goldenDoorLight.Value = false;
                                getStatus();
                                goldenDoorFlag = false;
                                args.Add("21");
                                args.Add(Convert.ToInt32(goldenDoorLock.Value));
                                args.Add(successCode);
                                args.Add(successMessage);
                            }
                            else
                            {
                                //error
                                args.Add("21");
                                args.Add(goldenDoorLock.Value.ToString());
                                args.Add(((int)ROBOTERRORCODE.DoorNotClosed).ToString());
                                args.Add(ROBOTERRORCODE.DoorNotClosed.ToString());
                            }
                        }
                        lockEvent("21", goldenDoorLock.Value);
                        break;
                }
                
            }

            return (string[])args.ToArray(typeof(string));
        }
        private string[] GetSpeed()
        {
            ArrayList args = new ArrayList();
            args.Add(this.Speed);
            args.Add(successCode);
            args.Add(successMessage);
            return (string[])args.ToArray(typeof(string));
        }
        private string[] SetSpeed(string[] recData)
        {
            ArrayList args = new ArrayList();
            this.Speed = Convert.ToInt32(recData[2]);
            getStatus();
            args.Add(recData[2]);
            args.Add(this.Speed);
            args.Add(successCode);
            args.Add(successMessage);
            setSpeedEvent(Convert.ToString(this.Speed));
            return (string[])args.ToArray(typeof(string));
        }
        private string[] BEACON(string[] recData)
        {
            ArrayList args = new ArrayList();
            switch (recData[2])
            {
                case "Off":
                    lightHouse.Buzzer = false;
                    args.Add("Off");
                    break;
                case "On":
                    lightHouse.Buzzer = true;
                    args.Add("On");
                    break;
                case "NoChange":
                    args.Add(lightHouse.Buzzer ? "On" : "Off");
                    break;
            }
            //Red
            switch (recData[3])
            {
                case "Off":
                    lightHouse.Red = false;
                    args.Add("Off");
                    break;
                case "On":
                    lightHouse.Red = true;
                    args.Add("On");
                    break;
                case "NoChange":
                    args.Add((lightHouse.Red ? "On" : "Off"));
                    break;
            }
            //Amber
            switch (recData[4])
            {
                case "Off":
                    lightHouse.Yellow = false;
                    args.Add("Off");
                    break;
                case "On":
                    lightHouse.Yellow = true;
                    args.Add("On");
                    break;
                case "Flashing":
                    lightHouse.Yellow = true;
                    args.Add("Flashing");
                    break;
                case "NoChange":
                    args.Add((lightHouse.Yellow ? "On" : "0ff"));
                    break;
            }
            //Green
            switch (recData[5])
            {
                case "Off":
                    lightHouse.Green = false;
                    //data = data + "Off,Off,0,Success";
                    args.Add("Off");
                    args.Add("Off");
                    break;
                case "On":
                    lightHouse.Green = true;
                    //data = data + "On,Off,0,Success";
                    args.Add("On");
                    args.Add("Off");
                    break;
                case "NoChange":
                    //data = data + (lightHouse.Green ? "On," : "0ff,") + "0,Success";
                    args.Add(lightHouse.Green ? "On" : "0ff");
                    args.Add("Off");
                    break;
            }
            args.Add(successCode);
            args.Add(successMessage);
            getStatus();

            lightTowerEvent(lightHouse);
            // this.Send(data);
            return (string[])args.ToArray(typeof(string));
        }   //BEACON
        public string[] requestModeChange(int dev, int newState, int oldState)
        {
            ArrayList args = new ArrayList();
            args.Add(dev);
            args.Add(newState);
            args.Add(oldState);
            return (string[])args.ToArray(typeof(string));
        }
        private string[] acquireUUTMap(string[] recData) //ACQUIRE_UUT_MAP
        {
            //00001,ACQUIRE_UUT_MAP,101,01
            ArrayList args = new ArrayList();
            //delay time
            //delayTime(3);
            if (clamp1Open.Value == true&&clamp1Opened.Value==true)
            {
                clamp1Close.Value = true;
                clampEvent(clamp1Close, clamp1Close.Value);
                getStatus();
            }
            switch (recData[2])
            {
                case "101":
                    if (lefts.buffer[Convert.ToInt32(recData[3])-1].Value)
                    {
                        clamp1DUT.Value = true;
                        getStatus();
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        clamp1Open.Value = true;
                        clamp1Opened.Value = true;
                        getStatus();
                        clampEvent(clamp1Opened, clamp1Opened.Value);
                        clamp1DUT.Value = false;
                        getStatus();
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        uutMapEvent(Convert.ToInt32(recData[2]), Convert.ToInt32(recData[3]), lefts.buffer[Convert.ToInt32(recData[3]) - 1].Value);
                        args.Add(recData[2]);
                        args.Add(recData[3]);
                        args.Add("1");
                        //data = recData[0] + ",ACQUIRE_UUT_MAP," + recData[2] + "," + recData[3] + ",1,0,Success";
                    }
                    else
                    {
                        clamp1DUT.Value = false;
                        getStatus();
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        clamp1Open.Value = true;
                        clamp1Opened.Value = true;
                        getStatus();
                        clampEvent(clamp1Opened, clamp1Opened.Value);
                        clamp1DUT.Value = false;
                        getStatus();
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        uutMapEvent(Convert.ToInt32(recData[2]), Convert.ToInt32(recData[3]), lefts.buffer[Convert.ToInt32(recData[3]) - 1].Value);
                       // data = recData[0] + ",ACQUIRE_UUT_MAP," + recData[2] + "," + recData[3] + ",0,0,Success";
                        args.Add(recData[2]);
                        args.Add(recData[3]);
                        args.Add("0");
                    }
                    break;
                case "102":
                    if (rights.buffer[Convert.ToInt32(recData[3])-1].Value)
                    {
                        clamp1DUT.Value = true;
                        getStatus();
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        clamp1Open.Value = true;
                        clamp1Opened.Value = true;
                        getStatus();
                        clampEvent(clamp1Opened, clamp1Opened.Value);
                        clamp1DUT.Value = false;
                        getStatus();
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        uutMapEvent(Convert.ToInt32(recData[2]), Convert.ToInt32(recData[3]), rights.buffer[Convert.ToInt32(recData[3]) - 1].Value);
                        //data = recData[0] + ",ACQUIRE_UUT_MAP," + recData[2] + "," + recData[3] + ",1,0,success";
                        args.Add(recData[2]);
                        args.Add(recData[3]);
                        args.Add("1");
                    }
                    else
                    {
                        clamp1DUT.Value = false;
                        getStatus();
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        clamp1Open.Value = true;
                        clamp1Opened.Value = true;
                        getStatus();
                        clampEvent(clamp1Opened, clamp1Opened.Value);
                        clamp1DUT.Value = false;
                        getStatus();
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        uutMapEvent(Convert.ToInt32(recData[2]), Convert.ToInt32(recData[3]), rights.buffer[Convert.ToInt32(recData[3]) - 1].Value);
                        //data = recData[0] + ",ACQUIRE_UUT_MAP," + recData[2] + "," + recData[3] + ",0,0,Success";
                        args.Add(recData[2]);
                        args.Add(recData[3]);
                        args.Add("0");
                    }
                    break;
               
            }
            args.Add(successCode);
            args.Add(successMessage);
            // this.Send(data);
            return (string[])args.ToArray(typeof(string));
        }
        private string[] UNSOLICITED(string who, string errorCode)
        {
            //string data = "";
            ArrayList args = new ArrayList();
            switch (who)
            {
                case "Estop": //e-stop
                    if (errorCode == "01001")
                    {
                        args.Add(errorCode);
                        args.Add("Robot ESTOP engaged");
                    }
                    else if (errorCode == "0")
                    {
                        args.Add(errorCode);
                        args.Add("Robot ESTOP released");
                    }
                    break;
                case "airPressure": //airPressure
                    if (errorCode == "01003")
                    {
                        args.Add(errorCode);
                        args.Add("Robot Air UnNormal");
                    }
                    else if (errorCode == "0")
                    {
                        args.Add(errorCode);
                        args.Add("Robot Air Normal");
                    }
                    break;
                case "electric":
                    if (errorCode == "01002")
                    {
                        args.Add(errorCode);
                        args.Add("power supply exceptation");
                    }
                    else
                    {
                        args.Add(errorCode);
                        args.Add("power supply normal");
                    }
                    break;
            }
            //this.Send(data);
            return (string[])args.ToArray(typeof(string));
        }
        private string[] getConfig(string[] recData)
        {
            ArrayList args = new ArrayList();
            args.Add(dev_type);
            args.Add(ip);
            args.Add(os_ver);
            args.Add(app_ver);
            args.Add(proto_ver);
            args.Add(serial_num);
            args.Add(successCode);
            args.Add(successMessage);
            return (string[])args.ToArray(typeof(string));
        }

        private ROBOTERRORCODE PULB(string[] recData)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UNOVERWRITE;
            flag = PICK(Convert.ToInt32(recData[2]), recData[3], recData[4]);
            ArrayList data = new ArrayList();

            data.Add(recData[2]);
            data.Add(recData[3]);
            data.Add(recData[4]);
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                
                data.Add(successCode);
                data.Add(successMessage);
            }
            else
            {
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0],"PICK", (string[])data.ToArray(typeof(string)));
            data.Clear();

            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = UNLOAD(Convert.ToInt32(recData[5]), recData[6], recData[7]);
                data.Add(recData[5]);
                data.Add(recData[6]);
                data.Add(recData[6]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add("1");
                    data.Add(flag.ToString());
                }
            }
            else
            {
                data.Add(recData[5]);
                data.Add(recData[6]);
                data.Add(recData[7]);
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "UNLOAD", (string[])data.ToArray(typeof(string)));
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = LOAD(Convert.ToInt32(recData[8]), recData[9], recData[10]);
                data.Add(recData[8]);
                data.Add(recData[9]);
                data.Add(recData[10]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add("1");
                    data.Add(flag.ToString());
                }
            }
            else
            {
                data.Add(recData[8]);
                data.Add(recData[9]);
                data.Add(recData[10]);
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "LOAD", (string[])data.ToArray(typeof(string)));
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = BIN(Convert.ToInt32(recData[11]), recData[12], recData[13]);
                data.Add(recData[11]);
                data.Add(recData[12]);
                data.Add(recData[13]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add("1");
                    data.Add(flag.ToString());
                }
            }
            else
            {
                data.Add(recData[11]);
                data.Add(recData[12]);
                data.Add(recData[13]);
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "BIN", (string[])data.ToArray(typeof(string)));


            return flag;
        }

        private ROBOTERRORCODE UULL(string[] recData)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UNOVERWRITE;
            ArrayList data = new ArrayList();
            flag = UNLOAD(Convert.ToInt32(recData[2]), recData[3], recData[4]);
            
            data.Add(recData[2]);
            data.Add(recData[3]);
            data.Add(recData[4]);
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                
                data.Add(successCode);
                data.Add(successMessage);
            }
            else
            {
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "UNLOAD", (string[])data.ToArray(typeof(string)));
            data.Clear();

            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = UNLOAD(Convert.ToInt32(recData[5]), recData[6], recData[7]);
                data.Add(recData[5]);
                data.Add(recData[6]);
                data.Add(recData[7]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add("1");
                    data.Add(flag.ToString());
                }
            }
            else
            {
                data.Add(recData[5]);
                data.Add(recData[6]);
                data.Add(recData[7]);
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "UNLOAD", (string[])data.ToArray(typeof(string)));
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = LOAD(Convert.ToInt32(recData[8]), recData[9], recData[10]);
                data.Add(recData[8]);
                data.Add(recData[9]);
                data.Add(recData[10]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add("1");
                    data.Add(flag.ToString());
                }
            }
            else
            {
                data.Add(recData[8]);
                data.Add(recData[9]);
                data.Add(recData[10]);
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "LOAD", (string[])data.ToArray(typeof(string)));
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = LOAD(Convert.ToInt32(recData[11]), recData[12], recData[13]);
                data.Add(recData[11]);
                data.Add(recData[12]);
                data.Add(recData[13]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add("1");
                    data.Add(flag.ToString());
                }
            }
            else
            {
                data.Add(recData[11]);
                data.Add(recData[12]);
                data.Add(recData[13]);
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "LOAD", (string[])data.ToArray(typeof(string)));
            return flag;
        }



        private ROBOTERRORCODE UBPL(string[] recData)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UNOVERWRITE;
            ArrayList data = new ArrayList();
            flag=UNLOAD(Convert.ToInt32(recData[2]), recData[3], recData[4]);
            
            data.Add(recData[2]);
            data.Add(recData[3]);
            data.Add(recData[4]);
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                data.Add(successCode);
                data.Add(successMessage);
            }
            else
            {
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "UNLOAD", (string[])data.ToArray(typeof(string)));
            data.Clear();
            
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = BIN(Convert.ToInt32(recData[5]), recData[6], recData[7]);
                data.Add(recData[5]);
                data.Add(recData[6]);
                data.Add(recData[7]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add("1");
                    data.Add(flag.ToString());
                }
            }else
            {
                data.Add(recData[5]);
                data.Add(recData[6]);
                data.Add(recData[7]);
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "BIN", (string[])data.ToArray(typeof(string)));
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = PICK(Convert.ToInt32(recData[8]), recData[9], recData[10]);
                data.Add(recData[8]);
                data.Add(recData[9]);
                data.Add(recData[10]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add("1");
                    data.Add(flag.ToString());
                }
            }
            else
            {
                data.Add(recData[8]);
                data.Add(recData[9]);
                data.Add(recData[10]);
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "PICK", (string[])data.ToArray(typeof(string)));
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = LOAD(Convert.ToInt32(recData[11]), recData[12], recData[13]);
                data.Add(recData[11]);
                data.Add(recData[12]);
                data.Add(recData[13]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add("1");
                    data.Add(flag.ToString());
                }
            }
            else
            {
                data.Add(recData[11]);
                data.Add(recData[12]);
                data.Add(recData[13]);
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "LOAD", (string[])data.ToArray(typeof(string)));
            return flag;
        }
        
        
        public ROBOTERRORCODE PL(string[] recData)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            //string data=null;
            ArrayList data = new ArrayList();
            flag = PICK(Convert.ToInt32(recData[2]), recData[3], recData[4]);
            data.Add(recData[2]);
            data.Add(recData[3]);
            data.Add(recData[4]);
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                data.Add(successCode);
                data.Add(successMessage);
            }
            else
            {
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "PICK", (string[])data.ToArray(typeof(string)));
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = LOAD(Convert.ToInt32(recData[5]), recData[6], recData[7]);
                data.Add(recData[5]);
                data.Add(recData[6]);
                data.Add(recData[7]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add(successCode);
                    data.Add(successMessage);
                }
            }
            else
            {
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "LOAD", (string[])data.ToArray(typeof(string)));
            return flag;
            
        }  //PL
        public ROBOTERRORCODE UB(string[] recData)
        {
            // 49152:12395,UL,01,102,03,01,102,03[0x0d]
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            ArrayList data = new ArrayList();
            flag = UNLOAD(Convert.ToInt32(recData[2]),recData[3], recData[4]);
            data.Add(recData[2]);
            data.Add(recData[3]);
            data.Add(recData[4]);
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                data.Add(successCode);
                data.Add(successMessage);
            }
            else
            {
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "UNLOAD", (string[])data.ToArray(typeof(string)));
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = BIN(Convert.ToInt32(recData[5]), recData[6], recData[7]);
                data.Add(recData[5]);
                data.Add(recData[6]);
                data.Add(recData[7]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add("1");
                    data.Add(flag.ToString());
                }
            }
            else
            {
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "BIN", (string[])data.ToArray(typeof(string)));
            return flag;
        }  //UB
        public ROBOTERRORCODE UL(string[] recData)
        {
            // 49152:12395,UL,01,102,03,01,102,03[0x0d]

            ArrayList data = new ArrayList();
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            flag = UNLOAD(Convert.ToInt32(recData[2]), recData[3], recData[4]);
            data.Add(recData[2]);
            data.Add(recData[3]);
            data.Add(recData[4]);
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                data.Add(successCode);
                data.Add(successMessage);
            }
            else
            {
                data.Add("1");
                data.Add(flag.ToString());
                
            }
            this.Send(recData[0], "UNLOAD", (string[])data.ToArray(typeof(string)));
            data.Clear();
            if (flag == ROBOTERRORCODE.SUCCESS)
            {
                flag = LOAD(Convert.ToInt32(recData[5]),recData[6], recData[7]);
                data.Add(recData[5]);
                data.Add(recData[6]);
                data.Add(recData[7]);
                if (flag == ROBOTERRORCODE.SUCCESS)
                {
                    data.Add(successCode);
                    data.Add(successMessage);
                }
                else
                {
                    data.Add("1");
                    data.Add(flag.ToString());
                }
            }
            else
            {
                data.Add("1");
                data.Add(flag.ToString());
            }
            this.Send(recData[0], "LOAD", (string[])data.ToArray(typeof(string)));
            return flag;
            
        }  //UL
        private string[] CONTINUE()
        {
            continueFlag = true;
            abortFlag = false;
            ArrayList args = new ArrayList();
            args.Add(successCode);
            args.Add(successMessage);
            return (string[])args.ToArray(typeof(string));
        }
        public ROBOTERRORCODE PICK(int gripper,string station,string slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            switch (station)
            {
                case "51":
                    targetPosition="Input";
                    delayTime(csvData[currentPosition + targetPosition+pick],Speed);
                    flag = fromInput(gripper, Convert.ToInt32(slot));
                    break;
                case "21":
                    flag = fromInBuffer(gripper, Convert.ToInt32(slot));
                    break;
                case "31":
                    flag = fromAudit(gripper, Convert.ToInt32(slot));
                    break;
            }
            return flag;
        }
        public ROBOTERRORCODE LOAD(int gripper,string location,string slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            switch (location)
            {
                case "101":
                    switch (slot)
                    {
                        case "1":
                        case "3":
                        case "5":
                        case "7":
                            targetPosition = "L-comp_1";
                            break;
                        case "2":
                        case "4":
                        case "6":
                        case "8":
                            targetPosition = "L-comp_2";
                            break;

                    }
                    delayTime(csvData[currentPosition + targetPosition + place],Speed);
                    flag = toLeft(gripper,Convert.ToInt32(slot));
                    break;
                case "102":
                    switch (slot)
                    {
                        case "1":
                        case "3":
                        case "5":
                        case "7":
                            targetPosition = "L-comp_3";
                            break;
                        case "2":
                        case "4":
                        case "6":
                        case "8":
                            targetPosition = "L-comp_4";
                            break;

                    }
                    delayTime(csvData[currentPosition + targetPosition + place],Speed);
                    flag = toRight(gripper,Convert.ToInt32(slot));
                    break;
            }
            return flag;

        }
        public ROBOTERRORCODE UNLOAD(int gripper,string location,string slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            switch (location)
            {
                case "101":

                    switch (slot)
                    {
                        case "01":
                        case "03":
                        case "05":
                        case "07":
                            targetPosition = "L-comp_1";
                            break;
                        case "02":
                        case "04":
                        case "06":
                        case "08":
                            targetPosition = "L-comp_2";
                            break;

                    }
                    //currentPosition = targetPosition;
                    delayTime(csvData[currentPosition + targetPosition + pick],Speed);
                    flag = fromLeft(gripper, Convert.ToInt32(slot));
                    break;
                case "102":
                    switch (slot)
                    {
                        case "01":
                        case "03":
                        case "05":
                        case "07":
                            targetPosition = "L-comp_3";
                            break;
                        case "02":
                        case "04":
                        case "06":
                        case "08":
                            targetPosition = "L-comp_4";
                            break;

                    }
                    delayTime(csvData[currentPosition + targetPosition + pick],Speed);
                    flag = fromRight(gripper,Convert.ToInt32(slot));
                    break;
            }
            return flag;

        }
        public ROBOTERRORCODE BIN(int gripper,string station,string slot)
        {

            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            switch (station)
            {
                case "52":
                    targetPosition = "Output";
                    delayTime(csvData[currentPosition + targetPosition + place], Speed);
                    //blowAir(5);
                    DateTime timeStart = DateTime.Now;
                    DateTime timeEnd;
                    string time = null;

                    
                        //ADD continue judge

                    while (true)
                    {
                        Thread.Sleep(2);
                        timeEnd = DateTime.Now;
                        time = DateDiff(timeEnd, timeStart);
                        if (Convert.ToInt32(time) >= timeOut)
                        {
                            flag = ROBOTERRORCODE.MoveActionTimeout;
                            break;
                        }
                        if (estop.Value == true)
                        {
                            flag = ROBOTERRORCODE.EmergencyMode;
                            break;
                        }
                        if (abortFlag == true)
                        {
                            abortFlag = false;
                            flag = ROBOTERRORCODE.TaskAbort;
                            break;
                        }
                        if (continueFlag == true)
                        {
                            //continueFlag = false;
                            break;
                        }

                    }
                    if (continueFlag == true && Convert.ToInt32(time) < timeOut)
                    {

                        placeUUTUseWhichGripper(gripper);
                        flag = ROBOTERRORCODE.SUCCESS;
                        continueFlag = false;
                    }
                    break;
                case "21":
                    flag = toInBuffer(gripper,Convert.ToInt32(slot));
                    break;
                case "11":
                    flag = toNGBuffer(gripper,Convert.ToInt32(slot));
                    break;
                case "12":
                    flag = toProcessBuffer(gripper,Convert.ToInt32(slot));
                    break;
                case "31":
                    flag = toAuditBuffer(gripper,Convert.ToInt32(slot));
                    break;
            }
            return flag;
            
        }
        private void placeUUTUseWhichGripper(int gripper)
        {
            if (gripper == 1)
            {
                fetchOver();
            }
            else
            {
                fetchOver2();
            }
        }
        private void takeUUTUseWhichGripper(int gripper)
        {
            if (gripper == 1)
            {
                clampReadyFetch();
            }else
            {
                clamp2ReadyFetch();
            }
        }
        private ROBOTERRORCODE fromInBuffer(int gripper, int startSlot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;

           // flag=suctionAir(5);
            if (gripper == 2)
            {
                if (clamp2Opened.Value == true && clamp2Open.Value == true)
                {
                    takeUUTUseWhichGripper(gripper);


                    if (inBuffer.buffer[startSlot - 1].Value)// inbuffer  have UUT
                    {

                        if (pickFlag)
                        {
                            flag = ROBOTERRORCODE.PickFailed;
                        }
                        else
                        {
                            inBuffer.buffer[startSlot - 1].Value = false;
                            getStatus();
                            clamp2DUT.Value = true;
                            getStatus();
                            // clampEvent(clamp1DUT, clamp1DUT.Value);
                            flag = ROBOTERRORCODE.SUCCESS;
                        }


                    }
                    else
                    {
                        //vacuum.Value = false;
                        //getStatus("00");
                        flag = ROBOTERRORCODE.NoFindUUT;
                    }
                    stationDataEvent(21, startSlot, inBuffer.buffer[startSlot - 1].Value);
                }
                else
                {
                    if (clamp2DUT.Value == true)   // vacuum have UUT
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                }
            }
            else
            {
                if (clamp1Opened.Value == true && clamp1Open.Value == true)
                {
                    takeUUTUseWhichGripper(gripper);


                    if (inBuffer.buffer[startSlot - 1].Value)// inbuffer  have UUT
                    {

                        if (pickFlag)
                        {
                            flag = ROBOTERRORCODE.PickFailed;
                        }
                        else
                        {
                            inBuffer.buffer[startSlot - 1].Value = false;
                            getStatus();
                            clamp1DUT.Value = true;
                            getStatus();
                            clampEvent(clamp1DUT, clamp1DUT.Value);
                            flag = ROBOTERRORCODE.SUCCESS;
                        }


                    }
                    else
                    {
                        //vacuum.Value = false;
                        //getStatus("00");
                        flag = ROBOTERRORCODE.NoFindUUT;
                    }
                    stationDataEvent(21, startSlot, inBuffer.buffer[startSlot - 1].Value);
                }
                else
                {
                    if (clamp1DUT.Value == true)   // vacuum have UUT
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time)>=timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE fromInput(int gripper, int startSlot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
           // flag=suctionAir(5);
            if (gripper == 2)
            {
                if (clamp2Opened.Value == true && clamp2Open.Value == true)
                {
                    takeUUTUseWhichGripper(gripper);
                    clamp2DUT.Value = true;
                    getStatus();
                    //clampEvent(clamp1DUT, clamp1DUT.Value);
                    if (pickFlag)
                    {
                        flag = ROBOTERRORCODE.PickFailed;
                        clamp2DUT.Value = false;
                        getStatus();
                    }
                    else
                    {
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                }
                else
                {
                    if (clamp2DUT.Value == true)
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                }
            }
            else
            {
                if (clamp1Opened.Value == true && clamp1Open.Value == true)
                {
                    takeUUTUseWhichGripper(gripper);
                    clamp1DUT.Value = true;
                    getStatus();
                    clampEvent(clamp1DUT, clamp1DUT.Value);
                    if (pickFlag)
                    {
                        flag = ROBOTERRORCODE.PickFailed;
                        clamp1DUT.Value = false;
                        getStatus();
                    }
                    else
                    {
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                }
                else
                {
                    if (clamp1DUT.Value == true)
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE fromLeft(int gripper, int startSlot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
           // flag=suctionAir(5);
            if (gripper == 2)
            {
                if (clamp2Opened.Value == true && clamp2Open.Value == true)
                {
                    takeUUTUseWhichGripper(gripper);
                    if (unloadFlag)
                    {
                        lefts.buffer[startSlot - 1].Value = true;
                        flag = ROBOTERRORCODE.UnLoadFailed;
                    }
                    else
                    {
                        if (lefts.buffer[startSlot - 1].Value == true)
                        {
                            clamp2DUT.Value = true;
                            getStatus();
                            // clampEvent(clamp1DUT, clamp2DUT.Value);
                            lefts.buffer[startSlot - 1].Value = false;
                            flag = ROBOTERRORCODE.SUCCESS;
                        }
                        else
                        {
                            flag = ROBOTERRORCODE.NoUnitDetect;
                        }
                        
                    }
                }
                else
                {
                    if (clamp2DUT.Value == true)
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                }
            }
            else
            {
                if (clamp1Opened.Value == true && clamp1Open.Value == true)
                {
                    takeUUTUseWhichGripper(gripper);

                    //make unload error flag
                    if (unloadFlag)
                    {
                        lefts.buffer[startSlot - 1].Value = true;
                        flag = ROBOTERRORCODE.UnLoadFailed;
                    }
                    else
                    {
                        clamp1DUT.Value = true;
                        getStatus();
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        lefts.buffer[startSlot - 1].Value = false;
                        flag = ROBOTERRORCODE.SUCCESS;
                    }


                }
                else
                {
                    if (clamp1DUT.Value == true)
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                }
            }
            
            
            locationDataEvent(101, startSlot, lefts.buffer[startSlot-1].Value);
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE fromRight(int gripper, int startSlot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
           // flag=suctionAir(5);
            if (gripper == 2)
            {
                if (clamp2Opened.Value == true && clamp2Open.Value == true)
                {
                    takeUUTUseWhichGripper(gripper);


                    if (unloadFlag)
                    {
                        rights.buffer[startSlot - 1].Value = true;//抓不起來
                        flag = ROBOTERRORCODE.UnLoadFailed;
                    }
                    else
                    {
                        clamp2DUT.Value = true;
                        getStatus();
                        //clampEvent(clamp1DUT, clamp1DUT.Value);
                        rights.buffer[startSlot - 1].Value = false;
                        flag = ROBOTERRORCODE.SUCCESS;
                    }

                }
                else
                {
                    if (clamp2DUT.Value == true)
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                }
            }
            else
            {
                if (clamp1Opened.Value == true && clamp1Open.Value == true)
                {
                    takeUUTUseWhichGripper(gripper);


                    if (unloadFlag)
                    {
                        rights.buffer[startSlot - 1].Value = true;//抓不起來
                        flag = ROBOTERRORCODE.UnLoadFailed;
                    }
                    else
                    {
                        clamp1DUT.Value = true;
                        getStatus();
                        clampEvent(clamp1DUT, clamp1DUT.Value);
                        rights.buffer[startSlot - 1].Value = false;
                        flag = ROBOTERRORCODE.SUCCESS;
                    }

                }
                else
                {
                    if (clamp1DUT.Value == true)
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                }
            }
            locationDataEvent(102, startSlot, rights.buffer[startSlot - 1].Value);
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE fromAudit(int gripper, int startSlot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;

            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;

            // flag=suctionAir(5);
            if (gripper == 2)
            {
                if (clamp2Opened.Value == true && clamp2Open.Value == true)
                {
                    takeUUTUseWhichGripper(gripper);
                    if (audits.buffer[startSlot - 1].Value)// audit  have UUT
                    {

                        if (pickFlag)
                        {
                            flag = ROBOTERRORCODE.PickFailed;
                        }
                        else
                        {
                            audits.buffer[startSlot - 1].Value = false;
                            getStatus();
                            clamp2DUT.Value = true;
                            getStatus();
                            //clampEvent(clamp1DUT, clamp1DUT.Value);
                            flag = ROBOTERRORCODE.SUCCESS;
                        }


                    }
                    else
                    {
                        //vacuum.Value = false;
                        //getStatus("00");
                        flag = ROBOTERRORCODE.NoFindUUT;
                    }
                    stationDataEvent(31, startSlot, audits.buffer[startSlot - 1].Value);
                }
                else
                {
                    if (clamp2DUT.Value == true)   // vacuum have UUT
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                }
            }
            else
            {
                if (clamp1Opened.Value == true && clamp1Open.Value == true)
                {
                    takeUUTUseWhichGripper(gripper);
                    if (audits.buffer[startSlot - 1].Value)// audit  have UUT
                    {

                        if (pickFlag)
                        {
                            flag = ROBOTERRORCODE.PickFailed;
                        }
                        else
                        {
                            audits.buffer[startSlot - 1].Value = false;
                            getStatus();
                            clamp1DUT.Value = true;
                            getStatus();
                            clampEvent(clamp1DUT, clamp1DUT.Value);
                            flag = ROBOTERRORCODE.SUCCESS;
                        }


                    }
                    else
                    {
                        //vacuum.Value = false;
                        //getStatus("00");
                        flag = ROBOTERRORCODE.NoFindUUT;
                    }
                    stationDataEvent(31, startSlot, audits.buffer[startSlot - 1].Value);
                }
                else
                {
                    if (clamp1DUT.Value == true)   // vacuum have UUT
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private void clampReadyFetch()
        {
            clamp1Open.Value = false;
            clamp1Opened.Value = false;
            getStatus();
            clampEvent(clamp1Opened, clamp1Opened.Value);
            clamp1Close.Value = true;
            getStatus();

        }
        private void clamp2ReadyFetch()
        {
            clamp2Open.Value = false;
            clamp2Opened.Value = false;
            getStatus();
            //clampEvent(clamp2Opened, clamp2Opened.Value);
            clamp2Close.Value = true;
            getStatus();

        }
        private ROBOTERRORCODE toLeft(int gripper,int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (gripper == 2)
            {
                if (clamp2DUT.Value)
                {
                    if (lefts.buffer[slot - 1].Value == true)
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);
                        lefts.buffer[slot - 1].Value = true;
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                }
                else
                {
                    flag = ROBOTERRORCODE.NoUnitDetect;
                    //lefts.buffer[slot - 1].Value = false;
                }
            }
            else
            {
                if (clamp1DUT.Value)
                {
                    if (lefts.buffer[slot - 1].Value == true)
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);
                        lefts.buffer[slot - 1].Value = true;
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                }
                else
                {
                    flag = ROBOTERRORCODE.NoUnitDetect;
                    //lefts.buffer[slot - 1].Value = false;
                }
            }
            locationDataEvent(101, slot, lefts.buffer[slot - 1].Value);
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE toRight(int gripper,int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (gripper == 2)
            {
                if (clamp2DUT.Value)
                {
                    if (rights.buffer[slot - 1].Value == true)
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);
                        rights.buffer[slot - 1].Value = true;
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                }
                else
                {
                    flag = ROBOTERRORCODE.NoUnitDetect;
                    //  rights.buffer[slot - 1].Value = false;
                }
            }
            else
            {
                if (clamp1DUT.Value)
                {
                    if (rights.buffer[slot - 1].Value == true)
                    {
                        flag = ROBOTERRORCODE.UnitAlreadyExist;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);
                        rights.buffer[slot - 1].Value = true;
                        flag = ROBOTERRORCODE.SUCCESS;
                    }
                }
                else
                {
                    flag = ROBOTERRORCODE.NoUnitDetect;
                    //  rights.buffer[slot - 1].Value = false;
                }
            }
            locationDataEvent(102, slot, rights.buffer[slot - 1].Value);
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE toAuditBuffer(int gripper,int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (gripper == 2)
            {
                if (clamp2DUT.Value)
                {
                    if (audits.buffer[slot - 1].Value)
                    {
                        flag = ROBOTERRORCODE.PositionIsUsed;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);

                        audits.buffer[slot - 1].Value = true;
                        getStatus();

                        //sleep some time check again
                        if (audits.buffer[slot - 1].Value == false)
                        {
                            flag = ROBOTERRORCODE.NoDetectSignal;
                        }
                        else
                        {
                            flag = ROBOTERRORCODE.SUCCESS;
                        }
                        stationDataEvent(31, slot, inBuffer.buffer[slot - 1].Value);
                    }
                }
            }
            else
            {
                if (clamp1DUT.Value)
                {
                    if (audits.buffer[slot - 1].Value)
                    {
                        flag = ROBOTERRORCODE.PositionIsUsed;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);

                        audits.buffer[slot - 1].Value = true;
                        getStatus();

                        //sleep some time check again
                        if (audits.buffer[slot - 1].Value == false)
                        {
                            flag = ROBOTERRORCODE.NoDetectSignal;
                        }
                        else
                        {
                            flag = ROBOTERRORCODE.SUCCESS;
                        }
                        stationDataEvent(31, slot, inBuffer.buffer[slot - 1].Value);
                    }
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE toInBuffer(int gripper,int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (gripper == 2)
            {
                if (clamp2DUT.Value)
                {
                    if (inBuffer.buffer[slot - 1].Value)
                    {
                        flag = ROBOTERRORCODE.PositionIsUsed;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);

                        inBuffer.buffer[slot - 1].Value = true;
                        getStatus();

                        //sleep some time check again
                        if (inBuffer.buffer[slot - 1].Value == false)
                        {
                            flag = ROBOTERRORCODE.NoDetectSignal;
                        }
                        else
                        {
                            flag = ROBOTERRORCODE.SUCCESS;
                        }
                        stationDataEvent(21, slot, inBuffer.buffer[slot - 1].Value);
                    }
                }
            }
            else
            {
                if (clamp1DUT.Value)
                {
                    if (inBuffer.buffer[slot - 1].Value)
                    {
                        flag = ROBOTERRORCODE.PositionIsUsed;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);

                        inBuffer.buffer[slot - 1].Value = true;
                        getStatus();

                        //sleep some time check again
                        if (inBuffer.buffer[slot - 1].Value == false)
                        {
                            flag = ROBOTERRORCODE.NoDetectSignal;
                        }
                        else
                        {
                            flag = ROBOTERRORCODE.SUCCESS;
                        }
                        stationDataEvent(21, slot, inBuffer.buffer[slot - 1].Value);
                    }
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE toProcessBuffer(int gripper,int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (gripper == 2)
            {
                if (clamp2DUT.Value)
                {
                    if (processBuffer.buffer[slot - 1].Value)
                    {
                        flag = ROBOTERRORCODE.PositionIsUsed;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);

                        processBuffer.buffer[slot - 1].Value = true;
                        getStatus();
                        //sleep some time check again

                        if (processBuffer.buffer[slot - 1].Value == false)
                        {
                            flag = ROBOTERRORCODE.NoDetectSignal;
                        }
                        else
                        {
                            flag = ROBOTERRORCODE.SUCCESS;
                        }
                        stationDataEvent(12, slot, processBuffer.buffer[slot - 1].Value);
                    }
                }
            }
            else
            {
                if (clamp1DUT.Value)
                {
                    if (processBuffer.buffer[slot - 1].Value)
                    {
                        flag = ROBOTERRORCODE.PositionIsUsed;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);

                        processBuffer.buffer[slot - 1].Value = true;
                        getStatus();
                        //sleep some time check again

                        if (processBuffer.buffer[slot - 1].Value == false)
                        {
                            flag = ROBOTERRORCODE.NoDetectSignal;
                        }
                        else
                        {
                            flag = ROBOTERRORCODE.SUCCESS;
                        }
                        stationDataEvent(12, slot, processBuffer.buffer[slot - 1].Value);
                    }
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        private ROBOTERRORCODE toNGBuffer(int gripper,int slot)
        {
            ROBOTERRORCODE flag = ROBOTERRORCODE.UndefineError;
            DateTime timeStart = DateTime.Now;
            DateTime timeEnd;
            string time = null;
            if (gripper == 2)
            {
                if (clamp2DUT.Value)
                {
                    if (ngBuffer.buffer[slot - 1].Value)
                    {
                        flag = ROBOTERRORCODE.PositionIsUsed;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);

                        ngBuffer.buffer[slot - 1].Value = true;
                        getStatus();
                        if (ngBuffer.buffer[slot - 1].Value == false)
                        {
                            flag = ROBOTERRORCODE.NoDetectSignal;
                        }
                        else
                        {
                            flag = ROBOTERRORCODE.SUCCESS;
                        }
                        stationDataEvent(11, slot, ngBuffer.buffer[slot - 1].Value);
                    }
                }
            }
            else
            {
                if (clamp1DUT.Value)
                {
                    if (ngBuffer.buffer[slot - 1].Value)
                    {
                        flag = ROBOTERRORCODE.PositionIsUsed;
                    }
                    else
                    {
                        placeUUTUseWhichGripper(gripper);

                        ngBuffer.buffer[slot - 1].Value = true;
                        getStatus();
                        if (ngBuffer.buffer[slot - 1].Value == false)
                        {
                            flag = ROBOTERRORCODE.NoDetectSignal;
                        }
                        else
                        {
                            flag = ROBOTERRORCODE.SUCCESS;
                        }
                        stationDataEvent(11, slot, ngBuffer.buffer[slot - 1].Value);
                    }
                }
            }
            timeEnd = DateTime.Now;
            time = DateDiff(timeEnd, timeStart);
            if (Convert.ToInt32(time) >= timeOut)
            {
                flag = ROBOTERRORCODE.MoveActionTimeout;
            }
            return flag;
        }
        //clamp grab uut finished
        private void fetchOver2()
        {
            clamp2Close.Value = false;
            getStatus();
            clamp2Open.Value = true;
            getStatus();
            clamp2Opened.Value = true;
            getStatus();
           // clampEvent(clamp2Opened, clamp2Opened.Value);
            clamp2DUT.Value = false;
            getStatus();
           // clampEvent(clamp2DUT, clamp2DUT.Value);
            Thread.Sleep(850);
        }
        private void fetchOver()
        {
            clamp1Close.Value = false;
            getStatus();
            clamp1Open.Value = true;
            getStatus();
            clamp1Opened.Value = true;
            getStatus();
            clampEvent(clamp1Opened, clamp1Opened.Value);
            clamp1DUT.Value = false;
            getStatus();
            clampEvent(clamp1DUT, clamp1DUT.Value);
            Thread.Sleep(850);
        }
        #endregion
        // s 
        private static string DateDiff(DateTime DateTime1, DateTime DateTime2)
        {
            string dateDiff = null;
            TimeSpan ts1 = new TimeSpan(DateTime1.Ticks);
            TimeSpan ts2 = new TimeSpan(DateTime2.Ticks);
            TimeSpan ts = ts1.Subtract(ts2).Duration();
            dateDiff = ts.Seconds.ToString();
            return dateDiff;
        }
        #region make exceptation 
        public bool connect(string id)
        {
            ArrayList data = new ArrayList();
            //string data = null;
            bool flag = false;
            if (client == null&&this.server==null)
            {
                this.server = new SocketTcpServer();
                if (ListenCam())
                {

                    Thread.Sleep(5000);
                    DateTime timeStart = DateTime.Now;
                    DateTime timeEnd;
                    string time = null;
                    while (client == null)
                    {
                        Thread.Sleep(2);
                        timeEnd = DateTime.Now;
                        time = DateDiff(timeEnd, timeStart);
                        if (Convert.ToInt32(time) >= 600)//connect timeout time 600s
                        {
                            flag = false;
                            //data = recData + ",CONNECT,1,connect timeout.";
                            //data.Append(recData).Append(",CONNECT,1,connect timeout.");
                            data.Add("1");
                            data.Add("connect timeout");
                            break;
                        }
                    }
                    if (this.client != null)
                    {
                        flag = true;
                        timer.Change(0, 10000);
                        //data = recData + ",CONNECT,0,SUCCESS.";
                        //data.Append(recData).Append(",CONNECT,0,SUCCESS.");
                        data.Add(successCode);
                        data.Add(successMessage);
                    }
                }
            }
            else
            {
                //data = recData + ",CONNECT,1,please check connect status.";
               // data.Append(recData).Append(",CONNECT,1,please check connect status.");
                data.Add("1");
                data.Add("please check connect status");
            }
            this.SendAVC(id,"CONNECT", (string[])data.ToArray(typeof(string)));
            return flag;
        }
        public bool disconnect(string id)
        {
            //string data = null;
            ArrayList data = new ArrayList();
            bool flag = false;
            if (client != null)
            {
                timer.Change(0, Timeout.Infinite);
                this.server.StopService();
                
               // client.Disconnect();
                if (this.client!=null)
                {
                    this.client.Disconnect();
                }
                this.client = null;
                this.server = null;
                //this.st
                flag = true;
                data.Add(successCode);
                data.Add(successMessage);
            }
            else
            {
                data.Add("1");
                data.Add("please check connect status");
            }
            this.SendAVC(id,"DISCONNECT", (string[])data.ToArray(typeof(string)));
            return flag;
        }
        public bool removeUUT(string[] param)
        {
            bool flag = false;
            ArrayList data = new ArrayList();
            switch (param[2])
            {
                case "101":
                    lefts.buffer[Convert.ToInt32(param[3])-1].Value = false;
                    getStatus();
                    flag = true;
                    locationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), lefts.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    break;
                case "102":
                    rights.buffer[Convert.ToInt32(param[3])-1].Value = false;
                    getStatus();
                    flag = true;
                    locationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), rights.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    break;
                case "21":
                    inBuffer.buffer[Convert.ToInt32(param[3])-1].Value = false;
                    getStatus();
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), inBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    break;
                case "31":
                    audits.buffer[Convert.ToInt32(param[3])-1].Value = false;
                    getStatus();
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), audits.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    break;
                case "11":
                    ngBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value = false;
                    getStatus();
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), ngBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    break;
                case "12":
                    processBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value = false;
                    getStatus();
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), processBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    break;
            }
            data.Add(param[2]);
            data.Add(param[3]);
            data.Add(successCode);
            data.Add(successMessage);
            this.SendAVC(param[0],"REMOVE_UUT", (string[])data.ToArray(typeof(string)));
            return flag;
        }
        public bool addUUT(string[] param)
        {
            bool flag = false;
            //string data = null;
            ArrayList data = new ArrayList();
            
            switch (param[2])
            {
                case "101":
                    lefts.buffer[Convert.ToInt32(param[3]) - 1].Value = true;
                    getStatus();
                    flag = true;
                    locationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), lefts.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    break;
                case "102":
                    rights.buffer[Convert.ToInt32(param[3]) - 1].Value = true;
                    getStatus();
                    flag = true;
                    locationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), rights.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    break;
                case "21":
                    inBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value = true;
                    getStatus();
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), inBuffer.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    break;
                case "31":
                    audits.buffer[Convert.ToInt32(param[3]) - 1].Value = true;
                    getStatus();
                    flag = true;
                    stationDataEvent(Convert.ToInt32(param[2]), Convert.ToInt32(param[3]), audits.buffer[Convert.ToInt32(param[3]) - 1].Value);
                    break;
            }
            data.Add(param[2]);
            data.Add(param[3]);
            data.Add(successCode);
            data.Add(successMessage);
            this.SendAVC(param[0],"ADD_UUT", (string[])data.ToArray(typeof(string)));
            return flag;
        }

        public bool makeError(string[] param)
        {
            bool flag = false;
            //string data = null;
            ArrayList data = new ArrayList();
            switch (param[2])
            {
                case "PICK":
                    pickFlag = true;
                    break;
                case "BIN":
                    break;
                case "LOAD":
                    break;
                case "UNLOAD":
                    unloadFlag = true;
                    break;
            }
            data.Add(param[2]);
            data.Add(param[3]);
            data.Add(param[4]);
            data.Add(successCode);
            data.Add(successMessage);
            SendAVC(param[0],param[1], (string[])data.ToArray(typeof(string)));
            return flag;
        }
        public bool estopError(string mesId,int status)
        {
            bool flag = false;
            //string data=null;
            ArrayList data = new ArrayList();
            if (status==1) //pressed
            {
                estop.Value = true;
                Estop(estop.Value);
                getStatus();
                flag = true;
            }
            else
            {
                estop.Value = false;
                Estop(estop.Value);
                getStatus();
                flag = true;

            }
            data.Add(status.ToString());
            data.Add(successCode);
            data.Add(successMessage);
            ioChangeEvent(estop.Name, estop.Value);
            this.SendAVC(mesId,"ESTOP", (string[])data.ToArray(typeof(string)));
            return flag;
        }
        public bool air(string mesId,int status)
        {
            bool flag = false;
            //string data = null;
            ArrayList data=new ArrayList();
            if (status == 1)//abnormal
            {
                airPressure.Value = false;
                Air(airPressure.Value);
                flag = true;
            }
            else
            {
                airPressure.Value = true;
                Air(airPressure.Value);
                flag = true;
            }
           // data = mesId + ",AIR," + status.ToString() + ",0,SUCCESS";
            //data.Append(mesId).Append(",AIR,").Append(status.ToString()).Append(",0,SUCCESS");
            data.Add(status.ToString());
            data.Add(successCode);
            data.Add(successMessage);
            this.SendAVC(mesId,"AIR", (string[])data.ToArray(typeof(string)));
            return flag;
        }
        public bool power(string mesId,int status)
        {
            bool flag = false;
            object error = null;
            //string data = null;
            string[] data = null;
            ArrayList args = new ArrayList();
            if (status == 1)
            {
                electric.Value = false;
                data = UNSOLICITED(electric.Name, "01002");
                getStatus();
                flag = true;
            }
            else
            {
                electric.Value = true;
                data = UNSOLICITED(electric.Name, "0");
                getStatus();
                flag = true;
            }
            if (client != null)
            {
                client.UnsolicitedSend("UNSOLICITED", ref error, data);
            }
            //data = mesId + ",POWER," + status.ToString() + ",0,SUCCESS";
           // data.Append(mesId).Append(",POWER,").Append(status.ToString()).Append(",0,SUCCESS");
            args.Add(status.ToString());
            args.Add(successCode);
            args.Add(successMessage);
            this.SendAVC(mesId,"POWER", (string[])data.ToArray());
            return flag;
        }
        public void reset(string mesId)
        {
            // pick  unload error
            pickFlag = false;
            unloadFlag = false;
            ArrayList args = new ArrayList();
            //connect error
            if (client == null)
            {

                ListenCam();
                timer.Change(0, 10000);
            }
            //estop
            estop.Value = false;
            getStatus();
            ioChangeEvent(estop.Name, estop.Value);
            //air
            airPressure.Value = true;
            getStatus();
            //electric
            electric.Value = true;
            getStatus();
            UNSOLICITED(electric.Name,"0");
            //data = mesId + ",RESET,0,SUCCESS";
            args.Add(successCode);
            args.Add(successMessage);
            this.SendAVC(mesId,"RESET", (string[])args.ToArray(typeof(string)));
        }
        private void requestChangeDevState(string mesId, int devID, int state)
        {
            DateTime timeEnd;
            double time = 0;
            DateTime timeStart = DateTime.Now;
            ArrayList args = new ArrayList();

            if (devID == 20)
            {
                if (state == 1)// request open
                {
                    rejectButton.Value = true;
                    getStatus();
                    requestModeChange(20, 1, 0);
                    while (drawerFlag == false)//opened
                    {
                        Thread.Sleep(2);
                        timeEnd = DateTime.Now;
                        time = timeDiff(timeEnd, timeStart);
                        if (Convert.ToInt32(time) >= 10000)
                        {
                            break;
                        }
                    }
                    args.Add(devID);
                    args.Add(state);
                    if (drawerFlag)
                    {
                        args.Add(successCode);
                        args.Add(successMessage);
                    }
                    else
                    {
                        args.Add("1");
                        args.Add("timeout");
                    }
                    this.SendAVC(mesId,"REQUEST_CHANGE_DEVSTATE", (string[])args.ToArray(typeof(string)));
                }
                else
                {
                    rejectButton.Value = false;
                    getStatus();
                    requestModeChange(20, 0, 1);
                    while (drawerFlag)//closed
                    {
                        Thread.Sleep(4);
                        timeEnd = DateTime.Now;
                        time = timeDiff(timeEnd, timeStart);
                        if (Convert.ToInt32(time) >= 10000)
                        {
                            break;
                        }
                    }
                    args.Add(devID);
                    args.Add(state);
                    if (drawerFlag == false)
                    {
                        args.Add(successCode);
                        args.Add(successMessage);
                    }
                    else
                    {
                        args.Add("1");
                        args.Add("timeout");
                    }
                    this.SendAVC(mesId,"REQUEST_CHANGE_DEVSTATE", (string[])args.ToArray(typeof(string)));
                }
            }
            else if (devID == 21)
            {
                if (state == 1)
                {
                    goldenButten.Value = true;
                    getStatus();
                    requestModeChange(21, 1, 0);
                    Thread.Sleep(4);
                    while (goldenDoorFlag == false)
                    {
                        //time out
                        Thread.Sleep(4);
                        timeEnd = DateTime.Now;
                        time = timeDiff(timeEnd, timeStart);
                        if (Convert.ToInt32(time) >= 10000)
                        {
                            break;
                        }
                    }
                    args.Add(devID);
                    args.Add(state);
                    if (goldenDoorFlag)
                    {
                        args.Add(successCode);
                        args.Add(successMessage);
                    }
                    else
                    {
                        args.Add("1");
                        args.Add("timeout");
                    }
                    this.SendAVC(mesId,"REQUEST_CHANGE_DEVSTATE", (string[])args.ToArray(typeof(string)));
                }
                else
                {
                    goldenButten.Value = false;
                    getStatus();
                    requestModeChange(21, 0, 1);
                    Thread.Sleep(4);
                    while (goldenDoorFlag)
                    {
                        //time out
                        Thread.Sleep(4);
                        timeEnd = DateTime.Now;
                        time = timeDiff(timeEnd, timeStart);
                        if (Convert.ToInt32(time) >= 10000)
                        {
                            break;
                        }
                    }
                    args.Add(devID);
                    args.Add(state);
                    if (goldenDoorFlag == false)
                    {
                        //this.SendAVC(mesId + ",REQUEST_CHANGE_DEVSTATE," + devID + "," + state + ",0,Success");
                        args.Add(successCode);
                        args.Add(successMessage);
                    }
                    else
                    {
                        args.Add("1");
                        args.Add("timeout");
                    }
                    this.SendAVC(mesId,"REQUEST_CHANGE_DEVSTATE", (string[])args.ToArray(typeof(string)));
                }
            }


        }
        #endregion
        //ms
        private static double timeDiff(DateTime DateTime1, DateTime DateTime2)
        {
            TimeSpan ts1 = new TimeSpan(DateTime1.Ticks);
            
            TimeSpan ts2 = new TimeSpan(DateTime2.Ticks);
            double t3 = ts1.TotalMilliseconds - ts2.TotalMilliseconds;
            //TimeSpan ts = ts1.Subtract(ts2).Duration();
            //dateDiff = ts.Milliseconds.ToString();
            //TimeSpan span = (TimeSpan)(DateTime1 - DateTime2);
           // dateDiff = span.TotalMilliseconds.ToString();
            return t3;
        }
        // Milliseconds
        private void delayTime(int times,int speed)
        {
            if (speed != 100)
            {
                DateTime timeEnd;
                double time = 0;
                DateTime timeStart = DateTime.Now;
                while (true)
                {
                    Thread.Sleep(2);
                    timeEnd = DateTime.Now;
                    time = timeDiff(timeEnd, timeStart);
                    if (Convert.ToInt32(time) >= times)
                    {
                        break;
                    }
                }
                currentPosition = targetPosition;
            }
            
        }
        public void readCSVFile()
        {
            string path = System.Environment.CurrentDirectory;
            StreamReader reader = new StreamReader(System.IO.Path.Combine(path, "testCSV.csv"), Encoding.UTF8);
          //  StreamReader reader = new StreamReader(path, Encoding.UTF8,true);
            string line = "";
            line = reader.ReadLine();
            while (line != "")
            {
                Thread.Sleep(2);
                string[] data = line.Split(',');
                if (data[0] == "")
                {
                    break;
                }
                if(data.Length>=3)
                {
                    csvData.Add(data[0] + data[1] + data[2], Convert.ToInt32(data[3]));
                    
                }
                line = reader.ReadLine();
            }
            reader.Close();
        }
        
        private void loadConfigFile(ArrayList args,string file)
        {
            string path = System.Environment.CurrentDirectory;
            StreamReader reader = new StreamReader(System.IO.Path.Combine(path, file), Encoding.UTF8);
            string line = "";
            line = reader.ReadLine();
            while (line != ""&&line!=null)
            {
                Thread.Sleep(2);
                string[] data = line.Split(',');
                if (data[0] == "")
                {
                    break;
                }
                if (data.Length >= 3)
                {
                    args.AddRange(data);
                }
                line = reader.ReadLine();
            }
            reader.Close();
        }
        public void stopListenCam()
        {
            try
            {
                if (this.server.ServiceRunning)
                {
                    client.Disconnect();
                    client = null;
                    if (motionThread.IsAlive)
                    {
                        motionThread.Abort();
                    }
                    this.server.StopService();
                }
            }
            catch (System.Exception)
            {
            }
        }
        public void stopListenAVC()
        {
            try
            {
                if (this.serverAVC.ServiceRunning)
                {
                    clientAVC.Disconnect();
                    clientAVC = null;
                    this.serverAVC.StopService();
                }
            }
            catch (System.Exception)
            {
            }
        }
        
    }
}

