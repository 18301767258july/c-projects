﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimRobot
{
    public class Sensor
    {
        public string Name
        {
            get;
            set;
        }

        public bool Value
        {
            get;
            set;
        }
        public Sensor(string name, bool value)
        {
            this.Name = name;
            this.Value = value;
        }
        private bool enabled = true;
        public bool Enabled
        {
            get{return enabled;}
            set{this.enabled=value;}
        }
    }
    
}
