﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SimRobot
{
    public partial class ShowCamLog : Form
    {
        public ShowCamLog()
        {
            InitializeComponent();
        }
        private string receiveData;

        public string ReceiveData
        {
            //get { return receiveData; }
            set { receiveData = value; }
        }
        

        private void ShowCamLog_Load(object sender, EventArgs e)
        {
            
        }
        private delegate void InvokeCallback(string msg);

        void m_comm_MessageEvent(string msg)
        {
            if (listBox1.InvokeRequired)
            {
                InvokeCallback msgCallback = new InvokeCallback(m_comm_MessageEvent);

                listBox1.Invoke(msgCallback, new object[] { msg });
            }
            else
            {
                listBox1.Items.Add(msg);

            }
        }

        public void showCAMLog()
        {
            if (receiveData.Contains("!"))
            {
                string text = receiveData.Replace("!", "");
                m_comm_MessageEvent(text);
            }
            else
            {
                m_comm_MessageEvent(receiveData);
            }
        }

        private void ShowCamLog_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }
       
    }
}
