﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;

namespace SimRobot
{
    #region Robot error code
    public enum ROBOTERRORCODE
    {
        UNOVERWRITE = -1,
        SUCCESS = 11000,
        UndefineError = 11001,
        SuctionTimeout = 11002,
        BlowTimeout = 11003,
        UndefineCommand = 11006,
        NoUnitDetect = 11007,
        UnitAlreadyExist = 11008,
        PositionIsUsed = 11009,
        CAMSTOP = 11010,
        ManualMode = 11011,
        EmergencyMode = 11012,
        MoveActionTimeout = 11013,
        UnknownState = 11014,
        NoDetectSignal = 11015,
        GripperMaskError = 11016,
        TaskAbort = 11017,
        BlockDetect = 11018,
        UndefineDeviceID = 11019,
        DoorNotClosed = 11020,  //  DoorNotClosed
        UndefineAction = 11021,
        DebugPressed = 11022,
        SafeGoError = 11023,
        SetModeTimeout = 11024,
        UnLoadFailed = 11025,
        NoFindUUT = 11026,
        PickFailed=11027,
        LoadFailed = 11028,
        BinFailed = 11029
    }
    #endregion
    public class Robot : CoordinatePosition
    {
        public string ip;
        public int camPort;
        public int grippers;
       // private int speed;
        public string dev_type = "SACV6";
        public string os_ver = "RC8";
        public string app_ver = "v1.0.3";
        public string proto_ver = "0.32";
        public string serial_num = "11R036";
        public string state;

      //  public ArrayList robotInputIO;
      //  public ArrayList robotOutputIO;


        #region all IO
        public LightTower lightHouse;
      //  public PointLocation[] locations;
        public Bin inBuffer;
        public Bin processBuffer;
        public Bin ngBuffer;
        //audit buffers
        public Bin audits;

        public Sensor rejectButton;
        public Sensor rejectDrawerClosed;
        public Sensor doorLock;
        public Sensor rejectRight;
        //public Sensor calLocked;
        //public Sensor testLocked;
        //public Sensor arLocked;
        public Sensor estop;
        public Sensor calLock;
        public Sensor testLock;
        public Sensor arLock;
       // public Sensor gripper1Suction;
      //  public Sensor gripper1Blow;
        public Sensor electric;
        public Sensor airPressure;
        
      //  public Sensor gripperUutSensor;
       // public int speed = 20;
        public double vacuumValue;
        public double VacuumValue
        {
            get { return this.vacuumValue; }
            set
            {
                if (vacuumValue < 400)
                {
                    clamp1DUT.Value = true;
                }
                else
                {
                    clamp1DUT.Value = false;
                }

            }
        }
        private int speed = 30;
        public int Speed
        {
            get { return speed; }
            set { this.speed = value; }
        }
        public Sensor outputReady;
        public Sensor goldenButten;
        public Sensor goldenDoorClosed;
        public Sensor clamp1Closed;
        public Sensor clamp1Opened;
        public Sensor clamp1DUT;

        public Sensor clamp2Closed;
        public Sensor clamp2Opened;
        public Sensor clamp2DUT;

        public Sensor goldenDoorLight;
        public Sensor goldenDoorLock;
        public Sensor rejectDrawerLock;
        public Sensor clamp1Close;
        public Sensor clamp1Open;
        public Sensor clamp2Close;
        public Sensor clamp2Open;

        #endregion
        /// <summary>
        /// 初始化Robot数据
        /// </summary>
        /// <param name="ip"></param>
        /// <param name="port"></param>
        public Robot()
        {
            lightHouse = new LightTower();
            Log.WriteLog("init lighthouse success！");
            //从XML文件加载点位
            // LoadDataFromXML();
            //  Log.WriteLog("点位加载成功！");
            //初始化  IO
            goldenDoorLight = new Sensor("goldenDoorLight", false);
            goldenDoorLock = new Sensor("goldenDoorLock", true);    
            rejectDrawerLock = new Sensor("rejectDrawerLock", true); 
            rejectButton = new Sensor("rejectButton", false);
            rejectDrawerClosed = new Sensor("rejectDrawerClosed", false);
            estop = new Sensor("Estop", false);
            electric = new Sensor("electric", true);
            airPressure = new Sensor("airPressure", true);
           // doorLock = new Sensor("doorLock", false);     //change
            rejectRight = new Sensor("rejectLight", false);
            calLock = new Sensor("calLockO", true);
            testLock = new Sensor("testLockO", true);
            arLock = new Sensor("arLock", true);
            clamp1DUT = new Sensor("clamp1DUT", false);
            clamp1Closed = new Sensor("clamp1Closed", false);
            clamp1Opened = new Sensor("clamp1Opened", true);
            clamp1Close = new Sensor("clamp1Close", false);
            clamp1Open = new Sensor("clamp1Open", true);

            clamp2DUT = new Sensor("clamp2DUT", false);
            clamp2Closed = new Sensor("clamp2Closed", false);
            clamp2Opened = new Sensor("clamp2Opened", true);
            clamp2Close = new Sensor("clamp1Close", false);
            clamp2Open = new Sensor("clamp1Open", true);

            outputReady = new Sensor("outputReady",true);
            goldenButten = new Sensor("goldenButten",false);
            goldenDoorClosed = new Sensor("goldenDoorClosed", false); //change
            

            Log.WriteLog("IO init success！");
            state = "Running";
            inBuffer = new Bin(4);
            processBuffer = new Bin(4);
            ngBuffer = new Bin(4);
            audits= new Bin(4);
           // robotInputIO = getInputIO();
         //   robotOutputIO = getOutputIO();
            Log.WriteLog("Buffers load success！");
        }
        
        
        public string home()
        {
            DateTime strTime = DateTime.Now;
            string time = strTime.ToString("MM-dd-yyyy hh:mm:ss");
          
            return time;
        } //HOME
        //public int getSpeed()
        //{
        //    return this.Speed;
        //}
        
        public bool move(double x,double y,double z)
        {
            bool flag=false;
            this.X = x;
            this.Y = y;
            this.Z = z;
            #region move
            /*
            switch (startPosition)
            {
                case "51":
                    fromInput(startPosition, startSlot);
                    switch (destination)
                    {
                        case "101":
                            flag = toCal(endSlot);
                            break;
                        case "21":
                            flag = toInBuffer(endSlot);
                            break;
                        case "11":
                            flag = toNGBuffer(endSlot);
                            break;
                        case "12":
                            flag = toProcessBuffer(endSlot);
                            break;
                    }
                    break;
                case "101":
                    fromCal(startPosition, startSlot);
                    switch (destination)
                    {
                        case "102":
                            flag = toTest(endSlot);
                            break;
                        case "11":
                            flag = toNGBuffer(endSlot);
                            break;
                        case "12":
                            flag = toProcessBuffer(endSlot);
                            break;
                        case "20":
                            flag = toInBuffer(endSlot);
                            break;
                    }
                    break;
                case "21":
                    fromInBuffer(startPosition, startSlot);
                    switch (destination)
                    {
                        case "101":
                            flag = toCal(endSlot);
                            break;
                        case "102":
                            flag = toTest(endSlot);
                            break;
                        case "103":
                            flag = toAr(endSlot);
                            break;
                    }
                    break;
                case "102":
                    fromTest(startPosition, startSlot);
                    switch (destination)
                    {
                        case "103":
                            flag = toAr(endSlot);
                            break;
                        case "11":
                            flag = toNGBuffer(endSlot);
                            break;
                        case "12":
                            flag = toProcessBuffer(endSlot);
                            break;
                        case "21":
                            flag = toInBuffer(endSlot);
                            break;
                    }
                    break;
                case "103":
                    fromAr(startPosition, startSlot);
                    switch (destination)
                    {
                        case "21":
                            flag = toInBuffer(endSlot);
                            break;
                        case "11":
                            flag = toNGBuffer(endSlot);
                            break;
                        case "12":
                            flag = toProcessBuffer(endSlot);
                            break;
                        case "52":
                            flag = true;
                            break;
                    }
                    break;
            }
             */
            #endregion
            return flag;
        }


        public string getInputBitMap()
        {
            string mes = String.Join(",", (int[])getInputIO().ToArray(typeof(int)));
            string str = mes.Replace(",", "");
            string result = string.Format("{0:x}", Convert.ToInt32(str, 2)).ToUpper();
            return result;
        }
        public string getOutputBitMap()
        {
            string mes = String.Join(",", (int[])getOutputIO().ToArray(typeof(int)));
            string str = mes.Replace(",", "");
            string result = string.Format("{0:x}", Convert.ToInt32(str, 2)).ToUpper();
            return result;
        }
        public string getIOBitMap()
        {
            string mes = String.Join(",", (int[])getSensorsStatus(getOutputIO(), getInputIO()).ToArray(typeof(int)));
            string str = mes.Replace(",", "");
            string result = string.Format("{0:x}", Convert.ToInt64(str, 2)).ToUpper();
            return result;
        }
        public ArrayList getInputIO()
        {
            ArrayList robotInputIO = new ArrayList();
            robotInputIO.Add(Convert.ToInt32(outputReady.Value));
            robotInputIO.Add(Convert.ToInt32(estop.Value));
            robotInputIO.Add(Convert.ToInt32(electric.Value));
            robotInputIO.Add(Convert.ToInt32(airPressure.Value));
            robotInputIO.Add(Convert.ToInt32(goldenButten.Value));
            robotInputIO.Add(Convert.ToInt32(goldenDoorClosed.Value));
            robotInputIO.Add(Convert.ToInt32(rejectButton.Value));
            robotInputIO.Add(Convert.ToInt32(rejectDrawerClosed.Value));
            //gripper
            robotInputIO.Add(0);
            robotInputIO.Add(0);
            //gripper2
            robotInputIO.Add(Convert.ToInt32(clamp2DUT.Value));
            robotInputIO.Add(Convert.ToInt32(clamp2Opened.Value));
            robotInputIO.Add(Convert.ToInt32(clamp2Closed.Value));

            //gripper1
            robotInputIO.Add(Convert.ToInt32(clamp1DUT.Value));
            robotInputIO.Add(Convert.ToInt32(clamp1Opened.Value));
            robotInputIO.Add(Convert.ToInt32(clamp1Closed.Value));
            
            for (int i = 3; i >= 0; i--)
            {
                robotInputIO.Add(Convert.ToInt32(ngBuffer.buffer[i].Value));
            }
            for (int i = 3; i >= 0; i--)
            {
                robotInputIO.Add(Convert.ToInt32(processBuffer.buffer[i].Value));
            }
            // audit buffer
            for (int i = 3; i >= 0; i--)
            {
                robotInputIO.Add(Convert.ToInt32(audits.buffer[i].Value));
            }
            // inbuffer 4 ,3
            robotInputIO.Add(0);
            robotInputIO.Add(0);
            // inbuffer 2,  1
            for (int i =1; i >= 0; i--)  
            {
                robotInputIO.Add(Convert.ToInt32(inBuffer.buffer[i].Value));
            }
            return robotInputIO;
        }
        public ArrayList getOutputIO()
        {
            ArrayList robotOutputIO = new ArrayList();
           
            robotOutputIO.Add(Convert.ToInt32(goldenDoorLight.Value));
            robotOutputIO.Add(Convert.ToInt32(goldenDoorLock.Value));
            robotOutputIO.Add(Convert.ToInt32(rejectDrawerLock.Value));
            robotOutputIO.Add(0);
            robotOutputIO.Add(0);
            robotOutputIO.Add(Convert.ToInt32(clamp2Open.Value));
            robotOutputIO.Add(Convert.ToInt32(clamp2Close.Value));
            robotOutputIO.Add(Convert.ToInt32(clamp1Open.Value));
            robotOutputIO.Add(Convert.ToInt32(clamp1Close.Value));
            robotOutputIO.Add(0);
            robotOutputIO.Add(0);
            robotOutputIO.Add(0);
            robotOutputIO.Add(0);
            robotOutputIO.Add(0);
            robotOutputIO.Add(0);
            robotOutputIO.Add(0);
            robotOutputIO.Add(0);
            robotOutputIO.Add(Convert.ToInt32(lightHouse.Buzzer));
            robotOutputIO.Add(Convert.ToInt32(lightHouse.Green));
            robotOutputIO.Add(Convert.ToInt32(lightHouse.Yellow));
            robotOutputIO.Add(Convert.ToInt32(lightHouse.Red));
            return robotOutputIO;
        }
        public ArrayList getSensorsStatus(ArrayList robotOutputIO, ArrayList robotInputIO)
        {
            robotInputIO.AddRange(robotOutputIO);
            return robotInputIO;
        }
        public void sleepTime(int time)
        {
            if (Speed == 100)
            {
                Thread.Sleep(0);
            }
            else
            {
                Thread.Sleep((time * 100000) / Speed);
            }
            
        }
    }
}
