﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using Pegatron.Foundation;

namespace Pegatron.Communication.Socket
{
    public class SocketByteSendParam : CommSendParam
    {
        public IPEndPoint RemoteEndPoint
        {
            get;
            set;
        }

        public byte[] Data
        {
            get;
            set;
        }

        public SocketByteSendParam(byte[] data, IPEndPoint remoteEndPoint = null)
        {
            this.Data = data;
            this.RemoteEndPoint = remoteEndPoint;
        }
    }

    public class SocketStringSendParam : CommSendParam
    {
        public IPEndPoint RemoteEndPoint
        {
            get;
            set;
        }

        public string Message
        {
            get;
            set;
        }

        public string Terminator
        {
            get;
            set;
        }

        public SocketStringSendParam(string message, string terminator = null, IPEndPoint remoteEndPoint = null)
        {
            this.Message = message;
            this.Terminator = terminator;
            this.RemoteEndPoint = remoteEndPoint;
        }
    }
}
