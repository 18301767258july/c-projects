﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using Pegatron.Foundation;

namespace Pegatron.Communication.Socket
{
    public class SocketRecvResult : CommResult
    {
        public IPEndPoint RemoteEndPoint
        {
            get;
            set;
        }

        public byte[] Data
        {
            get;
            set;
        }

        public int Bytes
        {
            get;
            set;
        }

        public SocketRecvResult(bool result = false, object error = null, IPEndPoint remote = null, byte[] data = null, int bytes = 0)
            : base(result, error)
        {
            this.RemoteEndPoint = remote;
            this.Data = data;
            this.Bytes = bytes;
        }
    }
}
