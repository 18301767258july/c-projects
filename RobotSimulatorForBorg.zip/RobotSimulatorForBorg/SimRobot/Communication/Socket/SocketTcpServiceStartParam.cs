﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Pegatron.Foundation;

namespace Pegatron.Communication.Socket
{
    public class SocketTcpServiceStartParam : CommServiceStartParam
    {
        public const int DefaultServiceDelayMilliseconds = 0;//ms
        public const int DefaultWaitAcceptMilliSeconds = 2000;//ms

        public string BindingIP
        {
            get;
            set;
        }

        public int BindingPort
        {
            get;
            set;
        }

        public int DelayMilliseconds
        {
            get;
            set;
        }

        public bool IsBackground
        {
            get;
            set;
        }

        public int WaitAcceptMilliSeconds
        {
            get;
            set;
        }

        public SocketTcpServiceStartParam(
            string ip, 
            int port, 
            bool isBackground = false,
            int delayMilliseconds = SocketTcpServiceStartParam.DefaultServiceDelayMilliseconds, 
            int waitAcceptMilliSeconds = SocketTcpServiceStartParam.DefaultWaitAcceptMilliSeconds
            )
        {
            this.BindingIP = ip;
            this.BindingPort = port;
            this.IsBackground = isBackground;
            this.DelayMilliseconds = delayMilliseconds;
            this.WaitAcceptMilliSeconds = waitAcceptMilliSeconds;
        }
    }
}
