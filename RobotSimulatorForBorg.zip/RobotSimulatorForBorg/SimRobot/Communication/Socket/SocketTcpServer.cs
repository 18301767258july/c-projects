﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Pegatron.Foundation;

namespace Pegatron.Communication.Socket
{
    public class SocketTcpServer : IServiceDevice
    {
        public const string SocketTcpServerStartBadParamError       = "socket tcp server start bad parameter error";
        public const string SocketTcpServerStillRunningError        = "socket tcp server still running error";
        public const string SocketTcpServerRequestServiceStartError = "socket tcp server request service start error";
        public const string SocketTcpServerRequestInterruptError    = "socket tcp server request interrupt error";
        public const string SocketTcpServerRequestTimeoutError      = "socket tcp server request timeout error";

        public event CommConnectionReceivedCallback TcpConnectionReceived;

        protected LoopProcessor mClientRequestProcessor = new LoopProcessor();

        protected ManualResetEventSlim mClientRequestInterruptEvent = new ManualResetEventSlim(false);

        protected IAsyncResult mAsyncAcceptResult = null;

        public bool ServiceRunning 
        {
            get
            {
                return this.mClientRequestProcessor.Running || this.SystemListener != null;
            }
        }

        public int WaitAcceptMilliSeconds
        {
            get;
            protected set;
        }

        protected TcpListener SystemListener
        {
            get;
            set;
        }

        public EndPoint BindingEndPoint
        {
            get
            {
                EndPoint result = null;
                try
                {
                    if (this.SystemListener != null)
                    {
                        result = this.SystemListener.LocalEndpoint;
                    }
                }
                catch
                {
                    result = null;
                }
                return result;
            }
        }

        public string BindingIP
        {
            get
            {
                return Network.GetIPByEndPoint(this.BindingEndPoint);
            }
        }

        public int BindingPort
        {
            get
            {
                return Network.GetPortByEndPoint(this.BindingEndPoint); ;
            }
        }

        public SocketTcpServer()
        {
            this.mClientRequestProcessor.LoopHandler = this.ListenPort;
        }

        public CommResult StartService(
            CommServiceStartParam param,
            CommConnectionReceivedCallback connectionCallback
            )
        {
            CommResult result = new CommResult(false);
            object error = null;
            try
            {
                if (param is SocketTcpServiceStartParam)
                {
                    SocketTcpServiceStartParam tcpServiceStartParam = param as SocketTcpServiceStartParam;
                    result.Result = this.StartService(
                                    tcpServiceStartParam.BindingIP,
                                    tcpServiceStartParam.BindingPort,
                                    tcpServiceStartParam.IsBackground,
                                    tcpServiceStartParam.DelayMilliseconds,
                                    tcpServiceStartParam.WaitAcceptMilliSeconds,
                                    connectionCallback,
                                    ref error
                                    );
                }
                else
                {
                    error = SocketTcpServer.SocketTcpServerStartBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public bool StartService(
            string bindingIP,
            int bindingPort,
            bool isBackground,
            CommConnectionReceivedCallback connectionCallback,
            ref object error
            )
        {
            return this.StartService(
                        new IPEndPoint(IPAddress.Parse(bindingIP), bindingPort),
                        isBackground,
                        SocketTcpServiceStartParam.DefaultServiceDelayMilliseconds,
                        SocketTcpServiceStartParam.DefaultWaitAcceptMilliSeconds,
                        connectionCallback,
                        ref error
                        );
        }

        public bool StartService(
            string bindingIP,
            int bindingPort,
            bool isBackground,
            int delayMilliseconds,
            int waitAcceptMilliSeconds,
            CommConnectionReceivedCallback connectionCallback,
            ref object error
            )
        {
            return this.StartService(
                new IPEndPoint(IPAddress.Parse(bindingIP), bindingPort),
                isBackground,
                delayMilliseconds,
                waitAcceptMilliSeconds,
                connectionCallback,
                ref error
                );
        }

        public bool StartService(
            IPEndPoint bindingEndPoint,
            bool isBackground,
            int delayMilliseconds,
            int waitAcceptMilliSeconds,
            CommConnectionReceivedCallback connectionCallback,
            ref object error
            )
        {
            bool result = false;
            if (bindingEndPoint != null)
            {
                try
                {
                    this.StopService();
                    if (!this.ServiceRunning)
                    {
                        this.SystemListener = new TcpListener(bindingEndPoint);
                        if (this.SystemListener != null)
                        {
                            this.SystemListener.Start();
                            this.WaitAcceptMilliSeconds = waitAcceptMilliSeconds;
                            this.mClientRequestProcessor.LoopSleepMilliseconds = delayMilliseconds;
                            this.mClientRequestProcessor.IsBackground = isBackground;
                            if (connectionCallback != null)
                            {
                                this.TcpConnectionReceived = connectionCallback;
                            }
                            this.mClientRequestInterruptEvent.Reset();
                            if (!(result = mClientRequestProcessor.AsyncExec()))
                            {
                                error = SocketTcpServer.SocketTcpServerRequestServiceStartError;
                            }
                        }
                    }
                    else
                    {
                        error = SocketTcpServer.SocketTcpServerStillRunningError;
                    }
                }
                catch (System.Exception ex)
                {
                    result = false;
                    error = ex;
                }
                finally
                {
                    if (!result)
                    {
                        this.StopService();
                    }
                }
            }
            return result;
        }

        public void StopService()
        {
            try
            {
                this.mClientRequestInterruptEvent.Set();
                this.mClientRequestProcessor.StopExec();
                if (this.SystemListener != null)
                {
                    this.SystemListener.Stop();
                    this.SystemListener = null;
                }
                this.mAsyncAcceptResult = null;
                this.mClientRequestInterruptEvent.Reset();
            }
            catch (System.Exception)
            {
            }
        }

        private SocketTcpClient GetConnectedDevice(int timeoutMilliseconds, ref object error)
        {
            SocketTcpClient result = null;
            try
            {
                TcpClient tcpClient = null;
                if (this.mAsyncAcceptResult == null /*|| this.mAsyncAcceptResult.IsCompleted*/)
                {
                    this.mAsyncAcceptResult = this.SystemListener.BeginAcceptTcpClient(null, null);
                }

                if (this.mAsyncAcceptResult != null)
                {
                    int waitReturn = WaitHandle.WaitAny(new WaitHandle[] { this.mAsyncAcceptResult.AsyncWaitHandle, this.mClientRequestInterruptEvent.WaitHandle }, timeoutMilliseconds);
                    if (waitReturn == 0)
                    {
                        tcpClient = this.SystemListener.EndAcceptTcpClient(mAsyncAcceptResult);
                        this.mAsyncAcceptResult = null;
                    }
                    else if (waitReturn == 1)
                    {
                        error = SocketTcpServer.SocketTcpServerRequestInterruptError;
                    }
                    else
                    {
                        error = SocketTcpServer.SocketTcpServerRequestTimeoutError;
                    }
                }

                if (tcpClient != null)
                {
                    result = new SocketTcpClient(tcpClient);
                }
            }
            catch (System.Exception ex)
            {
                result = null;
                error = ex;
            }

            return result;
        }

        private bool ListenPort(object arg)
        {
            bool result = true;
            try
            {
                object error = null;
                SocketTcpClient client = this.GetConnectedDevice(this.WaitAcceptMilliSeconds, ref error);
                if (client != null)
                {
                    if (this.TcpConnectionReceived != null)
                    {
                        this.TcpConnectionReceived.Invoke(this, new SocketTcpConnectionReceivedEventArgs(client, this));
                    }
                }
            }
            catch (System.Exception)
            {
            }
            finally
            {
                if (this.mClientRequestInterruptEvent.IsSet)
                {
                    result = false;
                }
            }
            return result;
        }
    }
}
