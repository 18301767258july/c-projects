﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Pegatron.Foundation;

namespace Pegatron.Communication.Socket
{
    public class SocketTcpConnectionReceivedEventArgs : CommConnectionReceivedEventArgs
    {
        public SocketTcpConnectionReceivedEventArgs(SocketTcpClient client, SocketTcpServer server)
            : this(client, server, TimeCounter.Now, true)
        {
        }

        public SocketTcpConnectionReceivedEventArgs(SocketTcpClient client, SocketTcpServer server, DateTime time, bool connected)
            : base(client, server, time, connected)
        {
            this.Client = client;
            this.Server = server;
            this.Time = time;
            this.Connected = connected;
        }
    }
}
