﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using Pegatron.Foundation;
using Pegatron.Communication;

namespace Pegatron.Communication.Socket
{
    public class SocketUdpClient : IConnectedDevice, ICommunication, ICommAsyncRecv
    {
        public const string SocketUdpConnectionBadParamError      = "socket udp connection bad parameter error";
        public const string SocketUdpConnectionWaitTimeoutError   = "socket udp connection wait timeout error";
        public const string SocketUdpConnectionFailed             = "socket udp connection failed";
        public const string SocketUdpSendBadParamError            = "socket udp send bad parameter error";
        public const string SocketUdpRecvBadParamError            = "socket udp recv bad parameter error";
        public const string SocketUdpRecvWaitTimeoutError         = "socket udp recv wait timeout error";
        public const string SocketUdpRecvInterruptError           = "socket udp recv interrupt error";
        public const string SocketUdpRecvAsyncStartError          = "socket udp recv async start error";
        public const string SocketUdpRecvAsyncBadParamError       = "socket udp recv async bad parameter error";
        public const string SocketUdpRecvAsyncStillRunningError   = "socket udp recv async still running error";
        public const string SocketUdpRecvNoDataError              = "socket udp recv no data error";

        protected LoopProcessor mAsyncRecvProcessor = new LoopProcessor();

        protected ManualResetEventSlim mAsyncRecvInterruptEvent = new ManualResetEventSlim(false);

        protected IAsyncResult mAsyncRecvResult = null;

        protected byte[] mRecvBuffer = null;

        public bool Connected
        {
            get
            {
                return this.SystemSocketClient != null && this.SystemSocketClient.Client != null && this.SystemSocketClient.Client.Connected;
            }
        }

        public SocketAsyncRecvParam SocketAsyncRecvParam
        {
            get;
            protected set;
        }

        public CommDataReceivedCallback AsyncReceivedCallback
        {
            get;
            set;
        }

        public bool AsyncReceiving
        {
            get
            {
                return this.mAsyncRecvProcessor.Running;
            }
        }

        protected UdpClient SystemSocketClient
        {
            get;
            set;
        }

        public IPEndPoint BindingEndPoint
        {
            get;
            protected set;
        }

        public bool EnableBroadcast
        {
            get;
            protected set;
        }

        public EndPoint LocalEndPoint
        {
            get
            {
                EndPoint result = null;
                try
                {
                    if (this.SystemSocketClient != null && this.SystemSocketClient.Client != null)
                    {
                        result = this.SystemSocketClient.Client.LocalEndPoint;
                    }
                }
                catch
                {
                    result = null;
                }
                return result;
            }
        }

        public string LocalIP
        {
            get
            {
                return Network.GetIPByEndPoint(this.LocalEndPoint);
            }
        }

        public int LocalPort
        {
            get
            {
                return Network.GetPortByEndPoint(this.LocalEndPoint); ;
            }
        }

        #region constructor

        public SocketUdpClient()
            : this(0, false)
        {
        }

        public SocketUdpClient(int bindingPort, bool enableBroadcast)
            : this(new IPEndPoint(IPAddress.Any, bindingPort), enableBroadcast)
        {
        }

        public SocketUdpClient(IPEndPoint bindingEP, bool enableBroadcast)
            : this(new UdpClient(bindingEP), enableBroadcast)
        {
        }

        public SocketUdpClient(UdpClient systemClient, bool enableBroadcast)
        {
            this.SystemSocketClient = systemClient;
            if (this.SystemSocketClient != null)
            {
                this.SystemSocketClient.EnableBroadcast = enableBroadcast;
            }
            this.EnableBroadcast = enableBroadcast;
            this.mAsyncRecvProcessor.LoopHandler = this.AsyncRecv;
        }
        #endregion

        #region function
        public CommResult Connect(CommConnectionParam param)
        {
            CommResult result = new CommResult(false);
            object error = null;
            try
            {
                if (param is SocketConnectionParam)
                {
                    SocketConnectionParam udpClientConnectionParam = param as SocketConnectionParam;
                    result.Result = this.Connect(
                                  udpClientConnectionParam.RemoteIP,
                                  udpClientConnectionParam.RemotePort,
                                  udpClientConnectionParam.TimeoutMilliseconds,
                                  ref error
                                  );
                }
                else
                {
                    error = SocketUdpClient.SocketUdpConnectionBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public bool Connect(string remoteIP, int remotePort, int timeoutMilliseconds, ref object error)
        {
            return this.Connect(new IPEndPoint(IPAddress.Parse(remoteIP), remotePort), timeoutMilliseconds, ref error);
        }

        public bool Connect(IPEndPoint remoteEndPoint, int timeoutMilliseconds, ref object error)
        {
            bool result = false;
            try
            {
                this.Disconnect();
                if (remoteEndPoint != null)
                {
                    if (this.SystemSocketClient == null || this.SystemSocketClient.Client == null)
                    {
                        if (this.BindingEndPoint != null)
                        {
                            this.SystemSocketClient = new UdpClient(this.BindingEndPoint);
                        }
                        else
                        {
                            this.SystemSocketClient = new UdpClient();
                        }
                        this.SystemSocketClient.EnableBroadcast = this.EnableBroadcast;
                    }
                    if (this.SystemSocketClient != null && !this.Connected)
                    {
                        IAsyncResult asyncResult = this.SystemSocketClient.Client.BeginConnect(remoteEndPoint.Address, remoteEndPoint.Port, null, null);
                        if (asyncResult != null)
                        {
                            if (asyncResult.AsyncWaitHandle.WaitOne(timeoutMilliseconds))
                            {
                                this.SystemSocketClient.Client.EndConnect(asyncResult);
                                result = true;
                            }
                            else
                            {
                                error = SocketUdpClient.SocketUdpConnectionWaitTimeoutError;
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                result = false;
                error = ex;
            }
            finally
            {
                if (!result)
                {
                    this.Disconnect();
                }
            }
            return result;
        }

        public void Disconnect()
        {
            try
            {
                this.EndAsyncRecv();
                if (this.SystemSocketClient != null)
                {
                    this.SystemSocketClient.Close();
                    this.SystemSocketClient = null;
                }
            }
            catch (System.Exception)
            {
            }
        }

        public CommResult Send(CommSendParam param)
        {
            SocketSendResult result = new SocketSendResult(false);
            object error = null;
            try
            {
                if (param is SocketStringSendParam)
                {
                    SocketStringSendParam udpClientSendParam = param as SocketStringSendParam;
                    result.Result = this.Send(udpClientSendParam.Message, udpClientSendParam.Terminator, udpClientSendParam.RemoteEndPoint, ref error);
                }
                else if (param is SocketByteSendParam)
                {
                    SocketByteSendParam udpClientSendParam = param as SocketByteSendParam;
                    result.Result = this.Send(udpClientSendParam.Data, udpClientSendParam.RemoteEndPoint, ref error);
                }
                else
                {
                    error = SocketUdpClient.SocketUdpSendBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public bool Send(string message, string terminator, int remotePort, string remoteIP, ref object error)
        {
            return this.Send(message, terminator, Encoding.ASCII, new IPEndPoint((string.IsNullOrEmpty(remoteIP) ? IPAddress.Broadcast : IPAddress.Parse(remoteIP)), remotePort), ref error);
        }

        public bool Send(string message, string terminator, IPEndPoint remoteEndPoint, ref object error)
        {
            return this.Send(message, terminator, Encoding.ASCII, remoteEndPoint, ref error);
        }

        public bool Send(string message, string terminator, Encoding encoding, IPEndPoint remoteEndPoint, ref object error)
        {
            bool result = false;
            if (encoding != null)
            {
                string fullMessage = message + (string.IsNullOrEmpty(terminator) ? string.Empty : terminator);
                result = this.Send(encoding.GetBytes(fullMessage), remoteEndPoint, ref error);
            }
            return result;
        }

        public bool Send(byte[] data, IPEndPoint remoteEndPoint, ref object error)
        {
            bool result = false;
            try
            {
                if (data != null && remoteEndPoint != null)
                {
                    try
                    {
                        result = (this.SystemSocketClient.Send(data, data.Length, remoteEndPoint) == data.Length);
                    }
                    catch (System.Exception ex)
                    {
                        result = false;
                        error = ex;
                    }
                }
                else
                {
                    error = SocketUdpClient.SocketUdpSendBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result = false;
                error = ex;
            }
            finally
            {
            }
            return result;
        }

        public CommResult Recv(CommRecvParam param)
        {
            SocketRecvResult result = new SocketRecvResult(false);
            object error = null;
            try
            {
                if (param is SocketRecvParam)
                {
                    byte[] data = null;
                    int bytes = 0;
                    IPEndPoint remoteEndPoint = null;
                    SocketRecvParam udpClientRecvParam = param as SocketRecvParam;
                    result.Result = this.Recv(ref data, ref bytes, ref remoteEndPoint, udpClientRecvParam.TimeoutMilliseconds, ref error);
                    result.Data = data;
                    result.Bytes = bytes;
                    result.RemoteEndPoint = remoteEndPoint;
                }
                else
                {
                    error = SocketUdpClient.SocketUdpRecvBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public bool Recv(ref string data, ref IPEndPoint remoteEndPoint, int timeoutMilliseconds, ref object error)
        {
            return this.Recv(ref data, Encoding.ASCII, ref remoteEndPoint, timeoutMilliseconds, ref error);
        }

        public bool Recv(ref string data, Encoding encoding, ref IPEndPoint remoteEndPoint, int timeoutMilliseconds, ref object error)
        {
            bool result = false;
            if (encoding != null)
            {
                byte[] byteData = null;
                int bytes = 0;
                if ((result = this.Recv(ref byteData, ref bytes, ref remoteEndPoint, timeoutMilliseconds, ref error)))
                {
                    if (bytes > 0)
                    {
                        data = encoding.GetString(byteData, 0, bytes);
                    }
                }
            }
            return result;
        }

        public bool Recv(ref byte[] data, ref int bytes, ref IPEndPoint remoteEndPoint, int timeoutMilliseconds, ref object error)
        {
            bool result = false;
            try
            {
                if (this.mAsyncRecvResult == null /*|| this.mAsyncRecvResult.IsCompleted*/)
                {
                    this.mAsyncRecvResult = this.SystemSocketClient.BeginReceive(null, null);
                }
                if (this.mAsyncRecvResult != null)
                {
                    int waitReturn = WaitHandle.WaitAny(new WaitHandle[] { this.mAsyncRecvResult.AsyncWaitHandle, this.mAsyncRecvInterruptEvent.WaitHandle }, timeoutMilliseconds);
                    if (waitReturn == 0)
                    {
                        data = this.SystemSocketClient.EndReceive(this.mAsyncRecvResult, ref remoteEndPoint);
                        if (data != null)
                        {
                            bytes = data.Length;
                            result = true;
                        }
                        else
                        {
                            error = SocketUdpClient.SocketUdpRecvNoDataError;
                        }
                        this.mAsyncRecvResult = null;
                    }
                    else if (waitReturn == 1)
                    {
                        error = SocketUdpClient.SocketUdpRecvInterruptError;
                    }
                    else
                    {
                        error = SocketUdpClient.SocketUdpRecvWaitTimeoutError;
                    }
                }
                else
                {
                    error = SocketUdpClient.SocketUdpRecvAsyncStartError;
                }
            }
            catch (System.Exception ex)
            {
                result = false;
                error = ex;
            }
            finally
            {
            }
            return result;
        }

        public CommResult BeginAsyncRecv(CommRecvParam param, CommDataReceivedCallback asyncReceivedCallback)
        {
            CommResult result = new CommResult(false);
            object error = null;
            try
            {
                if (!this.AsyncReceiving)
                {
                    if (param is SocketAsyncRecvParam)
                    {
                        this.SocketAsyncRecvParam = param as SocketAsyncRecvParam;
                        this.mAsyncRecvProcessor.LoopSleepMilliseconds = this.SocketAsyncRecvParam.AsyncDelayMilliseconds;
                        this.mAsyncRecvProcessor.IsBackground = this.SocketAsyncRecvParam.IsBackground;
                        this.AsyncReceivedCallback = asyncReceivedCallback;
                        this.mAsyncRecvInterruptEvent.Reset();
                        result.Result = this.mAsyncRecvProcessor.AsyncExec();
                    }
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public void EndAsyncRecv()
        {
            this.mAsyncRecvInterruptEvent.Set();
            this.mAsyncRecvProcessor.StopExec();
            this.mAsyncRecvInterruptEvent.Reset();
        }

        private bool AsyncRecv(object arg)
        {
            bool result = true;
            try
            {
                byte[] data = null;
                int bytes = 0;
                object error = null;
                IPEndPoint remoteEndPoint = null;
                if (this.Recv(ref data, ref bytes, ref remoteEndPoint, this.SocketAsyncRecvParam.TimeoutMilliseconds, ref error))
                {
                    if (this.AsyncReceivedCallback != null)
                    {
                        this.AsyncReceivedCallback.Invoke(this, new SocketDataReceivedEventArgs(data, bytes, remoteEndPoint, this.LocalEndPoint));
                    }
                }
                else
                {
                    if (error as string == SocketUdpClient.SocketUdpRecvNoDataError)
                    {
                        Thread.Sleep(this.SocketAsyncRecvParam.NoDataDelayMilliseconds);
                    }
                }
            }
            catch (System.Exception ex)
            {
                ATSException.Logging(ex);
            }
            finally
            {
                if (this.mAsyncRecvInterruptEvent.IsSet)
                {
                    result = false;
                }
            }
            return result;
        }

        #endregion       
    }
}
