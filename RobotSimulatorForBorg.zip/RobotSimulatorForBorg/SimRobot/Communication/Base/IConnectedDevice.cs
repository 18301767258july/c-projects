﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Communication
{
    public class CommConnectionParam
    {
    }

    public interface IConnectedDevice
    {
        bool Connected
        {
            get;
        }

        CommResult Connect(CommConnectionParam param);
        
        void Disconnect();
    }
}
