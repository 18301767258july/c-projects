﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Communication
{
    public class CommServiceStatusChangedEventArgs : EventArgs
    {
        public IServiceDevice Device
        {
            get;
            set;
        }

        public bool Running
        {
            get;
            set;
        }

        public DateTime Time
        {
            get;
            set;
        }

        public CommServiceStatusChangedEventArgs(IServiceDevice device, bool running, DateTime time)
        {
            this.Device = device;
            this.Running = running;
            this.Time = time;
        }
    }
}
