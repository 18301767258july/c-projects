﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Communication
{
    public class CommResult
    {
        public bool Result
        {
            get;
            set;
        }

        public object Error
        {
            get;
            set;
        }

        public CommResult(bool result = false, object error = null)
        {
            this.Result = result;
            this.Error = error;
        }
    }

    public class CommSendParam
    {
    }

    public class CommRecvParam
    {
    }

    public interface ICommSend
    {
        CommResult Send(CommSendParam param);
    }

    public interface ICommRecv
    {
        CommResult Recv(CommRecvParam param);
    }

    public interface ICommunication : ICommSend, ICommRecv
    {
    }
}
