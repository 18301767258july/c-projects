using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace Pegatron.Foundation
{
    /// <summary>
    /// IniFileAccess class to access .ini format file
    /// </summary>
    public class IniAccessor
    {
        #region dll import
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string defVal, StringBuilder retVal, int size, string filePath);
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        #endregion

        #region fields
        public const int DefaultIniValueCapacity = 255;
        #endregion

        #region Constructor
        /// <summary>
        /// IniFileAccess class constructor
        /// </summary>
        /// <param name="iniFilePath">.ini format file path</param>
        /// <param name="capacity">string capacity to handle</param>
        public IniAccessor(string iniFilePath, int capacity = IniAccessor.DefaultIniValueCapacity)
        {
            this.IniFilePath = iniFilePath;
            this.IniValueCapacity = capacity;
        }
        public IniAccessor()
            : this(null, IniAccessor.DefaultIniValueCapacity)
        {
        }
        #endregion

        #region property
        public string IniFilePath
        {
            get;
            protected set;
        }

        public int IniValueCapacity
        {
            get;
            protected set;
        }
        #endregion

        #region functions
        /// <summary>
        /// Check if ini file pointed by member mIniFilePath exists
        /// </summary>
        /// <returns>exist or not</returns>
        public bool IsIniExist()
        {
            return this.IniFilePath != null && System.IO.File.Exists(this.IniFilePath);
        }

        /// <summary>
        /// set value by key in section
        /// </summary>
        /// <param name="section">section name in ini file</param>
        /// <param name="key">key to be accessed</param>
        /// <param name="value">value to be assigned</param>
        public void SetValue(string section, string key, string value)
        {
            if (this.IsIniExist() && section != null && key != null && value != null)
            {
                WritePrivateProfileString(section, key, value, this.IniFilePath);
            }
        }

        /// <summary>
        /// get value by key in section
        /// </summary>
        /// <param name="section">section name in ini file</param>
        /// <param name="key">key to be accessed</param>
        /// <returns>value for the key</returns>
        public string GetValue(string section, string key)
        {
            string result = null;
            if (this.IsIniExist() && section != null && key != null)
            {
                StringBuilder temp = new StringBuilder(this.IniValueCapacity);
                GetPrivateProfileString(section, key, string.Empty, temp, this.IniValueCapacity, this.IniFilePath);
                result = temp.ToString();
            }
            return result;
        }
        #endregion
    }
}
