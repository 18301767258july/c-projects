﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace Pegatron.Foundation
{
    /// <summary>
    /// CSV文件转换类
    /// </summary>
    public class CSVConvert
    {
        #region  CSVDataTableConvert
        /// <summary>
        /// 导出报表为Csv
        /// </summary>
        /// <param name="dt">DataTable</param>
        /// <param name="strFilePath">物理路径</param>
        /// <param name="tableheader">表头</param>
        /// <param name="columname">字段标题,逗号分隔</param>
        public static bool DataTable2CSV(DataTable dataTable, string strFilePath, string columName)
        {
            try
            {
                string strBufferLine = string.Empty;
                StreamWriter strmWriterObj = new StreamWriter(strFilePath, false, System.Text.Encoding.UTF8);
                strmWriterObj.WriteLine(columName);
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    strBufferLine = string.Empty;
                    for (int j = 0; j < dataTable.Columns.Count-1; j++)
                    {
                        if (j > 0)
                            strBufferLine += ",";
                        strBufferLine += dataTable.Rows[i][j].ToString();
                    }
                    strmWriterObj.WriteLine(strBufferLine);
                }
                strmWriterObj.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 将Csv读入DataTable
        /// </summary>
        /// <param name="filePath">csv文件路径</param>
        /// <param name="startRow">表示第startRow行是字段title,第startRow+1行是记录开始</param>
        public static DataTable CSV2DataTable(string filePath, DataTable dataTable,int startRow)
        {
            StreamReader reader = new StreamReader(filePath, System.Text.Encoding.UTF8, false);
            int m = 0;
           // reader.Peek();
            while (reader.Peek() > 0)
            {
                m = m + 1;
                string str = reader.ReadLine();
                if (m >= startRow + 1)
                {
                    string[] split = str.Split(',');

                    System.Data.DataRow dataRow = dataTable.NewRow();
                    for (int i = 0; i < split.Length; i++)
                    {
                        dataRow[i] = split;
                    }
                    dataTable.Rows.Add(dataRow);
                }
            }
            return dataTable;
        }
        #endregion

        #region CSVDataGridViewConvert
        private void DataGridView2CSV(DataGridView dataGridView)
        {
            string delimiter = ",";
            string fullFileName = string.Empty;
            StreamWriter csvStreamWriter = StreamWriter.Null;
            FolderBrowserDialog sfp = new FolderBrowserDialog();
            sfp.Description = " Please choose a path to save file.";
            sfp.ShowNewFolderButton = true;
            if (sfp.ShowDialog() == DialogResult.OK)
            {
                fullFileName = sfp.SelectedPath.ToString() + "\\" + TimeCounter.Now.ToString("yyyyMMddhhmmss") + ".csv";
            }
            else
            {
                return;
            }
            csvStreamWriter = new StreamWriter(fullFileName, true, System.Text.Encoding.UTF8);
            if (File.Exists(fullFileName))
            {
                csvStreamWriter.Close();
                csvStreamWriter = new StreamWriter(fullFileName, false, System.Text.Encoding.UTF8);
            }
            //output header data 
            string header = string.Empty;
            for (int i = 0; i < dataGridView.Columns.Count; i++)
            {
                header += dataGridView.Columns[i].HeaderText.Trim() + delimiter.Trim();
            }
            csvStreamWriter.WriteLine(header.Trim().Substring(0, header.Length - 1));

            //output rows data 
            for (int j = 0; j < dataGridView.Rows.Count; j++)
            {
                string rowValue = string.Empty;

                for (int a = 0; a < dataGridView.Columns.Count; a++)
                {
                    rowValue += dataGridView.Rows[j].Cells[a].Value + delimiter;
                }
                csvStreamWriter.WriteLine(rowValue.Substring(0, rowValue.Length - 1));
            }
            csvStreamWriter.Close();
        }

        /// <summary>
        /// 将Csv读入DataGridView
        /// </summary>
        /// <param name="filePath">csv文件路径</param>
        /// <param name="startRow">表示第startRow行是字段title,第startRow+1行是记录开始,默认第一行开始</param>
        public static void CSV2DataGridView(string filePath,DataGridView dataGridView,int startRow)
        {
            dataGridView.Rows.Clear();
            StreamReader streamReader = new StreamReader(filePath, System.Text.Encoding.Default, false);
            int m = 0;
            //reader.Peek();
            while (streamReader.Peek() > 0)
            {
                m = m + 1;
                string str = streamReader.ReadLine();
                if (m >= startRow + 1 && str != ",")
                {
                    str = str + ",Del";
                    string[] split = str.Split(',');
                    dataGridView.Rows.Add(split);
                }
            }
            streamReader.Close();
            streamReader.Dispose();
        }
        #endregion

        #region DataGridView2DataTable
        public static DataTable DataGridView2DataTable(DataGridView dataGridView)
        {
            DataTable dataTable = new DataTable();
            DataColumn dataColumn;
            for (int i = 0; i < dataGridView.Columns.Count; i++)
            {
                dataColumn = new DataColumn();
                dataColumn.ColumnName = dataGridView.Columns[i].HeaderText.ToString();
                dataTable.Columns.Add(dataColumn);
            }
            for (int j = 0; j < dataGridView.Rows.Count; j++)
            {
                DataRow dataRow = dataTable.NewRow();
                for (int x = 0; x < dataGridView.Columns.Count; x++)
                {
                    dataRow[x] = dataGridView.Rows[j].Cells[x].Value;
                }
                dataTable.Rows.Add(dataRow);
            }
            return dataTable;
        }
        #endregion
    }
}
