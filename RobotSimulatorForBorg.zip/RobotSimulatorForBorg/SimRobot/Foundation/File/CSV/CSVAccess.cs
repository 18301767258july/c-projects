﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO; 
using System.Data;
using System.Text.RegularExpressions; 
using System.Windows.Forms;
using System.Collections;

namespace Pegatron.Foundation
{
    public class CSVAccess
    {
        public const string RowSeparater = ",";

        #region Row
        public static string CreateRow(params object[] fieldArray)
        {
            string result = string.Empty;
            if (fieldArray != null && fieldArray.Length > 0)
            {
                foreach (object field in fieldArray)
                {
                    string fieldString = (field != null ? field.ToString() : null);
                    string temp = (fieldString != null ? fieldString : string.Empty);
                    result = (string.IsNullOrEmpty(result) ? temp : (result + CSVAccess.RowSeparater + temp));
                }
            }
            return result;
        }
        #endregion

        #region Write CSV
        //write a file, existed file will be overwritten if append = false 
        public static void WriteCSV(string filePathName, List<String[]> rowList, bool append=false)
        {
            StreamWriter fileWriter = new StreamWriter(filePathName, append, Encoding.Default);
            foreach (String[] row in rowList)
            {
                fileWriter.WriteLine(String.Join(CSVAccess.RowSeparater, row));
            }
            fileWriter.Flush();
            fileWriter.Close();

        }
        #endregion
        
        #region Read CSV
        public static List<String[]> ReadCSV(string filePathName)
        {
            try
            {
                List<String[]> ls = new List<String[]>();
                StreamReader fileReader = new StreamReader(filePathName,Encoding.Default);
                if (fileReader == null)
                {
                    throw new Exception("The file is not exit!");
                }
                string line = string.Empty;
                string str = ",(?=\")|(?<=\"),";
                Regex r = new Regex(str);
                //string[] strSplit = {",\"","\","}; 
                line = fileReader.ReadLine();  //first line:header, do not need 
                if (line == null)
                {
                    throw new Exception("The file is null!");
                }
                while (line != null)
                {
                    if (line.Contains("\""))
                    {
                        if (line != null && line.Length > 0)
                        {
                            if (r.IsMatch(line))
                            {
                                string[] temp = { };
                                temp = r.Split(line);
                                List<string> list = new List<string>();
                                //temp = strLine.Split(strSplit, StringSplitOptions.None); 
                                for (int i = 0; i < temp.Length; i++)
                                {
                                    if (temp[i].StartsWith("\"") && temp[i].EndsWith("\""))
                                    {
                                        temp[i] = temp[i].Substring(1, temp[i].Length - 2);
                                        list.Add(temp[i]);
                                    }
                                    else
                                    {
                                        string[] ttemp = temp[i].Split(new string[] { CSVAccess.RowSeparater }, StringSplitOptions.None);
                                        for (int j = 0; j < ttemp.Length; j++)
                                            list.Add(ttemp[j]);
                                    }
                                }
                                ls.Add(list.ToArray());
                            }
                            else
                                ls.Add(line.Split(new string[] { CSVAccess.RowSeparater }, StringSplitOptions.None));
                        }

                    }
                    else
                    {
                        if (line != null && line.Length > 0)
                        {
                            ls.Add(line.Split(new string[] { CSVAccess.RowSeparater }, StringSplitOptions.None));
                        }
                    }
                    line = fileReader.ReadLine();
                }
                fileReader.Close();
                return ls;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return null;
            }
        }
        #endregion
    }
}
