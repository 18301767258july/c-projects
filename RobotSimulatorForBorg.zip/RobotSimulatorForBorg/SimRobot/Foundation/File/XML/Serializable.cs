﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Pegatron.Foundation.Xml
{
    /// <summary>
    /// interface defined convertation from/to TClass object
    /// </summary>
    public interface ISerializable<TClass>
    {
        /// <summary>
        /// Serialize into a dict
        /// </summary>
        /// <param name="template">TClass type template</param>
        /// <returns>TClass object</returns>
        TClass Serialize(TClass template);

        /// <summary>
        /// Deserialize from a obj
        /// </summary>
        /// <param name="obj">TClass type object</param>
        /// <param name="args">args data</param>
        /// <returns>sucess or not</returns>
        bool Deserialize(TClass obj, object args);
    }

    /// <summary>
    /// interface defined convertation from/to file
    /// </summary>
    public interface IFileSerializable
    {
        /// <summary>
        /// Serialize into a file
        /// </summary>
        /// <param name="filePath">file path</param>
        /// <param name="extraTypes">extra types</param>
        /// <returns>indicates sucess or not</returns>
        bool Serialize(string filePath, params Type[] extraTypes);

        /// <summary>
        /// Deserialize from a file
        /// </summary>
        /// <param name="filePath">file path</param>
        /// <param name="args">args data</param>
        /// <param name="extraTypes">extra types</param>
        /// <returns>indicates sucess or not</returns>
        bool Deserialize(string filePath, object args, params Type[] extraTypes);
    }
}
