﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Pegatron.Foundation.Xml
{
    /// <summary>
    /// Dict class defined a serializable key-value structure and link relationship with childs
    /// </summary>
    [Serializable]
    public class Dict : ISerializable<Dict>, ISerializable<XDict>, IFileSerializable
    {
        public const string AssemblyFileKey = "AssemblyFile";
        public const string ClassTypeKey = "ClassType";

        #region constructor
        public Dict()
            : this(null, null)
        {
        }

        public Dict(string key, object value = null)
        {
            this.Key = key;
            this.Value = value;
        }
        #endregion

        #region properties
        public string Key
        {
            get;
            set;
        }


        public object Value
        {
            get;
            set;
        }
        #endregion

        #region dict
        public virtual Dict Serialize(Dict template)
        {
            Dict result = (template != null ? template : new Dict());
            if (result != null)
            {
                result.Key = this.Key;
                result.Value = this.Value;
            }
            return result;
        }

        public virtual XDict Serialize(XDict template)
        {
            XDict result = (template != null ? template : new XDict());
            if (result != null && this.Key != null)
            {
                result[this.Key] = Dict.DictValue2XDictValue(this.Value);
            }
            return result;
        }

        private static object DictValue2XDictValue(object dictValue)
        {
            object xdictValue = null;
            if (dictValue is ISerializable<Dict>)
            {
                Dict dict = (dictValue as ISerializable<Dict>).Serialize(new Dict());
                if (dict != null)
                {
                    xdictValue = dict.Serialize(new XDict());
                }
            }
            else if (dictValue is IEnumerable<ISerializable<Dict>>)
            {
                XDict value = new XDict();
                IEnumerable<Dict> enumerableValue = dictValue as IEnumerable<Dict>;
                foreach (ISerializable<Dict> dictSerializable in enumerableValue)
                {
                    Dict dict = (dictSerializable as ISerializable<Dict>).Serialize(new Dict());
                    if (dict != null && dict.Key != null)
                    {
                        value[dict.Key] = Dict.DictValue2XDictValue(dict.Value);
                    }
                }
                xdictValue = value;
            }
            else if (dictValue is IEnumerable<ISerializable<XDict>>)
            {
                List<XDict> value = new List<XDict>();
                IEnumerable<XDict> enumerableValue = dictValue as IEnumerable<XDict>;
                foreach (ISerializable<XDict> xdictSerializable in enumerableValue)
                {
                    value.Add((xdictSerializable as ISerializable<XDict>).Serialize(new XDict()));
                }
                xdictValue = value.ToArray();
            }
            else if (dictValue != null)
            {
                xdictValue = dictValue;
            }
            return xdictValue;
        }

        public virtual bool Deserialize(Dict dict, object args = null)
        {
            bool result = false;
            if( dict != null )
            {
                this.Key = dict.Key;
                this.Value = dict.Value;
                result = true;
            }
            return result;
        }

        public virtual bool Deserialize(XDict xdict, object args = null)
        {
            bool result = false;
            if (xdict != null)
            {
                result = this.Deserialize(xdict.Serialize((Dict)null), args);
            }
            return result;
        }

        #endregion

        #region file load / save
        /// <summary>
        /// serialize into a file
        /// </summary>
        /// <param name="filePath">file path</param>
        /// <param name="extraTypes">extra types to be serialized</param>
        /// <returns></returns>
        public virtual bool Serialize(string filePath, params Type[] extraTypes)
        {
            return XmlFileSerializer.Serialize(this,filePath,extraTypes);
        }

        public virtual bool Deserialize(string filePath, object args, params Type[] extraTypes)
        {
            return this.Deserialize(Dict.Deserialize(filePath, extraTypes), args);
        }

        /// <summary>
        /// deseialize from a file
        /// </summary>
        /// <param name="filePath">file path</param>
        /// <param name="extraTypes">extra types to be deserialized</param>
        /// <returns></returns>
        public static Dict Deserialize(string filePath, params Type[] extraTypes)
        {
            return XmlFileSerializer.Deserialize(typeof(Dict), filePath, extraTypes) as Dict;
        }
        #endregion

        /// <summary>
        /// got bool value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public bool GetBoolValueByKey(string key, bool defaultValue)
        {
            bool result = defaultValue;
            object temp = this.GetValueByKey(key);
            try
            {
                if (temp != null)
                {
                    result = Convert.ToBoolean(temp);
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        /// <summary>
        /// get short type value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public short GetShortValueByKey(string key, short defaultValue)
        {
            short result = defaultValue;
            object temp = this.GetValueByKey(key);
            try
            {
                if (temp != null)
                {
                    result = Convert.ToInt16(temp);
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        /// <summary>
        /// get int type value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public int GetIntValueByKey(string key, int defaultValue)
        {
            int result = defaultValue;
            object temp = this.GetValueByKey(key);
            try
            {
                if (temp != null)
                {
                    result = Convert.ToInt32(temp);
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        /// <summary>
        /// get long type value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public long GetLongValueByKey(string key, long defaultValue)
        {
            long result = defaultValue;
            object temp = this.GetValueByKey(key);
            try
            {
                if (temp != null)
                {
                    result = Convert.ToInt64(temp);
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        /// <summary>
        /// get double type value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public double GetDoubleValueByKey(string key, double defaultValue)
        {
            double result = defaultValue;
            object temp = this.GetValueByKey(key);
            try
            {
                if (temp != null)
                {
                    result = Convert.ToDouble(temp);
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        /// <summary>
        /// get string value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public string GetStringValueByKey(string key, string defaultValue)
        {
            string result = defaultValue;
            object temp = this.GetValueByKey(key);
            try
            {
                result = temp as string;
                if(result == null)
                {
                    result = defaultValue;
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        public string GetStringValueByKey(string key)
        {
            return this.GetStringValueByKey(key, null);
        }

        /// <summary>
        /// get List of string by key
        /// </summary>
        /// <param name="key">key name</param>
        /// <returns></returns>
        public string[] GetStringArrayByKey(string key)
        {
            string[] result = null;
            object temp = this.GetValueByKey(key);
            try
            {
                result = temp as string[];
            }
            catch
            {
                result = null;
            }
            return result;
        }

        /// <summary>
        /// get value object for a specified key in child dict
        /// </summary>
        /// <param name="key">key string</param>
        /// <returns></returns>
        public object GetValueByKey(string key)
        {
            object result = null;
            Dict dict = this.GetDictByKey(key);
            if (dict != null)
            {
                result = dict.Value;
            }
            return result;
        }

        /// <summary>
        /// get Dict object by a specified key and string type value in child dict
        /// </summary>
        /// <param name="key">key string</param>
        /// <returns></returns>
        public Dict GetDictByKey(string key)
        {
            Dict result = null;
            if (this.Value != null && key != null)
            {
                if (this.Value is Dict)
                {
                    if (key == (this.Value as Dict).Key)
                    {
                        result = this.Value as Dict;
                    }
                }
                else if (this.Value is IEnumerable<Dict>)
                {
                    IEnumerable<Dict> enumerableValue = this.Value as IEnumerable<Dict>;
                    foreach (Dict dict in enumerableValue)
                    {
                        if (dict != null && key == dict.Key)
                        {
                            result = dict;
                            break;
                        }
                    }
                }
            }
            return result;
        }


        /// <summary>
        /// set value for a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="value">value object</param>
        /// <returns></returns>
        public bool SetValueByKey(string key, object value)
        {
            bool result = false;
            if (key != null)
            {
                if (this.Value != null)
                {
                    if (this.Value is Dict)
                    {
                        if (key == (this.Value as Dict).Key)
                        {
                            (this.Value as Dict).Value = value;
                        }
                        else
                        {
                            this.Value = new Dict[] { this.Value as Dict, new Dict(key, value) };
                        }
                        result = true;
                    }
                    else if (this.Value is ICollection)
                    {
                        bool isExist = false;
                        List<object> newValue = new List<object>();
                        foreach (object sub in (this.Value as ICollection))
                        {
                            newValue.Add(sub);
                            if (sub is Dict && (sub as Dict).Key == key)
                            {
                                (sub as Dict).Value = value;
                                isExist = true;
                                result = true;
                                break;
                            }
                        }
                        if (!isExist)
                        {
                            newValue.Add(new Dict(key, value));
                            this.Value = newValue.ToArray();
                            result = true;
                        }
                    }
                }
                else
                {
                    this.Value = new Dict[] { new Dict(key, value) };
                    result = true;
                }
            }
            return result;
        }
    }


    /// <summary>
    /// This class defined a key-value structure. 
    /// the deference with Dict is value not defined as a member, we add 2 delegate to access(get/set)
    /// </summary>
    public class KeyValue
    {
        #region property

        /// <summary>
        /// key string
        /// </summary>
        public string Key
        {
            get;
            set;
        }

        /// <summary>
        /// value object that get by GetDelegate
        /// </summary>
        public object Value
        {
            get
            {
                object result = null;
                if (this.GetDelegate != null)
                {
                    result = this.GetDelegate.Invoke();
                }
                return result;
            }
            set
            {
                if (this.SetDelegate != null)
                {
                    this.SetDelegate.Invoke(value);
                }
            }
        }

        /// <summary>
        /// read(get)
        /// </summary>
        public Func<object> GetDelegate
        {
            get;
            protected set;
        }

        /// <summary>
        /// write(set)
        /// </summary>
        public Action<object> SetDelegate
        {
            get;
            protected set;
        }
        #endregion

        #region Constructor
        /// <summary>
        /// constructor for KeyValue
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="getValueDelegate">delegate to get value</param>
        /// <param name="setValueDelegate">delegate to set value</param>
        public KeyValue(string key = null, Func<object> getValueDelegate = null, Action<object> setValueDelegate = null)
        {
            this.Key = key;
            this.GetDelegate = getValueDelegate;
            this.SetDelegate = setValueDelegate;
        }
        #endregion
    }
}
