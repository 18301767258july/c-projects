﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;
using System.Reflection;
using Pegatron.Foundation;

namespace Pegatron.Foundation.Xml
{
    [XmlRoot("Root")]
    public class XDict : Dictionary<string, object>, ISerializable<XDict>, ISerializable<Dict>, IFileSerializable, IXmlSerializable
    {
        public const string AssemblyFileKey = "AssemblyFile";
        public const string ClassTypeKey = "ClassType";
        public const string CollectionKey = "Collection";

        public new object this[string key]
        {
            get
            {
                if (key != null && this.ContainsKey(key))
                {
                    return base[key];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                if (key != null)
                {
                    base[key] = value;
                }
            }
        }

        public string AssemblyFile
        {
            get;
            set;
        }

        public string ClassType
        {
            get;
            set;
        }

        public bool IsCollection
        {
            get;
            set;
        }

        public override string  ToString()
        {
            if (!string.IsNullOrEmpty(this.AssemblyFile) || !string.IsNullOrEmpty(this.ClassType))
            {
                return Utility.CreateTag(this.AssemblyFile) + Utility.CreateTag(this.ClassType) + base.ToString();
            }
            else
            {
                return base.ToString();
            }
        }

        #region constructor
        public XDict()
            : this(null, null)
        {
        }

        public XDict(Dictionary<string, object> dictionary)
        {
            if (dictionary != null)
            {
                foreach (string key in dictionary.Keys)
                {
                    object value = dictionary[key];
                    if (value is Dictionary<string, object>)
                    {
                        this[key] = new XDict(value as Dictionary<string, object>);
                    }
                    else if (value is IEnumerable<Dictionary<string, object>>)
                    {
                        List<XDict> xdictList = new List<XDict>();
                        foreach (Dictionary<string, object> subDictionary in value as IEnumerable<Dictionary<string, object>>)
                        {
                            xdictList.Add(new XDict(subDictionary));
                        }
                        this[key] = xdictList.ToArray();
                    }
                    else
                    {
                        this[key] = value;
                    }
                }
            }
        }

        public XDict(string key, object value)
        {
            if (key != null)
            {
                this[key] = value;
            }
        }

        public XDict(string assemblyFile, string classType, string key, object value):this(key, value)
        {
            this.AssemblyFile = assemblyFile;
            this.ClassType = classType;
        }
        #endregion

        #region json
        public string ToJsonString()
        {
            StringBuilder message = new StringBuilder();
            try
            {
                new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(this, message);
            }
            catch (Exception ex)
            {
                message.Clear();
                ATSException.Logging(ex);
            }
            return message.ToString();
        }

        public static XDict JsonString2XDict(string jsonString)
        {
            XDict result = null;
            if (!string.IsNullOrEmpty(jsonString))
            {
                try
                {
                    Dictionary<string, object> dictionary =
                        new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Dictionary<string, object>>(jsonString);
                    result = new XDict(dictionary);
                }
                catch (Exception ex)
                {
                    result = null;
                    ATSException.Logging(ex);
                }
            }
            return result;
        }
        #endregion

        #region dict
        public virtual XDict Serialize(XDict template)
        {
            XDict result = (template != null ? template : new XDict());
            if( result != null )
            {
                result.AssemblyFile = this.AssemblyFile;
                result.ClassType = this.ClassType;
                result.IsCollection = this.IsCollection;
                foreach (string key in this.Keys)
                {
                    result[key] = this[key];
                }
            }
            return result;
        }

        public virtual Dict Serialize(Dict template)
        {
            Dict result = (template != null ? template : new Dict());
            if (result != null)
            {
                //if (this.Keys.Count > 1)
                {
                    List<Dict> value = new List<Dict>();
                    value.Add(new Dict(XDict.AssemblyFileKey, this.AssemblyFile));
                    value.Add(new Dict(XDict.ClassTypeKey, this.ClassType));
                    foreach (string key in this.Keys)
                    {
                        value.Add(new Dict(key, XDict.XDictValue2DictValue(this[key])));
                    }
                    result.Value = value.ToArray();
                }
                /*else if (this.Keys.Count == 1)
                {
                    result.Key = this.Keys.ElementAt(0);
                    if (result.Key != null)
                    {
                        result.Value = XDict.XDictValue2DictValue(this[result.Key]);
                    }
                }*/
            }
            return result;
        }

        private static object XDictValue2DictValue(object xdictValue)
        {
            object dictValue = null;
            if (xdictValue is ISerializable<XDict>)
            {
                XDict xdict = (xdictValue as ISerializable<XDict>).Serialize(new XDict());
                if (xdict != null)
                {
                    List<Dict> value = new List<Dict>();
                    value.Add(new Dict(XDict.AssemblyFileKey, xdict.AssemblyFile));
                    value.Add(new Dict(XDict.ClassTypeKey, xdict.ClassType));
                    foreach (string key in xdict.Keys)
                    {
                        if (key != null)
                        {
                            value.Add(new Dict(key, XDict.XDictValue2DictValue((xdictValue as XDict)[key])));
                        }
                    }
                    dictValue = value.ToArray();
                }
            }
            else if (xdictValue is IEnumerable<ISerializable<XDict>>)
            {
                List<Dict> value = new List<Dict>();
                IEnumerable<ISerializable<XDict>> enumerableValue = xdictValue as IEnumerable<ISerializable<XDict>>;
                foreach (ISerializable<XDict> xdictSerializable in enumerableValue)
                {
                    XDict xdict = xdictSerializable.Serialize(new XDict());
                    if (xdict != null)
                    {
                        value.Add((xdict != null) ? xdict.Serialize(new Dict()) : null);
                    }
                }
                dictValue = value.ToArray();
            }
            else if (xdictValue is IEnumerable<ISerializable<Dict>>)
            {
                List<Dict> value = new List<Dict>();
                IEnumerable<ISerializable<Dict>> enumerableValue = xdictValue as IEnumerable<ISerializable<Dict>>;
                foreach (ISerializable<Dict> dictSerializable in enumerableValue)
                {
                    value.Add(dictSerializable.Serialize(new Dict()));
                }
                dictValue = value.ToArray();
            }
            else if (xdictValue != null)
            {
                dictValue = xdictValue;
            }
            return dictValue;
        }

        public virtual bool Deserialize(XDict dict, object args = null)
        {
            bool result = false;
            if (dict != null)
            {
                this.AssemblyFile = dict.AssemblyFile;
                this.ClassType = dict.ClassType;
                this.IsCollection = dict.IsCollection;
                foreach (string key in dict.Keys)
                {
                    this[key] = dict[key];
                }
                result = true;
            }
            return result;
        }

        public virtual bool Deserialize(Dict dict, object args = null)
        {
            bool result = false;
            if (dict != null)
            {
                result = this.Deserialize(dict.Serialize((XDict)null), args);
            }
            return result;
        }
        #endregion

        #region convert with object
        public static XDict Serialize(object obj, bool ignoreDefaultKey = false, string upperLayerAssemblyFile = null, string defaultClassType = null)
        {
            XDict result = null;
            if (obj != null && Attribute.GetCustomAttribute(obj.GetType(), typeof(XDictAttribute)) is XDictAttribute)
            {
                result = new XDict();
                string assemblyFile = (obj.GetType().Module.Assembly.Equals(Assembly.GetEntryAssembly())) ? null : obj.GetType().Module.Name;
                string classType = obj.GetType().FullName;
                if (assemblyFile != null && !assemblyFile.Equals(upperLayerAssemblyFile))
                {
                    result.AssemblyFile = assemblyFile;
                }
                if (classType != null && !classType.Equals(defaultClassType))
                {
                    result.ClassType = classType;
                }
                PropertyInfo[] properties = obj.GetType().GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
                if (properties != null)
                {
                    foreach (PropertyInfo propertyInfo in properties)
                    {
                        XDictAttribute propertyAttribute = Attribute.GetCustomAttribute(propertyInfo, typeof(XDictAttribute)) as XDictAttribute;
                        if (propertyInfo.CanRead && propertyAttribute != null)
                        {
                            MethodInfo methodInfo = propertyInfo.GetGetMethod();
                            if (methodInfo != null && methodInfo.IsPublic)
                            {
                                object propertyValue = methodInfo.Invoke(obj, null);
                                if (propertyValue != null && (!ignoreDefaultKey || !propertyValue.Equals(propertyAttribute.DefaultValue)))
                                {
                                    string key = propertyAttribute.Key != null ? propertyAttribute.Key : propertyInfo.Name;
                                    if (key != null)
                                    {
                                        if (propertyAttribute.IsCollection && propertyValue is IEnumerable)
                                        {
                                            ArrayList propertySerialized = new ArrayList();
                                            foreach (object element in (propertyValue as IEnumerable))
                                            {
                                                if (Attribute.GetCustomAttribute(element.GetType(), typeof(XDictAttribute)) is XDictAttribute)
                                                {
                                                    string elementKey = propertyAttribute.ElementKey;
                                                    string elementTypeFullname = propertyAttribute.ElementType!=null ? propertyAttribute.ElementType.FullName : null;
                                                    if (string.IsNullOrEmpty(elementKey) && propertyAttribute.ElementType!=null)
                                                    {
                                                        elementKey = propertyAttribute.ElementType.Name;
                                                    }
                                                    if (!string.IsNullOrEmpty(elementKey))
                                                    {
                                                        string assamblyFile = (element.GetType().Module.Assembly.Equals(Assembly.GetEntryAssembly())) ? null : element.GetType().Module.Name;
                                                        propertySerialized.Add(new XDict(assamblyFile, element.GetType().FullName, elementKey, XDict.Serialize(element, ignoreDefaultKey, assemblyFile, elementTypeFullname)));
                                                    }
                                                    else
                                                    {
                                                        propertySerialized.Add(XDict.Serialize(element, ignoreDefaultKey, assemblyFile, elementTypeFullname));
                                                    }
                                                }
                                                else
                                                {
                                                    propertySerialized.Add(element);
                                                }
                                            }
                                            object serializeObj = null;
                                            if (propertyAttribute.SerializeType != null)
                                            {
                                                ConstructorInfo ci = propertyAttribute.SerializeType.GetConstructor(new Type[] { typeof(int) });
                                                if (ci != null)
                                                {
                                                    serializeObj = ci.Invoke(new object[] { propertySerialized.Count });
                                                }
                                            }
                                            propertySerialized.CopyTo(serializeObj as Array, 0);
                                            result[key] = serializeObj;
                                            result.IsCollection = true;
                                        }
                                        else
                                        {
                                            if (Attribute.GetCustomAttribute(propertyInfo.PropertyType, typeof(XDictAttribute)) is XDictAttribute)
                                            {
                                                result[key] = XDict.Serialize(propertyValue, ignoreDefaultKey, assemblyFile, propertyInfo.PropertyType.FullName);
                                            }
                                            else
                                            {
                                                result[key] = propertyValue;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return result;
        }

        public bool Deserialize(object obj)
        {
            bool result = false;
            if (obj != null && this != null && Attribute.GetCustomAttribute(obj.GetType(), typeof(XDictAttribute)) is XDictAttribute)
            {
                result = true;
                PropertyInfo[] properties = obj.GetType().GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
                if (properties != null)
                {
                    foreach (PropertyInfo propertyInfo in properties)
                    {
                        XDictAttribute propertyAttribute = Attribute.GetCustomAttribute(propertyInfo, typeof(XDictAttribute)) as XDictAttribute;
                        if (propertyInfo.CanWrite && propertyAttribute != null)
                        {
                            MethodInfo methodInfo = propertyInfo.GetSetMethod();
                            if (methodInfo != null && methodInfo.IsPublic)
                            {
                                string key = propertyAttribute.Key != null ? propertyAttribute.Key : propertyInfo.Name;
                                object value = propertyAttribute.DefaultValue;
                                if (key != null && this[key] != null)
                                {
                                    object beforeDeserialized = this[key];
                                    if (beforeDeserialized is XDict)
                                    {
                                        XDict targetDict = (beforeDeserialized as XDict);
                                        if (targetDict.ClassType == null)
                                        {
                                            value = AssemblyFuncs.CreateInstance(propertyInfo.PropertyType);
                                        }
                                        else
                                        {
                                            value = AssemblyFuncs.CreateInstance(targetDict.ClassType, targetDict.AssemblyFile);
                                        }
                                        targetDict.Deserialize(value);
                                    }
                                    else if (beforeDeserialized is IEnumerable<XDict>)
                                    {
                                        ArrayList objs = new ArrayList();
                                        string elementKey = propertyAttribute.ElementKey;
                                        if (string.IsNullOrEmpty(elementKey) && propertyAttribute.ElementType != null)
                                        {
                                            elementKey = propertyAttribute.ElementType.Name;
                                        }
                                        foreach (XDict subXdict in (beforeDeserialized as IEnumerable<XDict>))
                                        {
                                            object subValue = null;
                                            if (!string.IsNullOrEmpty(elementKey) && subXdict[elementKey] is XDict)
                                            {
                                                XDict elementDict = subXdict[elementKey] as XDict;
                                                
                                                if (elementDict != null)
                                                {
                                                    if (elementDict.ClassType == null)
                                                    {
                                                        subValue = AssemblyFuncs.CreateInstance(propertyAttribute.ElementType);
                                                    }
                                                    else
                                                    {
                                                        subValue = AssemblyFuncs.CreateInstance(elementDict.ClassType, elementDict.AssemblyFile);
                                                    }
                                                }
                                                elementDict.Deserialize(subValue);
                                            }
                                            else
                                            {
                                                object temp = subXdict[propertyAttribute.ElementType.Name];
                                                subValue = Convert.ChangeType(temp, propertyAttribute.ElementType);
                                            }
                                            objs.Add(subValue);
                                        }
                                        ConstructorInfo ci = propertyInfo.PropertyType.GetConstructor(new Type[] { typeof(int) });
                                        if (ci != null)
                                        {
                                            value = ci.Invoke(new object[] { objs.Count });
                                        }
                                        objs.CopyTo(value as Array, 0);
                                    }
                                    else
                                    {
                                        if (beforeDeserialized != null)
                                        {
                                            value = Convert.ChangeType(beforeDeserialized, propertyInfo.PropertyType) as object;
                                        }
                                    }
                                }
                                if (value != null)
                                {
                                    methodInfo.Invoke(obj, new object[] { value });
                                }
                            }
                        }
                    }
                }
            }
            return result;
        }
        #endregion

        #region file load / save
        /// <summary>
        /// serialize into a file
        /// </summary>
        /// <param name="filePath">file path</param>
        /// <returns></returns>
        public virtual bool Serialize(string filePath, params Type[] extraTypes)
        {
            return XmlFileSerializer.Serialize(this, filePath, extraTypes);
        }

        public virtual bool Deserialize(string filePath, object args, params Type[] extraTypes)
        {
            return this.Deserialize(XDict.Deserialize(filePath, extraTypes), args);
        }


        /// <summary>
        /// deseialize from a file
        /// </summary>
        /// <param name="filePath">file path</param>
        /// <param name="extraTypes">extra types to be deserialized</param>
        /// <returns></returns>
        public static XDict Deserialize(string filePath, params Type[] extraTypes)
        {
            return XmlFileSerializer.Deserialize(typeof(XDict), filePath, extraTypes) as XDict;
        }
        #endregion

        #region xml
        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(reader);
            this.ReadXml(xmlDoc);
        }

        public void ReadXml(XmlDocument xmlDoc)
        {
            this.Deserialize(XDict.ReadRootNodeToXmlDict(xmlDoc.FirstChild));
        }

        private static bool IsForArray(XmlNode xmlNode)
        {
            bool result = false;
            if (xmlNode.Attributes != null && xmlNode.Attributes[XDict.CollectionKey] != null)
            {
                result = Convert.ToBoolean(xmlNode.Attributes[XDict.CollectionKey].Value);
            }
            if (!result && xmlNode.ChildNodes.Count > 1)
            {
                result = true;
                XmlNode currentNode = xmlNode.ChildNodes[1];
                while (currentNode != null)
                {
                    if (currentNode.Name != currentNode.PreviousSibling.Name)
                    {
                        result = false;
                        break;
                    }
                    currentNode = currentNode.NextSibling;
                }
            }
            return result;
        }

        private static object ReadChildNodesToObject(XmlNode xmlNode)
        {
            object result = null;
            if (xmlNode.ChildNodes.Count > 0 || (xmlNode.Attributes!=null && xmlNode.Attributes.Count > 0))
            {
                if (xmlNode.ChildNodes.Count == 1 && xmlNode.FirstChild.NodeType == XmlNodeType.Text)
                {
                    result = xmlNode.FirstChild.Value;
                }
                else
                {
                    if (XDict.IsForArray(xmlNode))
                    {
                        result = XDict.ReadChildNodesToArrayOfXmlDict(xmlNode);
                    }
                    else
                    {
                        result = XDict.ReadChildNodesToXmlDict(xmlNode);
                    }
                }
            }
            return result;
        }

        private static XDict InitXmlDictByXmlNode(XmlNode xmlNode)
        {
            XDict result = new XDict();
            if (xmlNode!=null)
            {
                if (xmlNode.Attributes != null)
                {
                    result.IsCollection = XDict.IsForArray(xmlNode);
                    if (xmlNode.Attributes[XDict.AssemblyFileKey] != null)
                    {
                        result.AssemblyFile = xmlNode.Attributes[XDict.AssemblyFileKey].Value;
                    }
                    else
                    {
                        if (xmlNode.ParentNode != null)
                        {
                            result.AssemblyFile = XDict.InitXmlDictByXmlNode(xmlNode.ParentNode).AssemblyFile;
                        }
                    }
                    if (xmlNode.Attributes[XDict.ClassTypeKey] != null)
                    {
                        result.ClassType = xmlNode.Attributes[XDict.ClassTypeKey].Value;
                    }
                    else
                    {
                        if (xmlNode.ParentNode != null && XDict.IsForArray(xmlNode.ParentNode))
                        {
                            result.ClassType = XDict.InitXmlDictByXmlNode(xmlNode.ParentNode).ClassType;
                        }
                    }
                }
                else if (xmlNode.ParentNode != null )
                {
                    result.AssemblyFile = XDict.InitXmlDictByXmlNode(xmlNode.ParentNode).AssemblyFile;
                    if (XDict.IsForArray(xmlNode.ParentNode))
                    {
                        result.ClassType = XDict.InitXmlDictByXmlNode(xmlNode.ParentNode).ClassType;
                    }
                }
            }
            return result;
        }

        private static XDict[] ReadChildNodesToArrayOfXmlDict(XmlNode xmlNode)
        {
            List<XDict> result = new List<XDict>();
            foreach (XmlNode child in xmlNode.ChildNodes)
            {
                XDict xmlDict = XDict.InitXmlDictByXmlNode(child);
                xmlDict[child.Name] = XDict.ReadChildNodesToObject(child);
                result.Add(xmlDict);
            }
            return result.ToArray();
        }


        private static XDict ReadRootNodeToXmlDict(XmlNode rootNode)
        {
            return XDict.ReadChildNodesToXmlDict(rootNode);
        }

        private static XDict ReadChildNodesToXmlDict(XmlNode xmlNode)
        {
            XDict result = XDict.InitXmlDictByXmlNode(xmlNode);
            foreach (XmlNode child in xmlNode.ChildNodes)
            {
                result[child.Name] = XDict.ReadChildNodesToObject(child);
            }
            return result;
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            foreach (string key in this.Keys)
            {
                writer.WriteStartElement(key);
                object value = this[key];
                if (value != null)
                {
                    if (value is ISerializable<XDict>)
                    {
                        XDict serializedDict = (value as ISerializable<XDict>).Serialize(new XDict());
                        if (serializedDict.AssemblyFile != null)
                        {
                            writer.WriteAttributeString(XDict.AssemblyFileKey, serializedDict.AssemblyFile);
                        }

                        if (serializedDict.ClassType != null)
                        {
                            writer.WriteAttributeString(XDict.ClassTypeKey, serializedDict.ClassType);
                        }
                        serializedDict.WriteXml(writer);
                    }
                    else if (value is IEnumerable<ISerializable<XDict>>)
                    {
                        if (this.IsCollection && (value as IEnumerable<ISerializable<XDict>>).Count()<=1)
                        {
                            writer.WriteAttributeString(XDict.CollectionKey, this.IsCollection.ToString());
                        }
                        foreach (ISerializable<XDict> subValue in (value as IEnumerable<ISerializable<XDict>>))
                        {
                            subValue.Serialize(new XDict()).WriteXml(writer);
                        }
                    }
                    else
                    {
                        writer.WriteValue(value);
                    }
                }
                writer.WriteEndElement();
            }
        }
        #endregion

        #region get value by key
        /// <summary>
        /// got bool value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public bool GetBoolValueByKey(string key, bool defaultValue)
        {
            bool result = defaultValue;
            try
            {
                object temp = this[key];
                if (temp != null)
                {
                    result = Convert.ToBoolean(temp);
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        /// <summary>
        /// get short type value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public short GetShortValueByKey(string key, short defaultValue)
        {
            short result = defaultValue;
            try
            {
                object temp = this[key];
                if (temp != null)
                {
                    result = Convert.ToInt16(temp);
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        /// <summary>
        /// get int type value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public int GetIntValueByKey(string key, int defaultValue)
        {
            int result = defaultValue;
            try
            {
                object temp = this[key];
                if (temp != null)
                {
                    result = Convert.ToInt32(temp);
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        /// <summary>
        /// get long type value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public long GetLongValueByKey(string key, long defaultValue)
        {
            long result = defaultValue;
            try
            {
                object temp = this[key];
                if (temp != null)
                {
                    result = Convert.ToInt64(temp);
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        /// <summary>
        /// get double type value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public double GetDoubleValueByKey(string key, double defaultValue)
        {
            double result = defaultValue;
            try
            {
                object temp = this[key];
                if (temp != null)
                {
                    result = Convert.ToDouble(temp);
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        /// <summary>
        /// get string value by a key
        /// </summary>
        /// <param name="key">key string</param>
        /// <param name="defaultValue">default value will be returned if can not get for the key</param>
        /// <returns></returns>
        public string GetStringValueByKey(string key, string defaultValue)
        {
            string result = defaultValue;
            try
            {
                object temp = this[key];
                result = temp as string;
                if (result == null)
                {
                    result = defaultValue;
                }
            }
            catch
            {
                result = defaultValue;
            }
            return result;
        }

        public string GetStringValueByKey(string key)
        {
            return this.GetStringValueByKey(key, null);
        }
        #endregion
    }
}
