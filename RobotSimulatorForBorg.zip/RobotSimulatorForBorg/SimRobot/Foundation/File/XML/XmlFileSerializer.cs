using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections;
using System.Runtime.InteropServices;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Diagnostics;
using System.Reflection;
using Pegatron.Foundation;

namespace Pegatron.Foundation.Xml
{
    /// <summary>
    /// XmlFileSerializer class that using XmlSerializer to do serializer and deserializer
    /// </summary>
    public class XmlFileSerializer
    {
        /// <summary>
        /// Serialize(save) object data into file
        /// </summary>
        /// <param name="obj">object data to be serialized</param>
        /// <param name="filePath">file that storing object data</param>
        /// <param name="xmlSerializer">XmlSerializer</param>
        /// <returns>if true, serialze successfully, or error occured</returns>
        public static bool Serialize(object obj, string filePath, XmlSerializer xmlSerializer)
        {
            bool result = false;
            if (filePath != null && obj != null && xmlSerializer!=null)
            {
                FileStream fs = null;
                try
                {
                    fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);
                    xmlSerializer.Serialize(fs, obj);
                    result = true;
                }
                catch(Exception ex)
                {
                    result = false;
                    ATSException.Throw(ex);
                }
                finally
                {
                    if (fs != null)
                    {
                        fs.Close();
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Deserialize(read) object data from file
        /// </summary>
        /// <param name="filePath">file that storing object data</param>
        /// <param name="xmlSerializer">XmlSerializer</param>
        /// <returns>deserialized object</returns>
        public static object Deserialize(string filePath, XmlSerializer xmlSerializer)
        {
            object result = null;
            if (filePath != null && System.IO.File.Exists(filePath) && xmlSerializer != null)
            {
                FileStream fs = null;
                try
                {
                    fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                    result = xmlSerializer.Deserialize(fs);
                }
                catch (Exception ex)
                {
                    result = null;
                    ATSException.Throw(ex);
                }
                finally
                {
                    if (fs != null)
                    {
                        fs.Close();
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Serialize(save) object data into file with extra types
        /// </summary>
        /// <param name="obj">object data to be serialized</param>
        /// <param name="filePath">file that storing object data</param>
        /// <param name="xmlSerializer">XmlSerializer</param>
        /// <param name="extraTypes">extra types that should be serialized</param>
        /// <returns>if true, serialze successfully, or error occured</returns>
        public static bool Serialize(object obj, string filePath, params Type[] extraTypes)
        {
            bool result = false;
            try
            {
                XmlSerializer xs = new XmlSerializer(obj.GetType(), extraTypes);
                result = XmlFileSerializer.Serialize(obj, filePath, xs);
            }
            catch (Exception ex)
            {
                result = false;
                ATSException.Throw(ex);
            }
            return result;
        }

        /// <summary>
        /// Deserialize(read) object data from file
        /// </summary>
        /// <param name="filePath">file that storing object data</param>
        /// <param name="xmlSerializer">XmlSerializer</param>
        /// <param name="extraTypes">extra types that should be serialized</param>
        /// <returns>deserialized object</returns>
        public static object Deserialize(Type type, string filePath, params Type[] extraTypes)
        {
            object result = null;
            try
            {
                XmlSerializer xs = new XmlSerializer(type, extraTypes);
                result = XmlFileSerializer.Deserialize(filePath, xs);
            }
            catch (Exception ex)
            {
                result = null;
                ATSException.Throw(ex);
            }
            return result;
        }
    }
}
