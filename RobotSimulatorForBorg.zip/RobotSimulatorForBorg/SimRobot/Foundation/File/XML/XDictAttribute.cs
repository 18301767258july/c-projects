﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace Pegatron.Foundation.Xml
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Class)]
    public class XDictAttribute : Attribute
    {
        public string Key
        {
            get;
            set;
        }

        public string ElementKey
        {
            get;
            set;
        }

        public object DefaultValue
        {
            get;
            set;
        }

        public bool IsCollection
        {
            get;
            protected set;
        }

        public Type SerializeType
        {
            get;
            set;
        }

        public Type ElementType
        {
            get;
            set;
        }

        public XDictAttribute():this(false)
        {
        }

        public XDictAttribute(bool isCollection)
        {
            this.IsCollection = isCollection;
        }
    }
}
