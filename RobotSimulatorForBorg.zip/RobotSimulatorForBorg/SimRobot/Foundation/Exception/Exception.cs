using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pegatron.Foundation
{
    public class ATSException
    {
        public const string ExceptionKey = "Exeception";

        public static void Throw(Exception ex, object sender = null)
        {
            ATSException.Logging(ex, sender); 
            throw ex;
        }

        public static void Caught(Exception ex, object sender = null)
        {
            ATSException.Throw(ex, sender);
        }

        public static void Logging(Exception ex, object sender = null)
        {
            LoggingCenter.DefaultCenter.ExceptionLogging(ex, sender);
        }

        public static void Show(Exception ex, string title = ATSException.ExceptionKey, bool saveLogFlag = true)
        {
            if (saveLogFlag) ATSException.Logging(ex);
            System.Windows.Forms.MessageBox.Show(ex.ToString(), title, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
