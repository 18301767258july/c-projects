﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Pegatron.Foundation
{
    public abstract class EnumManager<TEnumerable, TElement>
        where TEnumerable : IEnumerable, new()
    {
        #region fields
        protected TEnumerable mDevices = new TEnumerable();

        protected RWLock mDeviceRWLock = new RWLock();
        #endregion

        #region properties

        public RWLock DeviceRWLock
        {
            get
            {
                return mDeviceRWLock;
            }
        }

        protected TEnumerable Devices
        {
            get
            {
                return mDevices;
            }
        }

        public virtual int Count
        {
            get
            {
                return this.PerformWithLockRead(() => this.InnerDevicesCount, -1);
            }
        }
        #endregion

        #region abstract functions
        protected abstract int InnerDevicesCount { get; }
        protected abstract bool InnerAddDevice(TElement device);
        protected abstract bool InnerRemoveDevice(TElement device);
        protected abstract bool InnerContainsDevice(TElement device);
        protected abstract void InnerClearDevices();
        #endregion

        #region functions
        #region add device
        public virtual bool AddDevice(TElement device)
        {
            return this.PerformWithLockWrite(() => this.InnerAddDevice(device));
        }

        public bool AddDevice(TElement device, Predicate<TElement> match)
        {
            bool result = false;
            if( match != null )
            {
                result = this.PerformWithLockWrite(() => match.Invoke(device) ? this.AddDevice(device) : false);
            }
            else
            {
                result = this.AddDevice(device);
            }
            return result;
        }

        public bool AddDevice(TElement device, Func<bool> match)
        {
            bool result = false;
            if (match != null)
            {
                result = this.PerformWithLockWrite(() => match.Invoke() ? this.AddDevice(device) : false);
            }
            else
            {
                result = this.AddDevice(device);
            }
            return result;
        }

        public bool AddDevice(TElement baseDevice, Func<TElement, TElement> convertor, Predicate<TElement> match = null)
        {
            bool result = false;
            if (convertor != null)
            {
                result = this.PerformWithLockWrite(() => this.AddDevice(convertor.Invoke(baseDevice), match));
            }
            else
            {
                result = this.AddDevice(baseDevice, match);
            }
            return result;
        }
        #endregion

        #region contains / get device(s)
        public virtual bool ContainsDevice(TElement device)
        {
            return this.PerformWithLockRead(() => this.InnerContainsDevice(device));
        }

        public virtual bool ContainsDevice(Predicate<TElement> match)
        {
            return this.GetDevice(match) != null;
        }

        public virtual TElement GetDevice(Predicate<TElement> match, TElement defaultValue = default(TElement))
        {
            return this.PerformOnDevicesUntil(match, defaultValue);
        }

        public virtual TElement[] EnumDevices(Predicate<TElement> match = null)
        {
            return this.PerformOnDevices(match);
        }
        #endregion

        #region perform
        public void PerformWithLockWrite(Action action)
        {
            this.DeviceRWLock.PerformWithLockWrite(action);
        }

        public TResult PerformWithLockWrite<TResult>(Func<TResult> func, TResult defaultValue = default(TResult))
        {
            return this.DeviceRWLock.PerformWithLockWrite(func, defaultValue);
        }

        public void PerformWithLockRead(Action action)
        {
            this.DeviceRWLock.PerformWithLockRead(action);
        }

        public TResult PerformWithLockRead<TResult>(Func<TResult> func, TResult defaultValue = default(TResult))
        {
            return this.DeviceRWLock.PerformWithLockRead(func, defaultValue);
        }

        public void PerformOnDevices(Action<TElement> action, Predicate<TElement> match = null)
        {
            if (action != null)
            {
                this.PerformWithLockRead(() =>
                    {
                        foreach (TElement device in this.Devices)
                        {
                            if (match == null || match.Invoke(device))
                            {
                                action.Invoke(device);
                            }
                        }
                    });
            }
        }

        public TResult PerformOnDevicesUntil<TResult>(Func<TElement, TResult> func, Predicate<TElement> condition, TResult defaultValue = default(TResult))
        {
            TResult result = defaultValue;
            if (func != null)
            {
                this.PerformWithLockRead(() =>
                {
                    foreach (TElement device in this.Devices)
                    {
                        if (condition == null || condition.Invoke(device))
                        {
                            result = func.Invoke(device);
                            break;
                        }
                    }
                });
            }
            return result;
        }

        public TElement[] PerformOnDevices(Predicate<TElement> match)
        {
            return this.PerformOnDevices(match, device => device);
        }

        public T[] PerformOnDevices<T>(Predicate<TElement> match, Func<TElement, T> convertor)
        {
            List<T> result = new List<T>();
            this.PerformOnDevices(device => result.Add(convertor.Invoke(device)), match);
            return (result != null && result.Count > 0) ? result.ToArray() : null;
        }

        public TElement PerformOnDevicesUntil(Predicate<TElement> condition, TElement defaultValue = default(TElement))
        {
            return this.PerformWithLockRead(() =>
                {
                    TElement result = defaultValue;
                    if (condition != null)
                    {
                        foreach (TElement device in this.Devices)
                        {
                            if (condition.Invoke(device))
                            {
                                result = device;
                                break;
                            }
                        }
                    }
                    return result;
                }
                );
        }
        #endregion

        #region remove /clear device(s)
        public virtual bool RemoveDevice(TElement device)
        {
            return this.PerformWithLockWrite(() => this.InnerRemoveDevice(device));
        }
        public virtual bool RemoveDevice(Predicate<TElement> match)
        {
            return ( match != null ) ? this.RemoveDevice(this.GetDevice(match)) : false;
        }
        public virtual void ClearDevices()
        {
            this.PerformWithLockWrite(() => this.InnerClearDevices());
        }
        #endregion

        #region add devices
        public int AddDevices(params TElement[] devices)
        {
            return this.AddDevices(devices as IEnumerable<TElement>);
        }

        public int AddDevices(IEnumerable<TElement> devices)
        {
            return this.AddDevices(null, devices);
        }

        public int AddDevices(Predicate<TElement> match, params TElement[] devices)
        {
            return this.AddDevices(match, devices as IEnumerable<TElement>);
        }

        public int AddDevices(Predicate<TElement> match, IEnumerable<TElement> devices)
        {
            int result = 0;
            if( devices != null )
            {
                result = this.PerformWithLockWrite(() =>
                {
                    int count = 0;
                    foreach (TElement device in devices)
                    {
                        if (this.AddDevice(device, match))
                        {
                            count++;
                        }
                    }
                    return count;
                });
            }
            return result;
        }
        #endregion

        #region remove devices

        public int RemoveDevices(params TElement[] devices)
        {
            return this.RemoveDevices(devices as IEnumerable<TElement>);
        }

        public int RemoveDevices(IEnumerable<TElement> devices)
        {
            int result = 0;
            if( devices != null )
            {
                result = this.PerformWithLockWrite(() =>
                {
                    int count = 0;
                    foreach (TElement device in devices)
                    {
                        if (this.RemoveDevice(device))
                        {
                            count++;
                        }
                    }
                    return count;
                });
            }
            return result;
        }

        public virtual int RemoveDevices(Predicate<TElement> match)
        {
            int result = 0;
            if( match != null )
            {
                result = this.PerformWithLockWrite(() =>
                {
                    int count = 0;
                    TElement[] removeDevices = this.EnumDevices(match);
                    if (removeDevices != null && removeDevices.Length > 0)
                    {
                        count = this.RemoveDevices(removeDevices);
                    }
                    return count;
                });
            }
            return result;
        }

        #endregion

        #region swap devices
        public void SwapDevices(TElement originDevice, Predicate<TElement> newMatch, params TElement[] newDevices)
        {
            this.SwapDevices(originDevice, newDevices, newMatch);
        }

        public void SwapDevices(TElement originDevice, IEnumerable<TElement> newDevices, Predicate<TElement> newMatch = null)
        {
            this.SwapDevices(new TElement[] { originDevice }, newDevices, newMatch);
        }

        public void SwapDevices(TElement[] originDevices, Predicate<TElement> newMatch, params TElement[] newDevices)
        {
            this.SwapDevices(originDevices as IEnumerable<TElement>, newDevices, newMatch);
        }

        public virtual void SwapDevices(IEnumerable<TElement> originDevices, IEnumerable<TElement> newDevices, Predicate<TElement> newMatch = null)
        {
            if( newDevices != null )
            {
                List<TElement> matchedNewDevices = ((newMatch == null) ? newDevices.ToList() : newDevices.ToList().FindAll(newMatch));
                if( matchedNewDevices != null && matchedNewDevices.Count > 0 )
                {
                    TElement[] removeDevices = ((originDevices != null) ? originDevices.Except(matchedNewDevices).ToArray() : null);
                    this.PerformWithLockWrite(() =>
                        {
                            this.RemoveDevices(removeDevices);
                            this.AddDevices(matchedNewDevices.ToArray());
                        });
                }
                else
                {
                    this.RemoveDevices(originDevices);
                }
            }
            else
            {
                this.RemoveDevices(originDevices);
            }
        }
        #endregion
        #endregion

        #region wait
        public bool WaitUntil(int timeoutMilliseconds, Func<bool> condition = null, int waitMilliseconds = RWLock.DefaultLockReadWaitMilliseconds)
        {
            return this.DeviceRWLock.WaitUntil(timeoutMilliseconds, condition, waitMilliseconds);
        }
        #endregion
    }
}
