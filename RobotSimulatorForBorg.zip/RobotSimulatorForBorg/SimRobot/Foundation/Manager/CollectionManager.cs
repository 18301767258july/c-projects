﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Pegatron.Foundation
{
    public abstract class CollectionManager<TCollection, TElement> : EnumManager<TCollection, TElement>
        where TCollection : ICollection, new()
    {
        #region override
        protected override int InnerDevicesCount
        {
            get
            {
                return this.Devices.Count;
            }
        }
        #endregion
    }

    public class TCollectionManager<TCollection, TElement> : EnumManager<TCollection, TElement>
        where TCollection : ICollection<TElement>, new()
    {
        #region properties
        public virtual bool IsReadOnly
        {
            get
            {
                return this.Devices.IsReadOnly;
            }
        }
        #endregion

        #region override functions
        protected override int InnerDevicesCount
        {
            get
            {
                return this.Devices.Count;
            }
        }

        protected override bool InnerAddDevice(TElement device)
        {
            this.Devices.Add(device);
            return true;
        }

        protected override bool InnerRemoveDevice(TElement device)
        {
            return this.Devices.Remove(device);
        }

        protected override void InnerClearDevices()
        {
            this.Devices.Clear();
        }

        protected override bool InnerContainsDevice(TElement device)
        {
            return this.Devices.Contains(device);
        }
        #endregion
    }
}
