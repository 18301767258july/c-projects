﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Pegatron.Foundation
{
    public class DictionaryManager<TCollection, TKey, TValue> : TCollectionManager<TCollection, KeyValuePair<TKey, TValue>>
        where TCollection : IDictionary<TKey, TValue>, new()
    {
        #region properties
        public virtual TValue this[TKey key]
        {
            get
            {
                return this.GetValueByKey(key);
            }
            set
            {
                this.SetValueByKey(key, value);
            }
        }

        public ICollection<TKey> Keys
        {
            get
            {
                return this.PerformWithLockRead(() => this.Devices.Keys);
            }
        }

        public ICollection<TValue> Values
        {
            get
            {
                return this.PerformWithLockRead(() => this.Devices.Values);
            }
        }
        #endregion

        #region override functions

        protected override bool InnerAddDevice(KeyValuePair<TKey, TValue> device)
        {
            return this.InnerAddKeyValue(device.Key, device.Value);
        }

        protected override bool InnerRemoveDevice(KeyValuePair<TKey, TValue> device)
        {
            bool result = false;
            if( this.InnerContainsDevice(device) )
            {
                result = this.InnerRemoveByKey(device.Key);
            }
            return result;
        }

        protected override void InnerClearDevices()
        {
            this.Devices.Clear();
        }

        protected override bool InnerContainsDevice(KeyValuePair<TKey, TValue> device)
        {
            bool result = false;
            TValue outValue = default(TValue);
            if( this.InnerGetValueByKey(device.Key, ref outValue) && outValue.Equals(device.Value) )
            {
                result = true;
            }
            return result;
        }
        #endregion

        #region new functions
        protected virtual bool InnerContainsKey(TKey key)
        {
            bool result = false;
            if( key != null )
            {
                result = this.Devices.ContainsKey(key);
            }
            return result;
        }

        protected virtual TValue InnerGetValueByKey(TKey key, TValue defaultValue = default(TValue))
        {
            TValue result = defaultValue;
            this.InnerGetValueByKey(key, ref result);
            return result;
        }

        protected virtual bool InnerGetValueByKey(TKey key, ref TValue value)
        {
            bool result = false;
            if (this.InnerContainsKey(key))
            {
                value = this.Devices[key];
                result = true;
            }
            return result;
        }

        protected virtual bool InnerSetValueByKey(TKey key, TValue value)
        {
            this.Devices[key] = value;
            return true;
        }

        protected virtual bool InnerAddKeyValue(TKey key, TValue value)
        {
            bool result = false;
            if (!this.InnerContainsKey(key))
            {
                this.Devices.Add(key, value);
                result = true;
            }
            return result;
        }

        protected virtual bool InnerRemoveByKey(TKey key)
        {
            bool result = false;
            if (this.InnerContainsKey(key))
            {
                this.Devices.Remove(key);
                result = true;
            }
            return result;
        }

        public virtual TValue GetValueByKey(TKey key, TValue defaultValue = default(TValue))
        {
            return this.PerformWithLockRead(() => this.InnerGetValueByKey(key, defaultValue));
        }

        public virtual bool SetValueByKey(TKey key, TValue value)
        {
            return this.PerformWithLockWrite(() =>
                {
                    if (this.InnerContainsKey(key))
                    {
                        return this.InnerSetValueByKey(key, value);
                    }
                    else
                    {
                        return this.InnerAddKeyValue(key, value);
                    }
                });
        }

        public virtual bool AddKeyValue(TKey key, TValue value)
        {
            return this.PerformWithLockWrite(() => this.InnerAddKeyValue(key, value));
        }

        public virtual bool RemoveByKey(TKey key)
        {
            return this.PerformWithLockWrite(() => this.InnerRemoveByKey(key));
        }

        public virtual bool ContainsKey(TKey key)
        {
            return this.PerformWithLockRead(() => this.InnerContainsKey(key));
        }
        #endregion

        #region perform on keys
        public void PerformOnKeys(Action<TKey> action, Predicate<TKey> match = null)
        {
            if (action != null)
            {
                this.PerformWithLockRead(() =>
                {
                    foreach (TKey key in this.Devices.Keys)
                    {
                        if (match == null || match.Invoke(key))
                        {
                            action.Invoke(key);
                        }
                    }
                });
            }
        }

        public List<TKey> PerformOnKeys(Predicate<TKey> match)
        {
            return this.PerformOnKeys(match, key => key);
        }

        public List<T> PerformOnKeys<T>(Predicate<TKey> match, Func<TKey, T> convertor)
        {
            List<T> result = new List<T>();
            this.PerformOnKeys(key => result.Add(convertor.Invoke(key)), match);
            return (result != null && result.Count > 0) ? result : null;
        }

        public TKey PerformOnKeysUntil(Predicate<TKey> condition, TKey defaultValue = default(TKey))
        {
            return this.PerformWithLockRead(() =>
            {
                TKey result = defaultValue;
                if (condition != null)
                {
                    foreach (TKey key in this.Devices.Keys)
                    {
                        if (condition.Invoke(key))
                        {
                            result = key;
                            break;
                        }
                    }
                }
                return result;
            }
                );
        }
        #endregion

        #region perform on values
        public void PerformOnValues(Action<TValue> action, Predicate<TValue> match = null)
        {
            if (action != null)
            {
                this.PerformWithLockRead(() =>
                {
                    foreach (TValue value in this.Devices.Values)
                    {
                        if (match == null || match.Invoke(value))
                        {
                            action.Invoke(value);
                        }
                    }
                });
            }
        }

        public TValue[] PerformOnValues(Predicate<TValue> match)
        {
            return this.PerformOnValues(match, value => value);
        }

        public T[] PerformOnValues<T>(Predicate<TValue> match, Func<TValue, T> convertor)
        {
            List<T> result = new List<T>();
            this.PerformOnValues(value => result.Add(convertor.Invoke(value)), match);
            return (result != null && result.Count > 0) ? result.ToArray() : null;
        }

        public TValue PerformOnValuesUntil(Predicate<TValue> condition, TValue defaultValue = default(TValue))
        {
            return this.PerformWithLockRead(() =>
            {
                TValue result = defaultValue;
                if (condition != null)
                {
                    foreach (TValue value in this.Devices.Values)
                    {
                        if (condition.Invoke(value))
                        {
                            result = value;
                            break;
                        }
                    }
                }
                return result;
            }
                );
        }
        #endregion
    }

    public class DictionaryManager<TKey, TValue> : DictionaryManager<Dictionary<TKey, TValue>, TKey, TValue>
    {
        #region new functions
        protected virtual bool InnerContainsValue(TValue value)
        {
            return this.Devices.ContainsValue(value);
        }
        public virtual bool ContainsValue(TValue value)
        {
            return this.PerformWithLockRead(() => this.InnerContainsValue(value));
        }
        #endregion
    }
}
