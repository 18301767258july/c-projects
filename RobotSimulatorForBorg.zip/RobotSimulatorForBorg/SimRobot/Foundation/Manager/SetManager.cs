﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Pegatron.Foundation
{
    public class SetManager<TCollection, TElement> : TCollectionManager<TCollection, TElement>
        where TCollection : ISet<TElement>, new()
    {
        #region override functions
        protected override bool InnerAddDevice(TElement device)
        {
            return this.Devices.Add(device);
        }
        #endregion
    }
}
