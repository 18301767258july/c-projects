﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Pegatron.Foundation
{
    public class HashTableManager<TKey, TValue> : DictionaryEntryManager<Hashtable, TKey, TValue>
    {
        #region new functions
        protected virtual bool InnerContainsValue(TValue value)
        {
            return this.Devices.ContainsValue(value);
        }
        public virtual bool ContainsValue(TValue value)
        {
            return this.PerformWithLockRead(() => this.InnerContainsValue(value));
        }
        #endregion
    }
}
