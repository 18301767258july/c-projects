﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    class LoggingLevel
    {
        public int Level
        {
            get;
            set;
        }

        public string[] Types
        {
            get;
            set;
        }

        public LoggingLevel(int level, params string[] types)
        {
            this.Level = level;
            this.Types = types;
        }
    }
}
