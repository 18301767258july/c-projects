﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

namespace Pegatron.Foundation
{
    public class LoggingCenter : DictionaryManager<string, LoggingQueue>, IEnable
    {
        #region fields
        protected object mLockObj = new object();

        public const string LogUpdateNotification = "LogUpdateNotification";

        public static string DefaultKey = "Default";
        
        public static string ExceptionKey = "Exeception";

        public static string ErrorKey = "Error";

        protected static LoggingCenter mDefaultCenter = new LoggingCenter();
        #endregion

        #region propertry
        public static LoggingCenter DefaultCenter
        {
            get
            {
                return mDefaultCenter;
            }
        }

        public bool Enabled
        {
            get;
            set;
        }
        #endregion

        #region Constructor
        /// <summary>
        /// protected Constructor to be singleton
        /// </summary>
        protected LoggingCenter()
        {
            string defaultFolder = System.IO.Path.Combine(FileLogger.LogsFolder, LoggingCenter.DefaultKey);
            string exceptionFolder = System.IO.Path.Combine(FileLogger.LogsFolder, LoggingCenter.ExceptionKey);
            string errorFolder = System.IO.Path.Combine(FileLogger.LogsFolder, LoggingCenter.ErrorKey);
            this.AddLogging(
                LoggingCenter.DefaultKey,
                System.IO.Path.Combine(defaultFolder, (FileLogger.GetDateTimeWithShift() + FileLogger.FileNameInnerConnector + LoggingCenter.DefaultKey + Logger.FileExtension)),
                false
                );
            this.AddLogging(
                LoggingCenter.ExceptionKey,
                System.IO.Path.Combine(exceptionFolder, (FileLogger.GetDateTimeWithShift() + FileLogger.FileNameInnerConnector + LoggingCenter.ExceptionKey + Logger.FileExtension)),
                false
                );
            this.AddLogging(
                LoggingCenter.ErrorKey,
                System.IO.Path.Combine(errorFolder, (FileLogger.GetDateTimeWithShift() + FileLogger.FileNameInnerConnector + LoggingCenter.ErrorKey + Logger.FileExtension)),
                false
                );
        }

        #endregion

        #region functions
        public bool AddLogging(string loggingThreadKey, string filePath, bool autoStart = true)
        {
            LoggingQueue queue = new LoggingQueue(loggingThreadKey, filePath);//for exception logging
            if (autoStart) queue.AsyncExec();
            return this.SetValueByKey(loggingThreadKey, queue);
        }

        public void StartLogging(string loggingThreadKey)
        {
            LoggingQueue queue = this.GetValueByKey(loggingThreadKey);
            if (queue != null)
            {
                queue.AsyncExec();
            }
        }

        public void StopLogging(string loggingThreadKey)
        {
            LoggingQueue queue = this.GetValueByKey(loggingThreadKey);
            if (queue != null)
            {
                queue.PurgeStarted = true;
                queue.WaitUntilEmpty();
                queue.StopExec();
            }
        }

        public void ReqeustToExitLogging(string loggingThreadKey)
        {
            LoggingQueue queue = this.GetValueByKey(loggingThreadKey);
            if (queue != null)
            {
                queue.PurgeStarted = true;
                queue.WaitUntilEmpty();
                queue.ExitRequested = true;
            }
        }

        public void StartLogging()
        {
            this.PerformOnValues(queue =>
            {
                if (!queue.Running)
                {
                    queue.AsyncExec();
                }
            });
        }

        public void StopLogging()
        {
            this.PerformOnValues(queue =>
            {
                queue.PurgeStarted = true;
                queue.WaitUntilEmpty();
                queue.StopExec();
            });
        }

        public void ReqeustToExitLogging()
        {
            this.PerformOnValues(queue =>
                {
                    queue.PurgeStarted = true;
                    queue.WaitUntilEmpty();
                    queue.ExitRequested = true;
                });
        }

        public bool DefaultLogging(
            string message,
            object sender = null,
            ELogType logType = ELogType.Information,
            bool autoPrefix = true,
            bool consoleEnabled = false,
            bool autoLineFeed = true,
            bool notificationEnabled = true
            )
        {
            return this.Logging(TimeCounter.Now, message, null, sender, logType, autoPrefix, consoleEnabled, autoLineFeed, notificationEnabled, LoggingCenter.DefaultKey);
        }

        public bool DefaultLogging(
            DateTime time,
            string message,
            object sender = null,
            ELogType logType = ELogType.Information,
            bool autoPrefix = true,
            bool consoleEnabled = false,
            bool autoLineFeed = true,
            bool notificationEnabled = true
            )
        {
            return this.Logging(time, message, null, sender, logType, autoPrefix, consoleEnabled, autoLineFeed, notificationEnabled, LoggingCenter.DefaultKey);
        }

        public bool ErrorLogging(
            string message,
            object sender = null,
            ELogType logType = ELogType.Error,
            bool autoPrefix = true,
            bool consoleEnabled = false,
            bool autoLineFeed = true,
            bool notificationEnabled = true
            )
        {
            return this.Logging(TimeCounter.Now, message, null, sender, logType, autoPrefix, consoleEnabled, autoLineFeed, notificationEnabled, LoggingCenter.ErrorKey);
        }

        public bool ErrorLogging(
            DateTime time,
            string message,
            object sender = null,
            ELogType logType = ELogType.Error,
            bool autoPrefix = true,
            bool consoleEnabled = false,
            bool autoLineFeed = true,
            bool notificationEnabled = true
            )
        {
            return this.Logging(time, message, null, sender, logType, autoPrefix, consoleEnabled, autoLineFeed, notificationEnabled, LoggingCenter.ErrorKey);
        }

        public bool ExceptionLogging(
            Exception exception,
            object sender = null
            )
        {
            return this.ExceptionLogging(TimeCounter.Now, exception, sender);
        }

        public bool ExceptionLogging(
            DateTime time,
            Exception exception,
            object sender = null
            )
        {
            return this.ExceptionLogging(time, exception.ToString(), sender);
        }

        public bool ExceptionLogging(
            DateTime time,
            string message,
            object sender = null
            )
        {
            return this.Logging(time, message, null, sender, ELogType.Error, true, true, true, true, LoggingCenter.ExceptionKey);
        }

        public bool Logging(
            DateTime time,
            string message,
            string filePath = null,
            object sender = null,
            ELogType logType = ELogType.Information,
            bool autoPrefix = true,
            bool consoleEnabled = false,
            bool autoLineFeed = true,
            bool notificationEnabled = true,
            string category = null
            )
        {
            return this.Logging(new LoggingInfo(time, message, filePath, sender, logType, autoPrefix, consoleEnabled, autoLineFeed, notificationEnabled, category));
        }

        public bool Logging(
            string message,
            string filePath,
            object sender = null,
            ELogType logType = ELogType.Information,
            bool autoPrefix = true,
            bool consoleEnabled = false,
            bool autoLineFeed = true,
            bool notificationEnabled = true,
            string category = null
            )
        {
            return this.Logging(new LoggingInfo(TimeCounter.Now, message, filePath, sender, logType, autoPrefix, consoleEnabled, autoLineFeed, notificationEnabled, category));
        }

        public bool Logging(LoggingInfo loggingInfo)
        {
            bool result = false;
            if (this.Enabled && loggingInfo != null)
            {
                LoggingInfo backupLoggingInfo = new LoggingInfo(loggingInfo.Time, 
                    loggingInfo.Message,
                    loggingInfo.FilePath,
                    loggingInfo.Sender,
                    loggingInfo.LogType,
                    loggingInfo.AutoPrefix,
                    loggingInfo.ConsoleEnabled,
                    loggingInfo.AutoLineFeed,
                    loggingInfo.NotificationEnabled,
                    loggingInfo.Category);
                if (backupLoggingInfo.NotificationEnabled && !(backupLoggingInfo.Sender is NotificationCenter))
                {
                    NotificationCenter.DefaultCenter.PostNotification(backupLoggingInfo.Sender, LoggingCenter.LogUpdateNotification, this, backupLoggingInfo);
                }


                LoggingQueue queue = string.IsNullOrEmpty(loggingInfo.FilePath) 
                    ? null 
                    : this.PerformOnValuesUntil(value => loggingInfo.FilePath == value.FilePath);
                string loggingThreadKey = Utility.ToString(loggingInfo.FilePath, Utility.ToString(loggingInfo.Category, LoggingCenter.DefaultKey));
                if (queue == null && !string.IsNullOrEmpty(loggingThreadKey))
                {
                    queue = this.GetValueByKey(loggingThreadKey);
                }
                if (queue != null)
                {
                    result = queue.ReceivedMessage(loggingInfo.Sender, loggingInfo);
                }
                else
                {
                    lock (this.mLockObj)
                    {
                        string loggingThreadName = Utility.ToString(
                                (loggingInfo.FilePath != null ? System.IO.Path.GetFileNameWithoutExtension(loggingInfo.FilePath) : null),
                                Utility.ToString(loggingInfo.Category, LoggingCenter.DefaultKey)
                                );
                        queue = new LoggingQueue(loggingThreadName);
                        queue.AsyncExec();
                        this.SetValueByKey(loggingThreadKey, queue);
                        result = queue.ReceivedMessage(loggingInfo.Sender, loggingInfo);
                    }
                }
            }
            return result;
        }
        #endregion
    }
}
