﻿using System;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Threading;

namespace Pegatron.Foundation
{
    /// <summary>
    /// ConsoleLogger class contains some static functions for logging
    /// </summary>
    public class ConsoleLogger
    {
        #region property
        public static bool Enabled
        {
            get;
            set;
        }

        public static bool AutoPrefixEnabled
        {
            get;
            set;
        }

        public static bool TimeStampEnabled
        {
            get;
            set;
        }
        #endregion

        #region functions
        /// <summary>
        /// flush buffer, write data to listeners
        /// </summary>
        public static void Flush()
        {
            try
            {
                Trace.Flush();
            }
            catch (Exception ex)
            {
                ATSException.Throw(ex);
            }
            finally
            {
            }
        }

        /// <summary>
        /// flush buffer,clear listeners and close listeners
        /// </summary>
        public static void Close()
        {
            try
            {
                ConsoleLogger.Flush();
                Trace.Listeners.Clear();
                Trace.Close();
            }
            catch (Exception ex)
            {
                ATSException.Throw(ex);
            }
            finally
            {
            }
        }


        /// <summary>
        /// add listener
        /// </summary>
        /// <param name="traceListener">TextWriterTraceListener object</param>
        /// <returns></returns>
        public static bool AddTraceListener(TraceListener traceListener)
        {
            bool result = false;
            if (traceListener != null)
            {
                try
                {
                    result = Trace.Listeners.Add(traceListener) >= 0;
                }
                catch (Exception ex)
                {
                    result = false;
                    ATSException.Throw(ex);
                }
                finally
                {
                }
            }
            return result;
        }

        /// <summary>
        /// Add listener by file
        /// </summary>
        /// <param name="filePath">file path</param>
        /// <returns></returns>
        public static bool AddTraceListenerByFile(string filePath)
        {
            bool result = false;
            if (filePath != null)
            {
                try
                {
                    string folderPath = System.IO.Path.GetDirectoryName(filePath);
                    if (!string.IsNullOrEmpty(folderPath))
                    {
                        if (!Directory.Exists(folderPath))
                        {
                            Directory.CreateDirectory(folderPath);
                        }
                        result = ConsoleLogger.AddTraceListener(new TextWriterTraceListener(filePath));
                    }
                }
                catch (Exception ex)
                {
                    result = false;
                    ATSException.Throw(ex);
                }
                finally
                {
                }
            }
            return result;
        }


        /// <summary>
        /// Add System.Console.Out listener
        /// </summary>
        public static bool AddConsoleOutListener()
        {
            return ConsoleLogger.AddTraceListener(new TextWriterTraceListener(System.Console.Out));
        }
        
        /// <summary>
        /// logging message
        /// </summary>
        /// <param name="message">main content of message</param>
        /// <param name="category">category string</param>
        /// <param name="sender">who send this message</param>
        public static void TraceLog(string message, string category, object sender = null)
        {
            try
            {
                Trace.WriteIf(ConsoleLogger.Enabled, ConsoleLogger.CreateTraceMessage(message, sender), category);
            }
            catch (Exception ex)
            {
                ATSException.Throw(ex);
            }
            finally
            {
            }
        }

        public static void TraceLog(string keyMsg, ELogType logType, object sender = null)
        {
            switch( logType )
            {
                case ELogType.Error:
                    ConsoleLogger.TraceError(keyMsg, sender);
                    break;
                case ELogType.Warnning:
                    ConsoleLogger.TraceWarning(keyMsg, sender);
                    break;
                case ELogType.Information:
                default:
                    ConsoleLogger.TraceInfo(keyMsg, sender);
                    break;
            }
        }

        /// <summary>
        /// logging info message
        /// </summary>
        /// <param name="message">main content of message</param>
        /// <param name="sender">who send this message</param>
        public static void TraceInfo(string message, object sender = null)
        {
            try
            {
                if (ConsoleLogger.Enabled)
                {
                    Trace.TraceInformation(ConsoleLogger.CreateTraceMessage(message, sender));
                }
            }
            catch (Exception ex)
            {
                ATSException.Throw(ex);
            }
            finally
            {
            }
        }

        /// <summary>
        /// logging error message
        /// </summary>
        /// <param name="message">main content of message</param>
        /// <param name="sender">who send this message</param>
        public static void TraceError(string message, object sender = null)
        {
            try
            {
                if (ConsoleLogger.Enabled)
                {
                    Trace.TraceError(ConsoleLogger.CreateTraceMessage(message, sender));
                }
            }
            catch (Exception ex)
            {
                ATSException.Throw(ex);
            }
            finally
            {
            }

        }

        /// <summary>
        /// logging warnning message
        /// </summary>
        /// <param name="message">main content of message</param>
        /// <param name="sender">who send this message</param>
        public static void TraceWarning(string message, object sender = null)
        {
            try
            {
                if (ConsoleLogger.Enabled)
                {
                    Trace.TraceWarning(ConsoleLogger.CreateTraceMessage(message, sender));
                }
            }
            catch (Exception ex)
            {
                ATSException.Throw(ex);
            }
            finally
            {
            }
        }

        /// <summary>
        /// create final message to be output
        /// </summary>
        /// <param name="message">original message</param>
        /// <param name="sender">who send this message</param>
        /// <returns>return final message to be output</returns>
        public static string CreateTraceMessage(string message, object sender)
        {
            if (ConsoleLogger.AutoPrefixEnabled)
            {
                string senderInfo = Utility.CreateTag("Sender", Utility.ToString(sender, string.Empty));
                string threadInfo = Utility.CreateTag("Thread", Thread.CurrentThread.Name, Thread.CurrentThread.ManagedThreadId);
                if (ConsoleLogger.TimeStampEnabled)
                {
                    string timeStamp = Utility.CreateTag(Utility.GetNowTimeString());
                    return timeStamp + senderInfo + threadInfo + Utility.ToString(message, string.Empty);
                }
                else
                {
                    return senderInfo + threadInfo + Utility.ToString(message, string.Empty);
                }
            }
            else
            {
                return Utility.ToString(message, string.Empty);
            }
        }
        #endregion
    }
}
