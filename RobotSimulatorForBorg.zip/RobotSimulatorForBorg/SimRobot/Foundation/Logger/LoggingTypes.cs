﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    class LoggingTypes
    {
        public const string Info        = @"Info";

        public const string Error       = @"Error";

        public const string Warnning    = @"Warnning";

        public const string Debug       = @"Debug";
    }
}
