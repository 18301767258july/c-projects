﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    class LoggingInfoFormatter
    {
        public const string LogTimeFormatKey        = "%T%";
        public const string LogTypeFormatKey        = "%t%";
        public const string LogSenderFormatKey      = "%S%";
        public const string LogMessageFormatKey     = "%m%";
        public const string LogLineFeedFormatKey    = "%n%";
        public const string LogCarriageReturnFormatKey = "%r";
        public const string DefaultLogFormat        = "[%T%][%t][%S%]%m%%n%";
        public const string DefaultLogTimeFormat    = "yyyy-MM-dd HH:mm:ss.fff";

        public string LogFormat
        {
            get;
            set;
        }

        public string TimeFormat
        {
            get;
            set;
        }

        public LoggingInfoFormatter(string logFormat, string dateFormat)
        {
            this.LogFormat = logFormat;
            this.TimeFormat = dateFormat;
        }

        public string ToStringForLoggingInfo(LoggingInfo loggingInfo)
        {
            string result = string.Empty;
            if (this.LogFormat != null)
            {
                string timeFormat = (this.TimeFormat != null ? this.TimeFormat : LoggingInfoFormatter.DefaultLogTimeFormat);
                string tempResult = this.LogFormat;
                tempResult = tempResult.Replace(LoggingInfoFormatter.LogLineFeedFormatKey, "\n");
                tempResult = tempResult.Replace(LoggingInfoFormatter.LogCarriageReturnFormatKey, "\r");
                tempResult = tempResult.Replace(LoggingInfoFormatter.LogTimeFormatKey, Utility.GetTimeString(loggingInfo.Time, timeFormat));
                tempResult = tempResult.Replace(LoggingInfoFormatter.LogTypeFormatKey, loggingInfo.LogType.ToString());
                tempResult = tempResult.Replace(LoggingInfoFormatter.LogSenderFormatKey, loggingInfo.Sender.ToString());
                tempResult = tempResult.Replace(LoggingInfoFormatter.LogMessageFormatKey, loggingInfo.Message);
                result = tempResult;
            }
            else
            {
                result = loggingInfo.Message;
            }
            return result;
        }
    }
}
