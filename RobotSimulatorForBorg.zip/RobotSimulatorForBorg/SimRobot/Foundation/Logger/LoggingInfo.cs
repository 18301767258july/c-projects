﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    public class NewLoggingInfo
    {
        public object Sender
        {
            get;
            protected set;
        }

        public DateTime Time
        {
            get;
            set;
        }

        public string Category
        {
            get;
            set;
        }

        public string Type
        {
            get;
            protected set;
        }

        public string Message
        {
            get;
            set;
        }

        public NewLoggingInfo(
            DateTime time,
            string type,
            object sender,
            string category,
            string message
            )
        {
            this.Time = time;
            this.Type = type;
            this.Sender = sender;
            this.Category = category;
            this.Message = message;
        }
    }
}
