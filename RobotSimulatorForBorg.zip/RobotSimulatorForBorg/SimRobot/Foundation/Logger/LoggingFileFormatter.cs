﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    class LoggingFileFormatter
    {
        public const string LogCategoryFormatKey = "%C%";
        public const string LogTimeFormatKey = "%T%";
        public const string DefaultFileNameFormat = "%C-%T.log";
        public const string DefaultFileNameDateFormat = "yyyy-MM-dd";

        public string FileNameFormat
        {
            get;
            set;
        }

        public string DateFormat
        {
            get;
            set;
        }

        public LoggingFileFormatter(string fileNameFormat, string dateFormat)
        {
            this.FileNameFormat = fileNameFormat;
            this.DateFormat = dateFormat;
        }
        
        public string ToStringForLoggingFileAttribute(LoggingFileAttribute fileAttribute)
        {
            string result = string.Empty;
            if (fileAttribute.LogFolder != null)
            {
                string dateFormat = (this.DateFormat != null ? this.DateFormat : LoggingFileFormatter.DefaultFileNameDateFormat);
                string tempResult = (this.FileNameFormat != null ? this.FileNameFormat : LoggingFileFormatter.DefaultFileNameFormat);
                tempResult = tempResult.Replace(LoggingFileFormatter.LogTimeFormatKey, Utility.GetTimeString(TimeCounter.Now, dateFormat));
                tempResult = tempResult.Replace(LoggingFileFormatter.LogCategoryFormatKey, fileAttribute.Category);
                result = System.IO.Path.Combine(fileAttribute.LogFolder, tempResult);
            }
            return result;
        }
    }
}
