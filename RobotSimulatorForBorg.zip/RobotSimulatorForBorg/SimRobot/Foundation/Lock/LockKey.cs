﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Pegatron.Foundation
{
    public class LockKey : INameDefined
    {
        #region properties
        public Action<LockKey, object, bool> KeyEnterLeaveHandler
        {
            get;
            set;
        }

        public string Name
        {
            get;
            protected set;
        }

        public string Type
        {
            get;
            set;
        }

        public object Key
        {
            get;
            protected set;
        }

        public object Locker
        {
            get;
            protected set;
        }

        public Type LockerType
        {
            get;
            protected set;
        }

        public int LockCount
        {
            get;
            protected set;
        }
        #endregion

        #region Constructor
        public LockKey()
            : this(new object())
        {
        }

        public LockKey(object key, string name = null)
        {
            this.Key = key;
            this.Locker = null;
            this.LockCount = 0;
            this.Name = !string.IsNullOrEmpty(name) ? name : string.Empty;
        }
        #endregion

        public bool IsAvailable(object requester)
        {
            bool result = false;
            if( this.Key != null )
            {
                lock( this.Key )
                {
                    result = ( this.Locker != null && this.Locker == requester ) ||
                        ( this.Locker == null && this.IsValidRequstType(requester) );
                }
            }
            return result;
        }

        public bool IsValidRequstType(object requester)
        {
            return this.LockerType == null || ( requester != null && this.LockerType.IsAssignableFrom(requester.GetType()) );
        }

        public bool IsValidRequstType(Type type)
        {
            return this.LockerType == null || ( type != null && this.LockerType.IsAssignableFrom(type) );
        }

        public bool IsOccupiedBy(object locker)
        {
            bool result = false;
            if( this.Key != null && locker != null )
            {
                lock( this.Key )
                {
                    result = ( this.Locker == locker );
                }
            }
            return result;
        }

        public bool TryLock(object requester)
        {
            bool result = false;
            if( this.Key != null && requester != null )
            {
                lock( this.Key )
                {
                    if( this.IsAvailable(requester) )
                    {
                        this.Locker = requester;
                        this.LockCount++;
                        result = true;
                    }
                    if( result && this.LockCount == 1 && this.KeyEnterLeaveHandler != null )
                    {
                        this.KeyEnterLeaveHandler(this, requester, true);
                    }
                }
            }
            return result;
        }

        public bool Lock(object requester, double timeout = -1, int waitMilliseconds = 10/*ms*/)
        {
            bool result = false;
            if( this.Key != null && requester != null )
            {
                lock( this.Key )
                {
                    TimeCounter timeCounter = new TimeCounter();
                    timeCounter.Start();
                    while( !( result = this.TryLock(requester) ) &&
                        ( timeout < 0 || timeCounter.LastRunningTime < timeout ) )
                    {
                        this.WaitKey(waitMilliseconds);
                    }
                }
            }
            return result;
        }

        public bool Unlock(object requester, bool fullUnlock = false)
        {
            bool result = false;
            if( this.Key != null && requester != null )
            {
                lock( this.Key )
                {
                    if( this.Locker == requester )
                    {
                        if( fullUnlock )
                        {
                            this.LockCount = 0;
                        }
                        else
                        {
                            this.LockCount--;
                        }
                        if( this.LockCount <= 0 )
                        {
                            this.Locker = null;
                            this.LockCount = 0;
                        }
                        this.SignalKey();
                        result = true;
                    }
                    if( result && this.LockCount == 0 && this.KeyEnterLeaveHandler != null )
                    {
                        this.KeyEnterLeaveHandler(this, requester, false);
                    }
                }
            }
            return result;
        }

        protected void SignalKey()
        {
            if( this.Key != null )
            {
                lock( this.Key )
                {
                    Monitor.Pulse(this.Key);
                }
            }
        }

        protected void WaitKey(int milliseconds)
        {
            if( this.Key != null )
            {
                Monitor.Wait(this.Key, milliseconds);
            }
        }
    }
}
