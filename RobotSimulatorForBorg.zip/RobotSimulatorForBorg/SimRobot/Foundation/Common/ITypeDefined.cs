﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Pegatron.Foundation
{
    /// <summary>
    /// 
    /// </summary>
    /// <author>
    /// Brice_Du
    /// </author>
    public interface ITypeDefined<T>
    {
        T Type
        {
            get;
        }
    }
}
