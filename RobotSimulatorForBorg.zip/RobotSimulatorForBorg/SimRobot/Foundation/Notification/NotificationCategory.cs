﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    public class NotificationCategory : INameDefined, ITypeDefined<object>
    {
        public string Name
        {
            get;
            protected set;
        }

        public object Type
        {
            get;
            protected set;
        }

        public NotificationCategory(
            string name,
            object type
            )
        {
            this.Name = name;
            this.Type = type;
        }

        public override bool Equals(object obj)
        {
            NotificationCategory category = obj as NotificationCategory;
            return category != null && this.Name == category.Name
                && ((this.Type == null && category.Type == null) || (this.Type != null && category.Type != null && this.Type.Equals(category.Type)));
        }

        public override int GetHashCode()
        {
            if (this.Type == null)
            {
                return this.Name == null ? base.GetHashCode() : this.Name.GetHashCode();
            }
            else
            {
                return this.Name == null ? this.Type.GetHashCode() : (this.Name.GetHashCode() + this.Type.GetHashCode());
            }
        }

        public override string ToString()
        {
            return Utility.CreateTag("Name", this.Name) + Utility.CreateTag("Type", this.Type);
        }
    }
}
