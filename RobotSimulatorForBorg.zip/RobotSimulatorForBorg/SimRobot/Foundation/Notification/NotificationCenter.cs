﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    public delegate void NotificationHandler(object sender, Notification notification);

    public delegate void NotificationPostHandler(object sender, Notification notification);

    public class NotificationCenter : DictionaryManager<NotificationCategory, DictionaryManager<object, ObserverNotificationQueue>>
    {
        #region fields

        protected static NotificationCenter mDefaultCenter = new NotificationCenter();

        protected IDGenerator mIDGenerator = new IDGenerator();

        #endregion

        #region propertry

        public static NotificationCenter DefaultCenter
        {
            get
            {
                return mDefaultCenter;
            }
        }

        #endregion

        #region functions

        public bool AddObserver(object observer, string notificationName, NotificationHandler method, object notificationType = null)
        {
            NotificationCategory category = new NotificationCategory(notificationName, notificationType);
            return this.PerformWithLockWrite(() =>
                {
                    DictionaryManager<object, ObserverNotificationQueue> observerDict = this[category];
                    if (observerDict != null)
                    {
                        ObserverNotificationQueue observerNotificationQueue = observerDict[observer];
                        if (observerNotificationQueue != null)
                        {
                            observerNotificationQueue.NotificationEventOccured += method;
                        }
                        else
                        {
                            observerDict[observer] = new ObserverNotificationQueue(method, this.NotificationHandlingDone);
                        }
                    }
                    else
                    {
                        observerDict = new DictionaryManager<object, ObserverNotificationQueue>();
                        observerDict[observer] = new ObserverNotificationQueue(method, this.NotificationHandlingDone);
                        this[category] = observerDict;
                    }
                    return true;
                });
        }

        public bool RemoveObserver(object observer)
        {
            return this.RemoveDevices(notificationDict => notificationDict.Value != null && notificationDict.Value.ContainsKey(observer)) > 0;
        }

        public bool RemoveObserver(object observer, string notificationName, object notificationType = null)
        {
            NotificationCategory category = new NotificationCategory(notificationName, notificationType);
            return this.PerformWithLockWrite(() =>
            {
                DictionaryManager<object, ObserverNotificationQueue> observerDict = this[category];
                if (observerDict != null)
                {
                    return observerDict.RemoveByKey(observer);
                }
                else
                {
                    return false;
                }
            });
        }

        public bool RemoveObserver(object observer, string notificationName, NotificationHandler method, object notificationType = null)
        {
            NotificationCategory category = new NotificationCategory(notificationName, notificationType);
            return this.PerformWithLockWrite(() =>
            {
                bool innerResult = false;
                DictionaryManager<object, ObserverNotificationQueue> observerDict = this[category];
                if (observerDict != null)
                {
                    ObserverNotificationQueue observerNotificationQueue = observerDict[observer];
                    if (observerNotificationQueue != null)
                    {
                        observerNotificationQueue.NotificationEventOccured -= method;
                        innerResult = true;
                    }
                }
                return innerResult;
            });
        }

        public bool PostNotification(Notification notification, bool waitDone = false)
        {
            bool result = this.PerformWithLockRead(() =>
            {
                bool innerResult = false;
                DictionaryManager<object, ObserverNotificationQueue> observerDict = this[notification.Category];
                if (observerDict != null)
                {
                    innerResult = true;
                    observerDict.PerformOnValues(observerNotificationQueue =>
                        {
                            if(!observerNotificationQueue.Run(notification))
                            {
                                innerResult = false;
                            }
                            if (waitDone)
                            {
                                if (!observerNotificationQueue.WaitUntil(System.Threading.Timeout.Infinite, () => !observerNotificationQueue.ContainsDevice(notification)))
                                {
                                    innerResult = false;
                                }
                            }
                        });
                    
                }
                return innerResult;
            });
            if (!result)
            {
                this.NotificationHandlingDone(this, notification);
            }
            //this.DebugLogging((result ? "Passed" : "Failed") + " to send " + notification.ToString());
            return result;
        }

        public bool PostNotification(object sender, string notificationName, object userInfo, object type, bool waitDone = false)
        {
            return this.PostNotification(new Notification(this.mIDGenerator.GenerateID(), notificationName, sender, userInfo, type), waitDone);
        }

        public bool PostNotification(object sender, string notificationName, object userInfo = null, bool waitDone = false)
        {
            return this.PostNotification(new Notification(this.mIDGenerator.GenerateID(), notificationName, sender, userInfo), waitDone);
        }

        public void NotificationHandlingDone(object sender, Notification notification)
        {
            this.mIDGenerator.ReleaseID(notification.ID);
        }

        #region logging
        /// <summary>
        /// output message to console / file
        /// </summary>
        /// <param name="message">message to be output</param>
        /// <param name="addPrefixFlag">enable/disable timestamp prefix</param>
        public void DebugLogging(string message, string folder = "Notification", string file = "Notification.log")
        {
            if (message != null)
            {
                Logger.Logging(
                    message,
                    System.IO.Path.Combine(FileLogger.LogsFolder, folder, (FileLogger.GetDateTimeWithShift() + FileLogger.FileNameInnerConnector + file)),
                    this
                    );
            }
        }
        #endregion

        #endregion
    }
}
