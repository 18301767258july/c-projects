﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    public class Notification : EventArgs, IIDDefined, INameDefined, ITypeDefined<object>
    {
        public NotificationCategory Category
        {
            get;
            protected set;
        }

        public int ID
        {
            get;
            set;
        }

        public string Name
        {
            get
            {
                return this.Category != null ? this.Category.Name : null;
            }
        }

        public object Type
        {
            get
            {
                return this.Category != null ? this.Category.Type : null;
            }
        }

        public object Sender
        {
            get;
            protected set;
        }

        public object UserInfo
        {
            get;
            protected set;
        }

        public Notification(
            string name,
            object sender,
            object userInfo,
            object type = null
            ):this(-1, name, sender, userInfo, type)
        {
            this.ID = this.GetHashCode();
        }

        public Notification(
            int id,
            string name,
            object sender,
            object userInfo,
            object type = null
            )
        {
            this.ID = id;
            this.Category = new NotificationCategory(name, type);
            this.Sender = sender;
            this.UserInfo = userInfo;
        }

        #region ToString
        public override string ToString()
        {
            return Utility.CreateTag(
                    this.GetType().FullName,
                    Utility.CreateTag("ID", this.ID) + Utility.CreateTag(this.Category) + Utility.CreateTag("Sender", this.Sender.GetType()) + Utility.CreateTag("UserInfo", this.UserInfo)
                    );
        }
        #endregion
    }
}
