﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Pegatron.Foundation
{
    public class ObserverNotificationQueue : QueueManager<Notification>
    {
        protected event NotificationHandler mNotificationEventOccured;

        protected event NotificationPostHandler mNotificationPostHandler;

        protected ManualResetEventSlim mAsyncFinishedEvent = new ManualResetEventSlim(true);

        protected object mLockObj = new object();

        public event NotificationHandler NotificationEventOccured
        {
            add
            {
                lock (this.mLockObj)
                {
                    mNotificationEventOccured += value;
                }
            }
            remove
            {
                lock (this.mLockObj)
                {
                    mNotificationEventOccured -= value;
                }
            }
        }

        public event NotificationPostHandler NotificationPostHandler
        {
            add
            {
                lock (this.mLockObj)
                {
                    mNotificationPostHandler += value;
                }
            }
            remove
            {
                lock (this.mLockObj)
                {
                    mNotificationPostHandler -= value;
                }
            }
        }

        protected IAsyncResult AsyncResult
        {
            get;
            set;
        }

        public ObserverNotificationQueue(NotificationHandler handler, NotificationPostHandler postHandler)
        {
            this.NotificationEventOccured += handler;
            this.NotificationPostHandler += postHandler;
        }

        public void RunCallBack(IAsyncResult ar)
        {
            Notification finishedNotification = this.Dequeue();
            mAsyncFinishedEvent.Set();
            if (this.mNotificationPostHandler != null)
            {
                this.mNotificationPostHandler.Invoke(this, finishedNotification);
            }
            this.Run(null);
        }

        public bool Run(Notification newNotification = null)
        {
            bool result = false;
            bool enqueue = true;
            if (newNotification != null)
            {
                enqueue = this.Enqueue(newNotification);
            }
            if (enqueue)
            {
                lock (this.mLockObj)
                {
                    if ((this.AsyncResult == null || this.AsyncResult.IsCompleted) && mAsyncFinishedEvent.IsSet)
                    {
                        Notification nextNotification = this.Peek();
                        if (nextNotification != null && this.mNotificationEventOccured != null)
                        {
                            mAsyncFinishedEvent.Reset();
                            this.AsyncResult = this.mNotificationEventOccured.BeginInvoke(nextNotification.Sender, nextNotification, new AsyncCallback(this.RunCallBack), null);
                            if (this.AsyncResult != null)
                            {
                                result = true;
                            }
                            else
                            {
                                mAsyncFinishedEvent.Set();
                            }
                        }
                    }
                    else
                    {
                        result = true;
                    }
                }
            }
            return result;
        }
    }
}
