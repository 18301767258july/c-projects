using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Reflection;
using System.Net;
using System.Management;
using Pegatron.Foundation;
using Pegatron.Foundation.Xml;

namespace Pegatron.Foundation
{
    /// <summary>
    /// network relative funtions
    /// </summary>
    /// <author>
    /// Brice_Du
    /// </author>
    public class Network
    {
        public static string GetIPByPrefix(string ipPrefix)
        {
            string result = null;
            try
            {
                if (!string.IsNullOrEmpty(ipPrefix))
                {
                    if (ipPrefix == IPAddress.Any.ToString())
                    {
                        result = IPAddress.Any.ToString();
                    }
                    else if (ipPrefix == IPAddress.Broadcast.ToString())
                    {
                        result = IPAddress.Broadcast.ToString();
                    }
                    else if (ipPrefix == IPAddress.Loopback.ToString())
                    {
                        result = IPAddress.Loopback.ToString();
                    }
                    else if (ipPrefix == IPAddress.None.ToString())
                    {
                        result = IPAddress.None.ToString();
                    }
                    else
                    {
                        IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
                        if (addressList != null && addressList.Length > 0)
                        {
                            for (int index = 0; index < addressList.Length; index++)
                            {
                                if (addressList[index].ToString().StartsWith(ipPrefix))
                                {
                                    result = addressList[index].ToString();
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            catch (System.Exception)
            {
            }
            return result;
        }

        public static string GetIPSubnet(string ip)
        {
            string result = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(ip))
                {
                    if (ip == IPAddress.Any.ToString())
                    {
                        result = IPAddress.None.ToString();
                    }
                    else if (ip == IPAddress.Broadcast.ToString())
                    {
                        result = IPAddress.None.ToString();
                    }
                    else if (ip == IPAddress.Loopback.ToString())
                    {
                        result = IPAddress.None.ToString();
                    }
                    else if (ip == IPAddress.None.ToString())
                    {
                        result = IPAddress.None.ToString();
                    }
                    else
                    {
                        ManagementClass mc = new ManagementClass("Win32_NetworkAdapterConfiguration");
                        ManagementObjectCollection nics = mc.GetInstances();
                        foreach (ManagementObject nic in nics)
                        {
                            if (Convert.ToBoolean(nic["ipEnabled"]) && (nic["IPAddress"] as String[])[0] == ip)
                            {
                                result = (nic["IPSubnet"] as String[])[0];
                                break;
                            }
                        }
                    }
                }
            }
            catch (System.Exception)
            {
            }
            return result;
        }

        public static string GetBroadcastIPAddress(string ip)
        {
            string result = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(ip))
                {
                    if (ip == IPAddress.Any.ToString())
                    {
                        result = IPAddress.Any.ToString();
                    }
                    else if (ip == IPAddress.Broadcast.ToString())
                    {
                        result = IPAddress.Broadcast.ToString();
                    }
                    else if (ip == IPAddress.Loopback.ToString())
                    {
                        result = IPAddress.Loopback.ToString();
                    }
                    else if (ip == IPAddress.None.ToString())
                    {
                        result = IPAddress.None.ToString();
                    }
                    else
                    {
                        IPAddress ipAddress = null;
                        string ipSubnet = Network.GetIPSubnet(ip);
                        if (!string.IsNullOrEmpty(ipSubnet))
                        {
                            byte[] ipBytes = IPAddress.Parse(ip).GetAddressBytes();
                            byte[] subnetBytes = IPAddress.Parse(ipSubnet).GetAddressBytes();
                            for (int index = 0; index < ipBytes.Length; index++)
                            {
                                ipBytes[index] = (byte)((~subnetBytes[index]) | ipBytes[index]);
                            }
                            ipAddress = new IPAddress(ipBytes);
                            result = ipAddress.ToString();
                        }
                    }
                }
            }
            catch (System.Exception)
            {
            }
            return result;
        }

        public static string CreateEndPoint(string ip, int port)
        {
            return ((ip == null ? "invalid ip" : ip) + ":" + port);
        }

        public static string GetIPByEndPoint(EndPoint endPoint)
        {
            string result = null;
            if (endPoint != null)
            {
                string clientEndPoint = endPoint.ToString();
                if (!string.IsNullOrEmpty(clientEndPoint))
                {
                    int index = clientEndPoint.IndexOf(':');
                    if (index >= 0)
                    {
                        result = clientEndPoint.Substring(0, index);
                    }
                }
            }
            return result;
        }

        public static int GetPortByEndPoint(EndPoint endPoint)
        {
            int result = -1;
            if (endPoint != null)
            {
                string clientEndPoint = endPoint.ToString();
                if (!string.IsNullOrEmpty(clientEndPoint))
                {
                    int index = clientEndPoint.IndexOf(':');
                    if (index >= 0)
                    {
                        result = int.Parse(clientEndPoint.Substring(index + 1));
                    }
                }
            }
            return result;
        }
    }
}
