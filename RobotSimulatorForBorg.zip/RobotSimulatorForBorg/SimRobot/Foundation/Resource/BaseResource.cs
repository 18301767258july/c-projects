﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    class BaseResource : IResource
    {
        protected List<object> mOwners = new List<object>();

        public string Type
        {
            get;
            protected set;
        }

        public string Name
        {
            get;
            protected set;
        }

        public object[] Owners
        {
            get
            {
                return this.mOwners.ToArray();
            }
        }

        public int MaximumCount
        {
            get;
            protected set;
        }

        public int AvailableCount
        {
            get
            {
                return this.MaximumCount - this.mOwners.Count;
            }
        }

        public BaseResource(string type, string name, int maximumCount)
        {
            this.Type = type;
            this.Name = name;
            this.MaximumCount = maximumCount;
        }

        public bool SetOccupied(object owner)
        {
            bool result = false;
            if (owner != null && this.AvailableCount > 0)
            {
                if (!this.mOwners.Contains(owner))
                {
                    this.mOwners.Add(owner);
                }
                result = true;
            }
            return result;
        }

        public bool Release(object owner)
        {
            bool result = false;
            if (owner != null && this.mOwners.Count > 0)
            {
                result = this.mOwners.Remove(owner);
            }
            return result;
        }
    }
}
