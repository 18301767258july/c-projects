﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    public interface IResource:ITypeDefined<string>, INameDefined
    {
        object[] Owners
        {
            get;
        }

        int MaximumCount
        {
            get;
        }

        int AvailableCount
        {
            get;
        }

        bool SetOccupied(object owner);

        bool Release(object owner);
    }
}
