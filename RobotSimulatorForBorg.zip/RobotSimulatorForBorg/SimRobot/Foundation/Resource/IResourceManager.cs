﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    public interface IResourceRequestor
    {
        void OnResourceAvailable(IResourceManager resourceManager, params IResource[] resources);
        void OnResourceNotAvailable(IResourceManager resourceManager, params IResource[] resources);
    }

    public interface IResourceManager
    {
        bool RequestResource(IResourceRequestor requestor, string type);
        bool RequestResource(IResourceRequestor requestor, string type, string name);
        bool OccupyResource(object owner, IResource resource);
        bool ReleaseResource(object owner, IResource resource);
    }
}
