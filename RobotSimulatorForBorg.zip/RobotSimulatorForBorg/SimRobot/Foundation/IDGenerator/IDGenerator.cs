﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pegatron.Foundation
{
    public class IDGenerator
    {
        public const int InvalidID = -1;
        public const int DefaultMinID = 1;
        public const int DefaultMaxID = 30000;
        protected List<int> mUsingIDs = new List<int>();
        protected List<int> mReleasedIDs = new List<int>();

        public int MaxID
        {
            get;
            protected set;
        }

        public int MinID
        {
            get;
            protected set;
        }

        protected int NextAvailableID
        {
            get;
            set;
        }

        public IDGenerator(int minID = IDGenerator.DefaultMinID, int maxID = IDGenerator.DefaultMaxID)
        {
            this.MinID = minID;
            this.MaxID = maxID;
            this.ReleaseAll();
        }

        public int GenerateID()
        {
            int result = IDGenerator.InvalidID;
            lock (this.mUsingIDs)
            {
                if (this.NextAvailableID <= this.MaxID && !this.mUsingIDs.Contains(this.NextAvailableID))
                {
                    result = this.NextAvailableID;
                }
                else
                {
                    if (mUsingIDs.Count > 0)
                    {
                        int maxUsingIDPlus = this.mUsingIDs.Max() + 1;
                        if (maxUsingIDPlus <= this.MaxID)
                        {
                            result = maxUsingIDPlus;
                        }
                        else
                        {
                            if (mReleasedIDs.Count > 0)
                            {
                                result = mReleasedIDs.Min();
                            }
                            else
                            {
                                if (mUsingIDs.Count <= this.MaxID - this.MinID)
                                {
                                    for (int id = this.MinID; id <= this.MaxID; id++)
                                    {
                                        if (!this.mUsingIDs.Contains(id))
                                        {
                                            result = id;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        result = this.MinID;
                    }
                }
                if (result != IDGenerator.InvalidID)
                {
                    this.NextAvailableID = result + 1;
                    if (!this.mUsingIDs.Contains(result))
                    {
                        this.mUsingIDs.Add(result);
                    }
                    if (this.mReleasedIDs.Contains(result))
                    {
                        this.mReleasedIDs.Remove(result);
                    }
                }
            }
            return result;
        }

        public void ReleaseID(int id)
        {
            lock (this.mUsingIDs)
            {
                if (this.mUsingIDs.Contains(id))
                {
                    this.mUsingIDs.Remove(id);
                    if (!this.mReleasedIDs.Contains(id))
                    {
                        this.mReleasedIDs.Add(id);
                    }
                }
            }
        }

        public void ReleaseAll()
        {
            lock (this.mUsingIDs)
            {
                this.mUsingIDs.Clear();
                this.mReleasedIDs.Clear();
                this.NextAvailableID = this.MinID;
            }
        }
    }
}
