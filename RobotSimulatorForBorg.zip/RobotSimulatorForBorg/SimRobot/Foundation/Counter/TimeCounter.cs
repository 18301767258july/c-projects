using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections;
using System.Runtime.InteropServices;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Diagnostics;
using System.Reflection;

namespace Pegatron.Foundation
{
    /// <summary>
    /// TimeCounter to count time
    /// </summary>
    public class TimeCounter
    {
        #region fields
        protected object mLockObject = new object();
        static protected DateTime? mNow;
        static protected RWLock mNowLockObj = new RWLock();
        #endregion

        #region property
        static public DateTime Now
        {
            get
            {
                DateTime result = DateTime.Now;
                if (TimeCounter.IsSimulation)
                {
                    if (mNow == null)
                    {
                        mNowLockObj.LockWrite();
                        try
                        {
                            if (mNow == null)
                            {
                                mNow = DateTime.Now;
                            }
                        }
                        finally
                        {
                            mNowLockObj.UnlockWrite();
                        }
                    }
                    if (mNowLockObj.LockRead())
                    {
                        try
                        {
                            result = (DateTime)mNow;
                        }
                        finally
                        {
                            mNowLockObj.UnlockRead();
                        }
                    }
                }
                else
                {
                    result = DateTime.Now;
                }
                return result;
            }
        }

        static public bool IsSimulation
        {
            get;
            set;
        }

        public bool ForceUsingSysTime
        {
            get;
            protected set;
        }

        public DateTime NowTime
        {
            get
            {
                return this.ForceUsingSysTime ? DateTime.Now : TimeCounter.Now;
            }
        }


        public double RunningTimeExceptLastRunning
        {
            get;
            protected set;
        }

        public double LastCycleTime
        {
            get;
            protected set;
        }

        public DateTime? FirstStartTime
        {
            get;
            protected set;
        }

        public DateTime? LastStartTime
        {
            get;
            set;
        }

        public DateTime? LastEndTime
        {
            get;
            set;
        }

        public DateTime? ResetTime
        {
            get;
            set;
        }

        public double LastRunningTime
        {
            get
            {
                double result = 0.0;
                lock (mLockObject)
                {
                    if (this.Running)
                    {
                        result = (this.NowTime - (DateTime)this.LastStartTime).TotalMilliseconds;
                    }
                    else if(this.Started && this.Stopped)
                    {
                        result = ((DateTime)this.LastEndTime - (DateTime)this.LastStartTime).TotalMilliseconds;
                    }
                }
                return result;
            }
        }
       
        public double LastFreeTime
        {
            get
            {
                double result = -1;//never started
                lock (mLockObject)
                {
                    result = this.LastTotalTime - this.LastRunningTime;
                }
                return result;
            }
        }

        public double TotalFreeTime
        {
            get
            {
                double result = -1;//never started
                lock (mLockObject)
                {
                    result = this.TotalTime - this.TotalRunningTime;
                }
                return result;
            }
        }

        public double LastTotalTime
        {
            get
            {
                double result = 0.0;
                lock (mLockObject)
                {
                    if (this.Started)
                    {
                        result = (this.NowTime - (DateTime)this.LastStartTime).TotalMilliseconds;
                    }
                    else if (this.ResetAlready)
                    {
                        result = (this.NowTime - (DateTime)this.ResetTime).TotalMilliseconds;
                    }
                }
                return result;
            }
        }

        public double TotalTime
        {
            get
            {
                double result = 0.0;
                lock (mLockObject)
                {
                    if(this.ResetAlready)
                    {
                        result = (this.NowTime - (DateTime)this.ResetTime).TotalMilliseconds;
                    }
                }
                return result;
            }
        }

        public double LifeTime
        {
            get
            {
                double result = 0.0;
                lock (mLockObject)
                {
                    if(!this.NeverStarted)
                    {
                        if (this.Stopped)
                        {
                            result = ((DateTime)this.LastEndTime - (DateTime)this.FirstStartTime).TotalMilliseconds;
                        }
                        else
                        {
                            result = (this.NowTime - (DateTime)this.FirstStartTime).TotalMilliseconds;
                        }
                    }
                }
                return result;
            }
        }

        public double TotalRunningTime
        {
            get
            {
                double result = 0.0;
                lock (mLockObject)
                {
                    if (this.Running)
                    {
                        result = this.RunningTimeExceptLastRunning + this.LastRunningTime;
                    }
                    else
                    {
                        result = this.RunningTimeExceptLastRunning;
                    }
                }
                return result;
            }
        }
        #endregion

        #region constructor
        /// <summary>
        /// TimeCounter class contructor, it will call Reset() function
        /// </summary>
        public TimeCounter()
            : this(true, true)
        {

        }
        public TimeCounter(bool forceUsingSysTime, bool reset = true)
        {
            this.ForceUsingSysTime = forceUsingSysTime;
            if (reset) this.Reset();
        }
        #endregion

        #region check
        /// <summary>
        /// Check if already reseted(reset time is not null) 
        /// </summary>
        /// <returns></returns>
        public bool ResetAlready
        {
            get
            {
                bool result = false;
                lock (mLockObject)
                {
                    result = (this.ResetTime != null);
                }
                return result;
            }
        }

        /// <summary>
        /// Check if never started(first start time is null)
        /// </summary>
        /// <returns></returns>
        public bool NeverStarted
        {
            get
            {
                bool result = false;
                lock (mLockObject)
                {
                    result = (this.FirstStartTime == null);
                }
                return result;
            }
        }

        /// <summary>
        /// Check if started for the last time(last start time is not null)
        /// </summary>
        /// <returns></returns>
        public bool Started
        {
            get
            {
                bool result = false;
                lock (mLockObject)
                {
                    result = this.LastStartTime != null;
                }
                return result;
            }
        }

        /// <summary>
        /// Check if stoped for the last time(IsStart() return true and last end time is not null)
        /// </summary>
        /// <returns></returns>
        public bool Stopped
        {
            get
            {
                bool result = false;
                lock (mLockObject)
                {
                    result = this.Started && (this.LastEndTime != null);
                }
                return result;
            }
        }

        /// <summary>
        /// Check if running for the last time(Started() return true and IsStoped() return false)
        /// </summary>
        /// <returns></returns>
        public bool Running
        {
            get
            {
                bool result = false;
                lock (mLockObject)
                {
                    result = this.Started && !this.Stopped;
                }
                return result;
            }
        }
        #endregion

        #region Reset/Start/Stop
        #region Reset
        /// <summary>
        /// reset the counter
        /// reset time will be assigned to current time
        /// first start time, last start time and last end time will be assign to null
        /// </summary>
        public void Reset()
        {
            lock (mLockObject)
            {
                this.RunningTimeExceptLastRunning = 0.0;
                this.LastCycleTime = 0.0;
                this.ResetTime = this.NowTime;
                this.FirstStartTime = null;
                this.LastStartTime = null;
                this.LastEndTime = null;
            }
        }
        #endregion

        #region Restart
        /// <summary>
        /// restart the counter
        /// stop counter first then start counter again
        /// </summary>
        /// <returns>the start result</returns>
        public bool Restart()
        {
            this.Stop();
            return this.Start();
        }
        #endregion

        #region Start
        /// <summary>
        /// start the counter, if the counter is still running will get false return
        /// if not reset, reset first
        /// last start time will be assigned to current time
        /// last end time will be assigned to null
        /// </summary>
        /// <returns>start result</returns>
        public bool Start()
        {
            bool result = false;
            lock (mLockObject)
            {
                if (!this.Running)
                {
                    if (!this.ResetAlready) this.Reset();
                    this.LastStartTime = this.NowTime;
                    this.LastEndTime = null;
                    if (this.FirstStartTime == null)
                    {
                        this.FirstStartTime = this.LastStartTime;
                    }
                }
            }
            return result;
        }
        #endregion

        #region Stop
        /// <summary>
        /// stop the running counter, if the counter is not running will get false return
        /// last end time will be assigned to current time
        /// </summary>
        /// <returns>stop result</returns>
        public bool Stop()
        {
            bool result = false;
            lock (mLockObject)
            {
                if (this.Running)
                {
                    this.LastEndTime = this.NowTime;
                    this.LastCycleTime = this.LastRunningTime;
                    this.RunningTimeExceptLastRunning += this.LastCycleTime;
                }
            }
            return result;
        }
        #endregion
        #endregion

        #region Update Now Time
        public static void UpdateNow(double elapsedTime)
        {
            if (TimeCounter.IsSimulation)
            {
                mNowLockObj.LockWrite();
                try
                {
                    if (mNow == null)
                    {
                        mNow = DateTime.Now;
                    }
                    mNow = ((DateTime)mNow).AddMilliseconds(elapsedTime);
                }
                finally
                {
                    mNowLockObj.UnlockWrite();
                }
            }
        }
        #endregion
    }
}
