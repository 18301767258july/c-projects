﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections;
using Pegatron.Foundation.Xml;

namespace Pegatron.Foundation
{
    public class MessageQueueManager<TMessage> : IMessageManager<TMessage>
    {
        public const int DefaultMessageWaitIntervalMilliseconds = 100;//ms

        protected QueueManager<TMessage> mWorkingQueue = new QueueManager<TMessage>();

        protected QueueManager<TMessage> mPendingQueue = new QueueManager<TMessage>();

        protected QueueManager<TMessage> WorkingQueue
        {
            get
            {
                return mWorkingQueue;
            }
        }

        protected QueueManager<TMessage> PendingQueue
        {
            get
            {
                return mPendingQueue;
            }
        }

        public virtual int MessageCount
        {
            get
            {
                return this.WorkingQueue.Count;
            }
        }

        public virtual bool MessagePurgeStarted
        {
            get;
            set;
        }

        #region message related functions

        protected void MovePendingMessagesToWorkingQueue()
        {
            this.PendingQueue.PerformWithLockWrite(() =>
            {
                TMessage[] pendingMessages = this.PendingQueue.EnumDevices();
                this.PendingQueue.ClearDevices();
                this.WorkingQueue.AddDevices(pendingMessages);
            });
        }

        /// <summary>
        /// get a message object from message list. default get the first one but we can get the one we want by overiding this virtual function
        /// </summary>
        /// <returns></returns>
        public virtual TMessage GetMessage()
        {
            return this.WorkingQueue.Dequeue();
        }

        public virtual bool WaitMessage(int timeoutMilliseconds, Func<bool> breakCondition)
        {
            return this.WorkingQueue.WaitUntil(timeoutMilliseconds, breakCondition, MessageQueueManager<TMessage>.DefaultMessageWaitIntervalMilliseconds);
        }

        public virtual bool AddMessage(TMessage message)
        {
            bool result = false;
            this.PendingQueue.PerformWithLockWrite(() =>
            {
                if (this.MessagePurgeStarted || this.PendingQueue.Count > 0)
                {
                    result = this.PendingQueue.AddDevice(message);
                }
                else
                {
                    result = this.WorkingQueue.AddDevice(message);
                }
            });
            return result;
        }

        public virtual bool RemoveMessage(TMessage message)
        {
            return this.WorkingQueue.RemoveDevice(message);
        }

        public virtual void ClearMessages()
        {
            this.WorkingQueue.ClearDevices();
            this.PendingQueue.ClearDevices();
        }

        public virtual TMessage[] EnumMessages()
        {
            return this.WorkingQueue.EnumDevices();
        }

        public virtual TMessage[] EnumMessages(Predicate<TMessage> condition)
        {
            return this.WorkingQueue.EnumDevices(condition);
        }
        #endregion
    }
}
