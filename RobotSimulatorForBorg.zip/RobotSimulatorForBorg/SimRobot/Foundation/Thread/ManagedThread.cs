﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Collections;
using Pegatron.Foundation.Xml;

namespace Pegatron.Foundation
{
    public interface IManagedThread : INameDefined, IIDDefined, IAsyncExec<object>
    {
        bool DebugEnabled
        {
            get;
            set;
        }

        bool IsBackground
        {
            get;
            set;
        }

        ThreadPriority Priority
        {
            get;
            set;
        }
    }

    public delegate IExitCode ManagedThreadBody(object args);

    public interface IManagedThreadDelegate
    {
        void OnManagedThreadStarting(ManagedThread managedThread);
        void OnManagedThreadCaughtException(ManagedThread managedThread, Exception exception);
        void OnManagedThreadExiting(ManagedThread managedThread, IExitCode exitCode);
    }

    public class ManagedThread : IManagedThread
    {
        public const int InvalidThreadId = -1;
        public const int DefaultStopWaitMilliseconds = 10000;//10s
        public const int DefaultAbortWaitMilliseconds = 5000;//5s

        /// <summary>
        /// Thread relative arguments
        /// </summary>
        protected Thread mThread = null;
        protected string mThreadName = null;
        protected bool mIsBackground = false;
        protected ThreadPriority mPriority = ThreadPriority.Normal;
        protected ManagedThreadBody mThreadBody = null;
        protected IManagedThreadDelegate mManagedThreadDelegate = null;
        protected IExitCode mExitCode = null;
        protected TimeCounter mRunTimeCounter = new TimeCounter();

        /// <summary>
        /// Lock and events
        /// </summary>
        protected RWLock mThreadRWLock = new RWLock();
        protected ManualResetEventSlim mStartedEvent = new ManualResetEventSlim(false);
        protected ManualResetEventSlim mFinishedEvent = new ManualResetEventSlim(false);
        protected ManualResetEventSlim mExitRequestedEvent = new ManualResetEventSlim(false);

        /// <summary>
        /// enabled debug or not
        /// </summary>
        public bool DebugEnabled
        {
            get;
            set;
        }

        /// <summary>
        /// Observer for Async executing
        /// </summary>
        public IAsyncExecCallback<object> Observer
        {
            get;
            protected set;
        }

        /// <summary>
        /// set / get the name of thread
        /// </summary>
        /// <returns></returns>
        public virtual string Name
        {
            get
            {
                return this.mThreadName;
            }
            set
            {
                this.PerformWithLockWrite(() =>
                {
                    if (!this.Running)
                    {
                        this.mThreadName = value;
                        if (this.mThread != null)
                        {
                            this.mThread.Name = this.mThreadName;
                        }
                    }
                });
            }
        }

        /// <summary>
        /// get the id of thread
        /// </summary>
        /// <returns></returns>
        public virtual int ID
        {
            get
            {
                return this.PerformWithLockRead(() => (this.mThread != null) ? this.mThread.ManagedThreadId : ManagedThread.InvalidThreadId);
            }
        }

        /// <summary>
        /// check if thread is running
        /// </summary>
        /// <returns></returns>
        public virtual bool Running
        {
            get
            {
                return this.PerformWithLockRead(() => (this.mStartedEvent.IsSet && !this.mFinishedEvent.IsSet));
            }
        }

        /// <summary>
        /// check if thread is finished
        /// </summary>
        /// <returns></returns>
        public virtual bool Finished
        {
            get
            {
                return this.PerformWithLockRead(() => (this.mStartedEvent.IsSet && this.mFinishedEvent.IsSet));
            }
        }

        /// <summary>
        /// thread last/current running time with milliseconds
        /// </summary>
        public double RunningTime
        {
            get
            {
                return this.mRunTimeCounter.LastRunningTime;
            }
        }

        /// <summary>
        /// thread total running time with milliseconds
        /// </summary>
        public double TotalRunningTime
        {
            get
            {
                return this.mRunTimeCounter.TotalRunningTime;
            }
        }

        /// <summary>
        /// check if exit requested
        /// </summary>
        /// <returns></returns>
        public virtual bool ExitRequested
        {
            get
            {
                return this.mExitRequestedEvent.IsSet;
            }
            set
            {
                //this set function may be done in the thread
                if (value)
                {
                    this.mExitRequestedEvent.Set();
                }
                else
                {
                    this.mExitRequestedEvent.Reset();
                }
            }
        }

        public virtual IExitCode FinishCode
        {
            get
            {
                return this.PerformWithLockRead(() =>
                {
                    if (this.Finished)
                    {
                        return this.mExitCode;
                    }
                    else
                    {
                        return null;
                    }
                });
            }
            protected set
            {
                this.mExitCode = value;
            }
        }

        /// <summary>
        /// set / get background properties
        /// </summary>
        /// <returns></returns>
        public bool IsBackground
        {
            get
            {
                return this.mIsBackground;
            }
            set
            {
                this.PerformWithLockWrite(() =>
                {
                    // only can be done when thread isn's started
                    if (!this.Running && !this.Finished)
                    {
                        this.mIsBackground = value;
                        if (this.mThread != null)
                        {
                            this.mThread.IsBackground = this.mIsBackground;
                        }
                    }
                });
            }
        }

        public ThreadPriority Priority
        {    
            get
            {
                return this.mPriority;
            }
            set
            {
                this.PerformWithLockWrite(() =>
                {
                    this.mPriority = value;
                    if (this.mThread != null)
                    {
                        this.mThread.Priority = this.mPriority;
                    }
                });
            }
        }

        public WaitHandle FinishedWaitHandle
        {
            get
            {
                return this.mFinishedEvent.WaitHandle;
            }
        }

        /// <summary>
        /// body function of thread
        /// </summary>
        public ManagedThreadBody ThreadBody
        {
            get
            {
                return this.mThreadBody;
            }
            set
            {
                this.PerformWithLockWrite(() =>
                {
                    if (!this.Running)
                    {
                        this.mThreadBody = value;
                    }
                });
            }
        }

        /// <summary>
        /// body function of thread
        /// </summary>
        public IManagedThreadDelegate ManagedThreadDelegate
        {
            get
            {
                return this.mManagedThreadDelegate;
            }
            set
            {
                this.PerformWithLockWrite(() =>
                {
                    if (!this.Running)
                    {
                        this.mManagedThreadDelegate = value;
                    }
                });
            }
        }


        /// <summary>
        /// thread lock for read & write
        /// </summary>
        protected RWLock ThreadRWLock
        {
            get
            {
                return this.mThreadRWLock;
            }
        }

        /// <summary>
        /// ManagedThread constructor
        /// </summary>
        /// <param name="name">thread name</param>
        /// <param name="threadBody">thread body function</param>
        /// <param name="isBackground">indicates thread is background or not</param>
        public ManagedThread(string name = null, ManagedThreadBody threadBody = null, bool isBackground = false)
        {
            this.Name = name;
            this.ThreadBody = threadBody;
            this.IsBackground = isBackground;
            this.DebugEnabled = false;
        }

        #region lock

        protected void PerformWithLockWrite(Action action)
        {
            this.ThreadRWLock.PerformWithLockWrite(action);
        }

        protected void PerformWithLockRead(Action action)
        {
            this.ThreadRWLock.PerformWithLockRead(action);
        }

        protected TResult PerformWithLockWrite<TResult>(Func<TResult> func, TResult defaultValue = default(TResult))
        {
            return this.ThreadRWLock.PerformWithLockWrite(func, defaultValue);
        }

        protected TResult PerformWithLockRead<TResult>(Func<TResult> func, TResult defaultValue = default(TResult))
        {
            return this.ThreadRWLock.PerformWithLockRead(func, defaultValue);
        }
        #endregion

        #region Start / Stop / Abort
        /// <summary>
        /// start thread
        /// </summary>
        /// <param name="observer">observer</param>
        /// <param name="args">thread start args</param>
        /// <returns>thread create and start result</returns>
        public virtual bool AsyncExec(IAsyncExecCallback<object> observer = null, object args = null)
        {
            return this.PerformWithLockWrite(() =>
            {
                bool result = false;
                if (!this.Running)
                {
                    //current isn't running, so we can start actually
                    try
                    {
                        this.mThread = new Thread(new ParameterizedThreadStart(this.Entry));
                        if (this.mThread != null)
                        {
                            //start preparing
                            this.Observer = observer;
                            this.FinishCode = null;
                            this.IsBackground = this.mIsBackground;
                            this.Priority = this.mPriority;
                            this.Name = string.IsNullOrEmpty(this.mThreadName) ? this.mThread.ManagedThreadId.ToString() : this.mThreadName;
                            this.ExitRequested = false;

                            //start thread
                            this.mFinishedEvent.Reset();
                            this.mRunTimeCounter.Restart();
                            this.mThread.Start(args);
                            this.mStartedEvent.Set();
                            result = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        //set to exception exit code
                        this.FinishCode = ExitCode.ExceptionExitCode(ex);
                        //start thread failed, reset data here
                        this.mThread = null;
                        this.mStartedEvent.Reset();
                        this.mRunTimeCounter.Stop();
                        this.mFinishedEvent.Set();
                        ATSException.Logging(ex);
                        result = false;
                    }
                }
                return result;
            });
        }

        /// <summary>
        /// stop running thread, wait until exit or timeout
        /// </summary>
        /// <param name="timeoutMilliseconds">time out to wait for thread exit</param>
        /// <returns>if thread exit then return true, or return false</returns>
        public virtual bool StopExec(int timeoutMilliseconds = ManagedThread.DefaultStopWaitMilliseconds)
        {
            this.ExitRequested = true;
            return this.WaitUntilExit(timeoutMilliseconds);
        }

        /// <summary>
        /// Abort running thread then stop thread, wait until exit or timeout
        /// </summary>
        /// <param name="timeoutMilliseconds">stop waitting time out(unit: ms)</param>
        /// <returns>stop result</returns>
        public virtual bool AbortExec(int timeoutMilliseconds = ManagedThread.DefaultAbortWaitMilliseconds)
        {
            this.PerformWithLockWrite(() =>
                {
                    if (this.Running)
                    {
                        try
                        {
                            if (mThread != null)
                            {
                                mThread.Abort();
                            }
                        }
                        catch (Exception ex)
                        {
                            ATSException.Logging(ex);
                        }
                    }
                });
            return this.StopExec(timeoutMilliseconds);
        }

        /// <summary>
        /// wait until async running to exit
        /// </summary>
        /// <param name="timeoutMilliseconds">wait timeout(units: ms)</param>
        /// <returns></returns>
        public virtual bool WaitUntilExit(int timeoutMilliseconds)
        {
            return this.PerformWithLockRead(() =>
            {
                if (this.Running)
                {
                    if (timeoutMilliseconds == System.Threading.Timeout.Infinite)
                    {
                        this.WaitUntilFinished();
                    }
                    else
                    {
                        this.WaitUntilFinished(timeoutMilliseconds);
                    }
                }
                return !this.Running;
            });
        }

        public void WaitUntilFinished()
        {
            this.mFinishedEvent.Wait();
        }

        public bool WaitUntilFinished(int timeoutMilliseconds)
        {
            return this.mFinishedEvent.Wait(timeoutMilliseconds);
        }

        public void WaitUntilExitRequested()
        {
            this.mExitRequestedEvent.Wait();
        }

        public bool WaitUntilExitRequested(int timeoutMilliseconds)
        {
            return this.mExitRequestedEvent.Wait(timeoutMilliseconds);
        }
        #endregion

        #region thread entry
        /// <summary>
        /// thread entry function with args
        /// </summary>
        /// <param name="args">args to start thread</param>
        private void Entry(object args)
        {
            try
            {
                this.DoWhileEnterEntry(args);
                this.RunThreadBody(args);
            }
            catch (Exception ex)
            {
                this.DoWhileCaughtException(ex);
            }
            finally
            {
                this.DoWhileExit(args);
            }
        }

        /// <summary>
        /// do something while enter entry function
        /// </summary>
        private void DoWhileEnterEntry(object args)
        {
            Logger.ThreadLogging(this, "thread starting...");
            this.FinishCode = null;
            if (this.ManagedThreadDelegate != null)
            {
                this.ManagedThreadDelegate.OnManagedThreadStarting(this);
            }
        }

        private void RunThreadBody(object args)
        {
            Logger.ThreadLogging(this, "thread running body function...");
            if (this.ThreadBody != null)
            {
                this.FinishCode = this.ThreadBody(args);
            }
        }

        /// <summary>
        /// do something when caught exception
        /// </summary>
        /// <param name="e">exception</param>
        private void DoWhileCaughtException(Exception ex)
        {
            Logger.ThreadLogging(this, "thread caught exception:" + ex.ToString());
            ATSException.Logging(ex, this);
            this.FinishCode = ExitCode.ExceptionExitCode(ex);
            if (this.ManagedThreadDelegate != null)
            {
                this.ManagedThreadDelegate.OnManagedThreadCaughtException(this, ex);
            }
        }

        /// <summary>
        /// do something before thread exit
        /// </summary>
        private void DoWhileExit(object args)
        {
            IExitCode exitCode = this.FinishCode;
            Logger.ThreadLogging(this, "thread exiting...");
            if (this.ManagedThreadDelegate != null)
            {
                this.ManagedThreadDelegate.OnManagedThreadExiting(this, exitCode);
            }
            this.mRunTimeCounter.Stop();
            this.mFinishedEvent.Set();
            Logger.ThreadLogging(this, "thread run time:" + this.RunningTime + "ms");
            if (this.Observer != null)
            {
                this.Observer.AsyncExecCallback(this, exitCode, args);
            }
        }
        #endregion
    }
}
