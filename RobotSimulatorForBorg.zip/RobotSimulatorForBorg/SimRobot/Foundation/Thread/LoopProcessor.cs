﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections;
using Pegatron.Foundation.Xml;

namespace Pegatron.Foundation
{
    public enum LoopProcessExitCode
    {
        Exception       = -1,
        Normal          = 0,
        Failed          = 1,
        Cancelled       = 2,
        Timeout         = 3,
        LoopFailed      = 4,
    }

    public interface ILoopProcessDelegate
    {
        IExitCode OnProcessorLoopFailed(LoopProcessor processor);
        IExitCode OnProcessorTimeout(LoopProcessor processor);
        IExitCode OnProcessorExitRequested(LoopProcessor processor);
    }

    public class LoopProcessor : ManagedThread
    {
        #region fields
        public const int DefaultLoopSleepMilliseconds = 100;//ms
        public const int ZeroLoopSleepMilliseconds = 0;//ms
        protected TimeCounter mCycleCounter = new TimeCounter();
        protected Func<object, bool> mLoopHandler = null;
        protected ILoopProcessDelegate mLoopDelegate = null;
        
        #endregion

        #region property

        public ILoopProcessDelegate LoopDelegate
        {
            get
            {
                return this.mLoopDelegate;
            }
            set
            {
                this.PerformWithLockWrite(() =>
                {
                    if (!this.Running)
                    {
                        this.mLoopDelegate = value;
                    }
                });
            }
        }

        public Func<object, bool> LoopHandler
        {
            get
            {
                return this.mLoopHandler;
            }
            set
            {
                this.PerformWithLockWrite(() =>
                {
                    if (!this.Running)
                    {

                        this.mLoopHandler = value;
                    }
                });
            }
        }

        public double? CycleTime
        {
            get
            {
                return this.mCycleCounter.LastCycleTime;
            }
        }

        public int LoopSleepMilliseconds
        {
            get;
            set;
        }

        public int TimeoutMilliseconds
        {
            get;
            set;
        }

        #endregion

        #region constructor & destructor
        public LoopProcessor()
            : this(null)
        {
        }

        public LoopProcessor(
            string name,
            int sleepMilliseconds = LoopProcessor.DefaultLoopSleepMilliseconds,
            bool isBackground = false,
            int timeoutMilliseconds = System.Threading.Timeout.Infinite,
            Func<object, bool> loopHandler = null)
            : base(name, null, isBackground)
        {
            
            this.LoopSleepMilliseconds = sleepMilliseconds;
            this.TimeoutMilliseconds = timeoutMilliseconds;
            this.ThreadBody = this.ThreadBodyEntry;
            this.LoopHandler = loopHandler;
        }

        #endregion

        #region entry
        /// <summary>
        /// thread body excute entry
        /// </summary>
        private IExitCode ThreadBodyEntry(object args)
        {
            IExitCode exitCode = null;
            while (true)
            {
                if (!this.CycleStart(args))
                {
                    exitCode = this.DoWhileLoopFailed();
                    break;
                }
                if (this.IsLoopTimeout())
                {
                    exitCode = this.DoWhileTimeout();
                    break;
                }
                if (this.ExitRequested)
                {
                    exitCode = this.DoWhileExitRequested();
                    break;
                }
            }
            return exitCode;
        }

        private bool CycleStart(object args)
        {
            bool result = false;
            this.mCycleCounter.Restart();
            //for loop
            if (this.LoopHandler != null)
            {
                if ((result = this.LoopHandler(args)))
                {
                    this.LoopSleep();
                }
            }
            this.mCycleCounter.Stop();
            Logger.ThreadLogging(this, "thread loop cycle time:" + this.CycleTime + "ms");
            return result;
        }

        /// <summary>
        /// do sleep 
        /// </summary>
        private void LoopSleep()
        {
            this.WaitUntilExitRequested(this.LoopSleepMilliseconds);
            //Thread.Sleep(sleepMilliseconds);
        }

        private bool IsLoopTimeout()
        {
            return this.TimeoutMilliseconds != System.Threading.Timeout.Infinite && this.RunningTime > this.TimeoutMilliseconds;
        }

        private IExitCode DoWhileLoopFailed()
        {
            IExitCode exitCode = ExitCode.CreateExitCode((int)LoopProcessExitCode.LoopFailed, "thread loop failed...");
            if (this.LoopDelegate != null)
            {
                IExitCode delegateExitCode = this.LoopDelegate.OnProcessorLoopFailed(this);
                if (delegateExitCode != null)
                {
                    exitCode = delegateExitCode;
                }
            }
            Logger.ThreadLogging(this, exitCode.Description);
            return exitCode;
        }

        /// <summary>
        /// do something while timeout
        /// </summary>
        private IExitCode DoWhileTimeout()
        {
            IExitCode exitCode = ExitCode.CreateExitCode((int)LoopProcessExitCode.Timeout, "thread loop timeout...");
            if (this.LoopDelegate != null)
            {
                IExitCode delegateExitCode = this.LoopDelegate.OnProcessorTimeout(this); 
                if (delegateExitCode != null)
                {
                    exitCode = delegateExitCode;
                }
            }
            Logger.ThreadLogging(this, exitCode.Description);
            return exitCode;
        }

        /// <summary>
        /// do something while timeout
        /// </summary>
        private IExitCode DoWhileExitRequested()
        {
            IExitCode exitCode = ExitCode.CreateExitCode((int)LoopProcessExitCode.Normal, "thread loop exit requested...");
            if (this.LoopDelegate != null)
            {
                IExitCode delegateExitCode = this.LoopDelegate.OnProcessorExitRequested(this);
                if (delegateExitCode != null)
                {
                    exitCode = delegateExitCode;
                }
            }
            Logger.ThreadLogging(this, exitCode.Description);
            return exitCode;
        }
        #endregion
    }
}
