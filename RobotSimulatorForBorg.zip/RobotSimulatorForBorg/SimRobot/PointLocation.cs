﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace SimRobot
{
    public class PointLocation
    {
        public PointLocation()
        { }
        public string Name
        { get; set; }
        public int Address
        { get; set; }
    }
    public class CollectionPointLocation
    {
        [XmlArrayItem("PointLocation")]
        public PointLocation[] Buffers { get; set; }

    }
}
