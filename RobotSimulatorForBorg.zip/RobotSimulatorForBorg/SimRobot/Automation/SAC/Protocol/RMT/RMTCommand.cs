﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Pegatron.Foundation;
using Pegatron.Foundation.Xml;
using Pegatron.Communication;
using Pegatron.Communication.Socket;

namespace Pegatron.Automation.SAC.Protocol.RMT
{
    public class RMTCommand : EventArgs
    {
        public const int InvalidCommandID                 = -1;
        public const int UnsolicitedCommandID             = 0;
        public const int DefaultCommandExpectedReplyCount = 1;
        public const string DefaultCommandParamSeperator  = ",";
        public const string DefaultCommandTerminator      = "\r";
        public const string DefaultCommandIDFormat        = "D5";

        protected ManualResetEventSlim mWaitReplyFinishedEvent = new ManualResetEventSlim(false);

        protected ManualResetEventSlim mWaitReplyInterruptedEvent = new ManualResetEventSlim(false);

        public WaitHandle ReplyFinishedWaitHandle
        {
            get
            {
                return this.mWaitReplyFinishedEvent.WaitHandle;
            }
        }

        public WaitHandle ReplyInterruptedWaitHandle
        {
            get
            {
                return this.mWaitReplyInterruptedEvent.WaitHandle;
            }
        }

        public string RawData
        {
            get;
            protected set;
        }

        public int CommandID
        {
            get;
            protected set;
        }

        public string CommandName
        {
            get;
            protected set;
        }

        public int ExpectedReplyCount
        {
            get;
            protected set;
        }

        public bool ReplyFinished
        {
            get
            {
                return this.mWaitReplyFinishedEvent.IsSet;
            }
        }

        public bool ReplyInterrupted
        {
            get
            {
                return this.mWaitReplyInterruptedEvent.IsSet;
            }
        }

        public string Seperator
        {
            get;
            protected set;
        }

        public string Terminator
        {
            get;
            protected set;
        }

        public string IDFormat
        {
            get;
            protected set;
        }

        public string[] Args
        {
            get;
            protected set;
        }

        public DateTime Time
        {
            get;
            set;
        }

        public RMTCommand()
            : this((string)null)
        {
        }

        public RMTCommand(int id, string commandName, params string[] args)
            : this(id, commandName, RMTCommand.DefaultCommandExpectedReplyCount, args)
        {
        }

        public RMTCommand(int id, string commandName, int expectedReplyCount, params string[] args)
            : this(id, commandName, expectedReplyCount, TimeCounter.Now, args)
        {
        }

        public RMTCommand(int id, string commandName, int expectedReplyCount, DateTime time, params string[] args)
            : this(id, commandName, expectedReplyCount, time, RMTCommand.DefaultCommandParamSeperator, RMTCommand.DefaultCommandTerminator, RMTCommand.DefaultCommandIDFormat, args)
        {
        }

        public RMTCommand(int id, string commandName, int expectedReplyCount, DateTime time, string seperator, string terminator, string idFormat, params string[] args)
        {
            this.CommandID = id;
            this.CommandName = commandName;
            this.ExpectedReplyCount = expectedReplyCount;
            this.Time = time;
            this.Seperator = seperator;
            this.Terminator = terminator;
            this.IDFormat = idFormat;
            this.Args = args;
            this.CreateRawData();
        }

        protected void CreateRawData()
        {
            this.RawData = this.CommandID.ToString(this.IDFormat);
            this.RawData += (this.Seperator + (this.CommandName == null ? string.Empty : this.CommandName));
            if (this.Args != null && this.Args.Length > 0)
            {
                foreach (string arg in this.Args)
                {
                    this.RawData += (this.Seperator + (arg == null ? string.Empty : arg));
                }
            }
            this.RawData += this.Terminator;
        }

        public RMTCommand(string rawData)
            : this(rawData, TimeCounter.Now)
        {
        }

        public RMTCommand(string rawData, DateTime time)
            : this(rawData, time, RMTCommand.DefaultCommandParamSeperator, RMTCommand.DefaultCommandTerminator, RMTCommand.DefaultCommandIDFormat)
        {
        }

        public RMTCommand(string rawData, string seperator, string terminator, string idFormat)
            : this(rawData, TimeCounter.Now, seperator, terminator, idFormat)
        {
        }

        public RMTCommand(string rawData, DateTime time, string seperator, string terminator, string idFormat)
        {
            this.CommandID = RMTCommand.InvalidCommandID;
            this.ExpectedReplyCount = 0;
            this.Time = time;
            this.Seperator = seperator;
            this.Terminator = terminator;
            this.IDFormat = idFormat;
            this.ParseRawData(rawData);
        }

        public bool ParseRawData(string rawData)
        {
            object error = null;
            return this.ParseRawData(rawData, ref error);
        }

        public bool ParseRawData(string rawData, ref object error)
        {
            bool result = false;
            try
            {
                this.RawData = rawData;
                if (!string.IsNullOrEmpty(rawData))
                {
                    if (rawData.EndsWith(this.Terminator))
                    {
                        rawData = rawData.Substring(0, rawData.Length - this.Terminator.Length);
                    }
                    if (!string.IsNullOrEmpty(rawData))
                    {
                        string[] datas = rawData.Split(new string[] { this.Seperator }, StringSplitOptions.None);
                        if (datas != null)
                        {
                            List<string> dataList = datas.ToList();
                            if (dataList.Count > 0)
                            {
                                this.CommandID = Int32.Parse(dataList[0]);
                            }
                            if (dataList.Count > 1)
                            {
                                this.CommandName = dataList[1];
                            }
                            if (dataList.Count > 2)
                            {
                                dataList.RemoveRange(0, 2);
                                if (dataList.Count > 0)
                                {
                                    this.Args = dataList.ToArray();
                                }
                            }
                            result = true;
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                error = ex;
                result = false;
            }
            return result;
        }

        public string GetArgument(int index)
        {
            string result = null;
            if (this.Args != null && index < this.Args.Length)
            {
                result = this.Args[index];
            }
            return result;
        }

        public override string ToString()
        {
            XDict dict = new XDict();
            dict.Add("ID", this.CommandID);
            dict.Add("Command", this.CommandName);
            dict.Add("Args", this.Args);
            return dict.ToJsonString();
        }

        public void SetReplyFinished()
        {
            this.mWaitReplyFinishedEvent.Set();
        }

        public void SetReplyInterrupted()
        {
            this.mWaitReplyInterruptedEvent.Set();
        }

        public static RMTCommand[] CreateCommands(string rawData, DateTime time, ref string incompleteMessage)
        {
            return RMTCommand.CreateCommands(rawData, time, RMTCommand.DefaultCommandParamSeperator, RMTCommand.DefaultCommandTerminator, RMTCommand.DefaultCommandIDFormat, ref incompleteMessage);
        }

        public static RMTCommand[] CreateCommands(string rawData, DateTime time, string seperator, string terminator, string idFormat, ref string incompleteData)
        {
            RMTCommand[] result = null;
            if (!string.IsNullOrEmpty(rawData) && !string.IsNullOrEmpty(seperator) && !string.IsNullOrEmpty(terminator))
            {
                string completeData = Utility.SplitOutIncompleteData(rawData, terminator, ref incompleteData);
                if (!string.IsNullOrEmpty(completeData))
                {
                    string[] messages = Utility.SplitStringWithSeperatorKept(completeData, terminator, StringSplitOptions.RemoveEmptyEntries);
                    if (messages != null && messages.Length > 0)
                    {
                        List<RMTCommand> list = new List<RMTCommand>();
                        foreach (string message in messages)
                        {
                            list.Add(new RMTCommand(message, time, seperator, terminator, idFormat));
                        }
                        result = list.ToArray();
                    }
                }
            }
            return result;
        }
    }
}
