﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net.Sockets;
using Pegatron.Foundation;
using Pegatron.Communication;
using Pegatron.Communication.Socket;

namespace Pegatron.Automation.SAC.Protocol.RMT
{
    public delegate void RMTCommandReceivedEventHandler(object sender, RMTCommand command);
    public delegate void RMTResponseReceivedEventHandler(object sender, RMTResponse response);

    public class RMTCommandSendParam : CommSendParam
    {
        public string CommandName
        {
            get;
            set;
        }

        public int CommandID
        {
            get;
            set;
        }

        public int ExpectedReplyCount
        {
            get;
            set;
        }

        public string[] Args
        {
            get;
            set;
        }

        public int TimeoutMilliseconds
        {
            get;
            set;
        }

        public RMTCommandSendParam(string commandName, int expectedReplyCount, int timeoutMilliseconds, params string[] args)
            : this(commandName, RMTCommand.InvalidCommandID, expectedReplyCount, timeoutMilliseconds, args)
        {
        }

        public RMTCommandSendParam(string commandName, int commandID, int expectedReplyCount, int timeoutMilliseconds, params string[] args)
        {
            this.CommandName = commandName;
            this.CommandID = commandID;
            this.ExpectedReplyCount = expectedReplyCount;
            this.TimeoutMilliseconds = timeoutMilliseconds;
            this.Args = args;
        }
    }

    public class RMTCommandSendResult : CommResult
    {
        public RMTCommand Command
        {
            get;
            set;
        }

        public RMTCommandSendResult(RMTCommand command, bool result = false, object error = null)
            : base(result, error)
        {
            this.Command = command;
        }
    }

    public class RMTCommandRecvParam : CommRecvParam
    {
        public RMTCommand Command
        {
            get;
            set;
        }

        public int TimeoutMilliseconds
        {
            get;
            set;
        }

        public RMTCommandRecvParam(RMTCommand command, int timeoutMilliseconds)
        {
            this.Command = command;
            this.TimeoutMilliseconds = timeoutMilliseconds;
        }
    }

    public class RMTCommandRecvResult : CommResult
    {
        public RMTCommand Command
        {
            get;
            set;
        }

        public RMTResponse Response
        {
            get;
            set;
        }

        public RMTCommandRecvResult()
            : this(null, null)
        {
        }

        public RMTCommandRecvResult(RMTCommand command, RMTResponse response, bool result = false, object error = null)
            : base(result, error)
        {
            this.Command = command;
            this.Response = response;
        }
    }

    public class RMTClient : INameDefined, IConnectedDevice, ICommSend, ICommRecv, ICommAsyncRecv
    {
        public const string RemoteConnectionBadParamError  = "RMT remote connection bad param error";
        public const string RemoteSendBadParamError        = "RMT remote send bad param error";
        public const string RemoteRecvBadParamError        = "RMT remote recv bad param error";
        public const string RemoteRecvTimeoutError         = "RMT remote recv timeout error";
        public const string RemoteRecvInterruptError       = "RMT remote recv interrupt error";
        public const string RemoteGeneratedInvalidIDError  = "RMT remote generated invalid command ID error";
        public const string RemoteDisconnectedError        = "RMT remote disconnected error";

        private SocketTcpClient mTcpClient = null;

        private HashTableManager<int, RMTResponse> mResponseData = new HashTableManager<int, RMTResponse>();
        private HashTableManager<int, RMTCommand> mSendCmdData = new HashTableManager<int, RMTCommand>();

        private ManualResetEventSlim mAsyncRecvInterruptEvent = new ManualResetEventSlim(false);

        private IDGenerator mCommandIDGenerator = null;

        private object mSyncRoot = new object();

        public event RMTCommandReceivedEventHandler RMTCommandReceived;
        public event RMTResponseReceivedEventHandler RMTResponseReceived;

        public string Name
        {
            get;
            private set;
        }

        public bool Connected
        {
            get
            {
                return this.mTcpClient.Connected;
            }
        }

        public bool AsyncReceiving
        {
            get
            {
                return this.mTcpClient.AsyncReceiving;
            }
        }

        public string RemoteIP
        {
            get;
            protected set;
        }

        public int RemotePort
        {
            get;
            protected set;
        }

        public Encoding StringEncoding
        {
            get;
            set;
        }

        protected string IncompleteData
        {
            get;
            set;
        }

        protected SocketConnectionParam ConnectionParam
        {
            get;
            set;
        }

        public RMTClient(string name, SocketTcpClient client = null, int maxID = IDGenerator.DefaultMaxID, int minID = IDGenerator.DefaultMinID)
        {
            this.Name = name;
            this.mCommandIDGenerator = new IDGenerator(minID, maxID);
            this.StringEncoding = Encoding.ASCII;
            if (client != null)
            {
                this.mTcpClient = client;
                this.RemoteIP = this.mTcpClient.RemoteIP;
                this.RemotePort = this.mTcpClient.RemotePort;
                this.ConnectionParam = new SocketConnectionParam(this.RemoteIP, this.RemotePort, SocketConnectionParam.DefaultConnectionTimeoutMilliseconds);
                this.BeginAsyncRecv(SocketAsyncRecvParam.Default, this.OnTcpDataReceived);
            }
            else
            {
                this.mTcpClient = new SocketTcpClient();
            }
        }

        public CommResult Connect(CommConnectionParam param)
        {
            CommResult result = new CommResult(false);
            object error = null;
            try
            {
                if (param is SocketConnectionParam)
                {
                    SocketConnectionParam connectionParam = param as SocketConnectionParam;
                    result.Result = this.Connect(
                        connectionParam.RemoteIP,
                        connectionParam.RemotePort,
                        connectionParam.TimeoutMilliseconds,
                        ref error
                        );
                }
                else
                {
                    error = RMTClient.RemoteConnectionBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public bool Connect(string remoteIP, int remotePort, int timeoutMillisecond, ref object error)
        {
            bool result = false;
            lock (this.mSyncRoot)
            {
                try
                {
                    this.Disconnect();
                    if (this.mTcpClient.Connect(remoteIP, remotePort, timeoutMillisecond, ref error))
                    {
                        this.RemoteIP = remoteIP;
                        this.RemotePort = remotePort;
                        this.ConnectionParam = new SocketConnectionParam(this.RemoteIP, this.RemotePort, timeoutMillisecond);
                        CommResult commResult = this.BeginAsyncRecv(SocketAsyncRecvParam.Default, this.OnTcpDataReceived);
                        result = (commResult != null && commResult.Result);
                        if (commResult != null)
                        {
                            error = commResult.Error;
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    result = false;
                    error = ex;
                }
                finally
                {
                    if (!result)
                    {
                        this.Disconnect();
                    }
                }
            }
            return result;
        }

        public void Disconnect()
        {
            lock (this.mSyncRoot)
            {
                this.EndAsyncRecv();
                this.mTcpClient.Disconnect();
                this.ReleaseAllCommandIDs();
                this.IncompleteData = null;
            }
        }

        public CommResult BeginAsyncRecv(CommRecvParam param, CommDataReceivedCallback asyncReceivedCallback)
        {
            CommResult result = new CommResult(false);
            object error = null;
            lock (this.mSyncRoot)
            {
                try
                {
                    this.mAsyncRecvInterruptEvent.Reset();
                    result = this.mTcpClient.BeginAsyncRecv(param, asyncReceivedCallback);
                }
                catch (System.Exception ex)
                {
                    result.Result = false;
                    error = ex;
                }
                finally
                {
                    result.Error = error;
                }
            }
            return result;
        }

        public void EndAsyncRecv()
        {
            lock (this.mSyncRoot)
            {
                this.mAsyncRecvInterruptEvent.Set();
                this.mTcpClient.EndAsyncRecv();
                this.mAsyncRecvInterruptEvent.Reset();
            }
        }

        public void ReleaseAllCommandIDs()
        {
            lock (this.mSyncRoot)
            {
                this.mCommandIDGenerator.ReleaseAll();
                this.mSendCmdData.PerformOnValues(command => command.SetReplyInterrupted());
                this.mSendCmdData.ClearDevices();
                this.mResponseData.ClearDevices();
            }
        }

        public void ReleaseCommandID(int commandID)
        {
            lock (this.mSyncRoot)
            {
                this.mCommandIDGenerator.ReleaseID(commandID);
                this.mSendCmdData.RemoveByKey(commandID);
            }
        }

        public CommResult Send(CommSendParam param)
        {
            RMTCommandSendResult result = new RMTCommandSendResult(null, false);
            object error = null;
            try
            {
                if (param is RMTCommandSendParam)
                {
                    RMTCommandSendParam commandSendParam = param as RMTCommandSendParam;
                    if (commandSendParam.CommandID != RMTCommand.InvalidCommandID)
                    {
                        result.Command =
                            this.Send(commandSendParam.CommandName, commandSendParam.CommandID, commandSendParam.ExpectedReplyCount, ref error, commandSendParam.Args);
                    }
                    else
                    {
                        result.Command =
                            this.Send(commandSendParam.CommandName, commandSendParam.ExpectedReplyCount, ref error, commandSendParam.Args);
                    }
                    if (result.Command != null)
                    {
                        result.Result = true;
                    }
                }
                else
                {
                    error = RMTClient.RemoteSendBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public RMTResponse SendAndWaitReply(string commandName, int timeoutMillisecond, ref object error, params string[] args)
        {
            return this.SendAndWaitReply(commandName, RMTCommand.DefaultCommandExpectedReplyCount, ref error, args);
        }

        public RMTResponse SendAndWaitReply(string commandName, int expectedReplyCount, int timeoutMillisecond, ref object error, params string[] args)
        {
            RMTResponse result = null;
            RMTCommand command = null;
            if ((command = this.Send(commandName, expectedReplyCount, ref error, args)) != null)
            {
                this.WaitUntilReply(command, timeoutMillisecond, ref result, ref error);
            }
            return result;
        }

        public bool WaitUntilReply(RMTCommand command, int timeoutMillisecond, ref RMTResponse reply)
        {
            object error = null;
            return this.WaitUntilReply(command, timeoutMillisecond, ref reply, ref error);
        }

        public bool WaitUntilReply(RMTCommand command, int timeoutMillisecond, ref RMTResponse reply, ref object error)
        {
            bool result = false;
            if (command != null)
            {
                reply = this.Recv(command, timeoutMillisecond, ref error);
                result = (reply != null);
            }
            return result;
        }

        public RMTCommand Send(string commandName, ref object error, params string[] args)
        {
            return this.Send(commandName, RMTCommand.DefaultCommandExpectedReplyCount, ref error, args);
        }

        public RMTCommand UnsolicitedSend(string commandName, ref object error, params string[] args)
        {
            return this.Send(commandName, RMTCommand.UnsolicitedCommandID, 0, ref error, args);
        }

        public RMTCommand Reply(RMTCommand receivedCommand, string commandName, ref object error, params string[] args)
        {
            RMTCommand result = null;
            if (receivedCommand != null)
            {
                result = this.Send(commandName, receivedCommand.CommandID, 0, ref error, args);
            }
            return result;
        }

        public RMTCommand Send(string commandName, int expectedReplyCount, ref object error, params string[] args)
        {
            int commandID = this.mCommandIDGenerator.GenerateID();
            RMTCommand result = this.Send(commandName, commandID, expectedReplyCount, ref error, args);
            if (result == null)
            {
                this.mCommandIDGenerator.ReleaseID(commandID);
            }
            return result;
        }

        private RMTCommand Send(string commandName, int commandID, int expectedReplyCount, ref object error, params string[] args)
        {
            RMTCommand result = null;
            lock (this.mSyncRoot)
            {
                if (!this.Connected)
                {
                    this.Connect(this.ConnectionParam);
                }
                if (this.Connected)
                {
                    if (commandID != IDGenerator.InvalidID)
                    {
                        RMTCommand command = new RMTCommand(commandID, commandName, expectedReplyCount, args);
                        if (command.ExpectedReplyCount > 0)
                        {
                            this.mSendCmdData.SetValueByKey(commandID, command);
                        }
                        if (this.mTcpClient.Send(command.RawData, ref error))
                        {
                            result = command;
                        }
                        else
                        {
                            this.mSendCmdData.RemoveByKey(commandID);
                        }
                    }
                    else
                    {
                        error = RMTClient.RemoteGeneratedInvalidIDError;
                    }
                }
                else
                {
                    error = RMTClient.RemoteDisconnectedError;
                }
            }
            return result;
        }

        public CommResult Recv(CommRecvParam param)
        {
            RMTCommandRecvResult result = new RMTCommandRecvResult();
            object error = null;
            try
            {
                if (param is RMTCommandRecvParam)
                {
                    RMTCommandRecvParam recvParam = param as RMTCommandRecvParam;
                    result.Response = this.Recv(recvParam.Command, recvParam.TimeoutMilliseconds, ref error);
                    if (result.Response != null)
                    {
                        result.Result = true;
                    }
                }
                else
                {
                    error = RMTClient.RemoteRecvBadParamError;
                }
            }
            catch (System.Exception ex)
            {
                result.Result = false;
                error = ex;
            }
            finally
            {
                result.Error = error;
            }
            return result;
        }

        public RMTResponse Recv(RMTCommand command, int timeoutMillisecond, ref object error)
        {
            RMTResponse result = null;
            if (command != null)
            {
                int index = WaitHandle.WaitAny(new WaitHandle[] { command.ReplyFinishedWaitHandle, command.ReplyInterruptedWaitHandle, this.mAsyncRecvInterruptEvent.WaitHandle },
                    timeoutMillisecond);
                result = this.mResponseData[command.CommandID];
                if (index == 0)
                {
                    this.mResponseData.RemoveByKey(command.CommandID);
                }
                else if (index == 1)
                {
                    error = RMTClient.RemoteRecvInterruptError;
                }
                else if (index == 2)
                {
                    error = RMTClient.RemoteRecvInterruptError;
                }
                else
                {
                    error = RMTClient.RemoteRecvTimeoutError;
                }
            }
            return result;
        }

        public void InterruptRecv(RMTCommand command)
        {
            if (command != null)
            {
                command.SetReplyInterrupted();
            }
        }

        private void OnTcpDataReceived(object sender, CommDataReceivedEventArgs data)
        {
            SocketDataReceivedEventArgs tcpData = data as SocketDataReceivedEventArgs;
            if (tcpData != null && tcpData.Data != null)
            {
                string newData = this.StringEncoding.GetString(tcpData.Data, 0, tcpData.Bytes);
                if (!string.IsNullOrEmpty(newData))
                {
                    string rawData = (string.IsNullOrEmpty(this.IncompleteData) ? newData : (this.IncompleteData + newData));
                    string incompleteData = null;
                    RMTCommand[] commands = RMTCommand.CreateCommands(rawData, tcpData.Time, ref incompleteData);
                    this.IncompleteData = incompleteData;

                    if (commands != null)
                    {
                        foreach (RMTCommand command in commands)
                        {
                            this.ProcessCommand(command);
                        }
                    }
                }
            }
        }

        private void ProcessCommand(RMTCommand recvCommand)
        {
            if (recvCommand != null)
            {
                int commandID = recvCommand.CommandID;
                if (this.mSendCmdData.ContainsKey(commandID))
                {
                    RMTCommand sendCommand = this.mSendCmdData[commandID];
                    RMTResponse sendResponse = this.mResponseData[commandID];
                    if (sendResponse == null)
                    {
                        sendResponse = new RMTResponse(sendCommand);
                    }
                    sendResponse.AddResponse(recvCommand);
                    this.mResponseData.SetValueByKey(commandID, sendResponse);
                    if (sendResponse.Responses.Length >= sendCommand.ExpectedReplyCount)
                    {
                        sendCommand.SetReplyFinished();
                        this.ReleaseCommandID(commandID);
                        if (this.RMTResponseReceived != null)
                        {
                            this.RMTResponseReceived.Invoke(this, sendResponse);
                        }
                    }
                }
                if (this.RMTCommandReceived != null)
                {
                    this.RMTCommandReceived.Invoke(this, recvCommand);
                }
            }
        }
    }
}
