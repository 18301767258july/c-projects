﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Management;
using Pegatron.Foundation;
using Pegatron.Communication.Socket;

namespace Pegatron.Automation.SAC.Protocol.PVO
{
    internal class PVOHandShake
    {
        public string RawData
        {
            get;
            protected set;
        }

        public string Command
        {
            get;
            protected set;
        }

        public string GUID
        {
            get;
            protected set;
        }

        public PVOStation Station
        {
            get;
            protected set;
        }

        public string Version
        {
            get;
            protected set;
        }

        public DateTime Time
        {
            get;
            protected set;
        }

        public PVOHandShake()
            : this(null, null, null, null, null, TimeCounter.Now)
        {
        }

        public PVOHandShake(string rawData, string command, string guid, PVOStation pvoStation, string version)
            : this(rawData, command, guid, pvoStation, version, TimeCounter.Now)
        {
        }

        public PVOHandShake(string rawData, string command, string guid, PVOStation station, string version, DateTime time)
        {
            this.RawData = rawData;
            this.Command = command;
            this.GUID = guid;
            this.Station = station;
            this.Version = version;
            this.Time = time;
        }
    }
}
