﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Management;
using Pegatron.Foundation;
using Pegatron.Communication.Socket;

namespace Pegatron.Automation.SAC.Protocol.PVO
{
    public class PVOStation
    {
        private object mSyncRoot = new object();

        public PVOStation RemoteStation
        {
            get;
            set;
        }

        public EPVORoleType RoleType
        {
            get;
            protected set;
        }

        public string StationID
        {
            get;
            protected set;
        }

        public string BroadcastGUID
        {
            get;
            protected set;
        }

        public string UdpIP
        {
            get;
            set;
        }

        public int UdpPort
        {
            get;
            set;
        }

        public string TcpIP
        {
            get;
            set;
        }

        public int TcpPort
        {
            get;
            set;
        }

        public DateTime? HandShakeSendTime
        {
            get;
            set;
        }

        public DateTime? HandShakeReceiveTime
        {
            get;
            set;
        }

        public bool Connected
        {
            get;
            set;
        }

        public double ElapsedSeconds
        {
            get
            {
                lock (this.mSyncRoot)
                {
                    double elapsedSeconds = this.HandShakeReceiveTime == null
                        ? (this.HandShakeSendTime != null ? (TimeCounter.Now - (DateTime)this.HandShakeSendTime).TotalSeconds : -1)
                        : (this.HandShakeSendTime != null ? 0 : (TimeCounter.Now - (DateTime)this.HandShakeReceiveTime).TotalSeconds);
                    /*
                    Console.WriteLine("send time:" + (this.HandShakeSendTime != null ? Utility.GetTimeString((DateTime)this.HandShakeSendTime) : "(null)"));
                    Console.WriteLine("recv time:" + (this.HandShakeReceiveTime != null ? Utility.GetTimeString((DateTime)this.HandShakeReceiveTime) : "(null)"));
                    Console.WriteLine("elapsed seconds:" + elapsedSeconds);
                     */
                    return elapsedSeconds;
                }
            }
        }

        public PVOStation(PVOStation pvoStation)
        {
            this.RemoteStation = pvoStation.RemoteStation;
            this.RoleType = pvoStation.RoleType;
            this.StationID = pvoStation.StationID;
            this.BroadcastGUID = pvoStation.BroadcastGUID;
            this.TcpIP = pvoStation.TcpIP;
            this.TcpPort = pvoStation.TcpPort;
            this.UdpIP = pvoStation.UdpIP;
            this.UdpPort = pvoStation.UdpPort;
            this.Connected = pvoStation.Connected;
            this.HandShakeSendTime = pvoStation.HandShakeSendTime;
            this.HandShakeReceiveTime = pvoStation.HandShakeReceiveTime;
        }

        public PVOStation(EPVORoleType roleType, string stationID, string broadcastGUID, string tcpIP, int tcpPort, string udpIP, int udpPort, bool connected)
        {
            this.RoleType = roleType;
            this.StationID = stationID;
            this.BroadcastGUID = broadcastGUID;
            this.TcpIP = tcpIP;
            this.TcpPort = tcpPort;
            this.UdpIP = udpIP;
            this.UdpPort = udpPort;
            this.Connected = connected;
        }

        public void UpdateHandShakeReceived(DateTime? recvTime)
        {
            lock(this.mSyncRoot)
            {
                this.HandShakeReceiveTime = recvTime;
            }
        }

        public void UpdateHandShakeSent(DateTime? sendTime, bool expectReply = true)
        {
            lock (this.mSyncRoot)
            {
                if (expectReply)
                {
                    if (this.HandShakeSendTime == null || this.HandShakeReceiveTime != null)
                    {
                        this.HandShakeSendTime = sendTime;
                        this.HandShakeReceiveTime = null;
                    }
                }
                else
                {
                    this.HandShakeSendTime = sendTime;
                }
            }
        }

        public void OnRemoteConnected(PVOStation remoteStation, DateTime time)
        {
            if (remoteStation != null)
            {
                this.RemoteStation = remoteStation;
                this.RemoteStation.RemoteStation = this;
                this.Connected = remoteStation.Connected;
                this.UpdateHandShakeReceived(time);
            }
        }
    }
}
