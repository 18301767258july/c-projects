﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Management;
using Pegatron.Foundation;
using Pegatron.Communication.Socket;

namespace Pegatron.Automation.SAC.Protocol.PVO
{
    public class PVONest
    {
        public int NestID
        {
            get;
            protected set;
        }

        public EPVONestStatus? NestStatus
        {
            get;
            set;
        }

        public object Config
        {
            get;
            set;
        }

        public string UUTID
        {
            get;
            set;
        }

        public EPVOTestResult? ResultCode
        {
            get;
            set;
        }

        public string ResultDesc
        {
            get;
            set;
        }

        public string[] Failures
        {
            get;
            set;
        }

        public PVONest(int nestID = -1)
            : this(nestID, null, null)
        {
        }

        public PVONest(int nestID, EPVONestStatus? nestStatus, string uutID)
            : this(nestID, nestStatus, uutID, null, null)
        {
        }

        public PVONest(int nestID, object config)
            : this(nestID, config, null, null, null, null, null)
        {
        }

        public PVONest(int nestID, EPVONestStatus? nestStatus, string uutID, EPVOTestResult? resultCode, string resultDescription, params string[] failures)
            : this(nestID, null, nestStatus, uutID, resultCode, resultDescription, failures)
        {
        }

        public PVONest(int nestID, object config, EPVONestStatus? nestStatus, string uutID, EPVOTestResult? resultCode, string resultDescription, params string[] failures)
        {
            this.NestID = nestID;
            this.Config = config;
            this.NestStatus = nestStatus;
            this.UUTID = uutID;
            this.ResultCode = resultCode;
            this.ResultDesc = resultDescription;
            this.Failures = failures;
        }
    }
}
